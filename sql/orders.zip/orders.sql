-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 10, 2022 at 09:58 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.0.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `orders`
--

-- --------------------------------------------------------

--
-- Table structure for table `account_stament_agents`
--

CREATE TABLE `account_stament_agents` (
  `id` int(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `agent_id` int(20) NOT NULL,
  `payed` int(20) NOT NULL,
  `total` int(20) NOT NULL,
  `late` int(20) NOT NULL,
  `excel` char(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `account_stament_agents`
--

INSERT INTO `account_stament_agents` (`id`, `created_at`, `agent_id`, `payed`, `total`, `late`, `excel`) VALUES
(10, '2022-12-03 00:16:31', 28, 7303, 7399, 96, 'محمود طرفايه/10تقفيل محمود طرفايه 10.xlsx'),
(11, '2022-12-03 00:17:13', 28, 7303, 7399, 96, 'محمود طرفايه/11تقفيل محمود طرفايه 11.xlsx'),
(12, '2022-12-03 00:18:24', 28, 990, 960, -30, 'محمود طرفايه/12تقفيل محمود طرفايه 12.xlsx'),
(13, '2022-12-03 00:19:55', 28, 990, 960, -30, 'محمود طرفايه/13تقفيل محمود طرفايه 13.xlsx'),
(14, '2022-12-03 00:30:50', 28, 98, 0, -98, 'محمود طرفايه/14تقفيل محمود طرفايه 14.xlsx');

-- --------------------------------------------------------

--
-- Table structure for table `account_stament_companies`
--

CREATE TABLE `account_stament_companies` (
  `id` int(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `company_id` int(20) NOT NULL,
  `payed` int(20) NOT NULL,
  `total` int(20) NOT NULL,
  `late` int(20) NOT NULL,
  `excel` char(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `account_stament_companies`
--

INSERT INTO `account_stament_companies` (`id`, `created_at`, `company_id`, `payed`, `total`, `late`, `excel`) VALUES
(19, '2022-12-08 19:48:50', 4, 2549, 2459, -90, 'ADM/19تقفيل ADM 19.xlsx');

-- --------------------------------------------------------

--
-- Table structure for table `causes_return`
--

CREATE TABLE `causes_return` (
  `id` int(20) NOT NULL,
  `cause` char(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `causes_return`
--

INSERT INTO `causes_return` (`id`, `cause`) VALUES
(1, 'hello1');

-- --------------------------------------------------------

--
-- Table structure for table `centers`
--

CREATE TABLE `centers` (
  `id` int(20) NOT NULL,
  `center_name` char(50) NOT NULL,
  `governate_id` int(11) DEFAULT NULL,
  `id_agent` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `centers`
--

INSERT INTO `centers` (`id`, `center_name`, `governate_id`, `id_agent`) VALUES
(6, 'كيمان', 7, 32),
(7, 'باغوص', 7, 33),
(8, 'مسله', 7, 34),
(9, 'ابشواي', 7, 28),
(10, 'اطسا', 7, 29),
(11, 'سنورس', 7, 31),
(12, 'طاميه', 7, 30);

-- --------------------------------------------------------

--
-- Table structure for table `chats`
--

CREATE TABLE `chats` (
  `id` int(20) NOT NULL,
  `msg` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  `reciver_id` int(20) NOT NULL,
  `sender_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `id` int(11) NOT NULL,
  `governorate_id` int(11) NOT NULL,
  `city_name_ar` varchar(200) NOT NULL,
  `city_name_en` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `governorate_id`, `city_name_ar`, `city_name_en`) VALUES
(1, 1, '15 مايو', '15 May'),
(2, 1, 'الازبكية', 'Al Azbakeyah'),
(3, 1, 'البساتين', 'Al Basatin'),
(4, 1, 'التبين', 'Tebin'),
(5, 1, 'الخليفة', 'El-Khalifa'),
(6, 1, 'الدراسة', 'El darrasa'),
(7, 1, 'الدرب الاحمر', 'Aldarb Alahmar'),
(8, 1, 'الزاوية الحمراء', 'Zawya al-Hamra'),
(9, 1, 'الزيتون', 'El-Zaytoun'),
(10, 1, 'الساحل', 'Sahel'),
(11, 1, 'السلام', 'El Salam'),
(12, 1, 'السيدة زينب', 'Sayeda Zeinab'),
(13, 1, 'الشرابية', 'El Sharabeya'),
(14, 1, 'مدينة الشروق', 'Shorouk'),
(15, 1, 'الظاهر', 'El Daher'),
(16, 1, 'العتبة', 'Ataba'),
(17, 1, 'القاهرة الجديدة', 'New Cairo'),
(18, 1, 'المرج', 'El Marg'),
(19, 1, 'عزبة النخل', 'Ezbet el Nakhl'),
(20, 1, 'المطرية', 'Matareya'),
(21, 1, 'المعادى', 'Maadi'),
(22, 1, 'المعصرة', 'Maasara'),
(23, 1, 'المقطم', 'Mokattam'),
(24, 1, 'المنيل', 'Manyal'),
(25, 1, 'الموسكى', 'Mosky'),
(26, 1, 'النزهة', 'Nozha'),
(27, 1, 'الوايلى', 'Waily'),
(28, 1, 'باب الشعرية', 'Bab al-Shereia'),
(29, 1, 'بولاق', 'Bolaq'),
(30, 1, 'جاردن سيتى', 'Garden City'),
(31, 1, 'حدائق القبة', 'Hadayek El-Kobba'),
(32, 1, 'حلوان', 'Helwan'),
(33, 1, 'دار السلام', 'Dar Al Salam'),
(34, 1, 'شبرا', 'Shubra'),
(35, 1, 'طره', 'Tura'),
(36, 1, 'عابدين', 'Abdeen'),
(37, 1, 'عباسية', 'Abaseya'),
(38, 1, 'عين شمس', 'Ain Shams'),
(39, 1, 'مدينة نصر', 'Nasr City'),
(40, 1, 'مصر الجديدة', 'New Heliopolis'),
(41, 1, 'مصر القديمة', 'Masr Al Qadima'),
(42, 1, 'منشية ناصر', 'Mansheya Nasir'),
(43, 1, 'مدينة بدر', 'Badr City'),
(44, 1, 'مدينة العبور', 'Obour City'),
(45, 1, 'وسط البلد', 'Cairo Downtown'),
(46, 1, 'الزمالك', 'Zamalek'),
(47, 1, 'قصر النيل', 'Kasr El Nile'),
(48, 1, 'الرحاب', 'Rehab'),
(49, 1, 'القطامية', 'Katameya'),
(50, 1, 'مدينتي', 'Madinty'),
(51, 1, 'روض الفرج', 'Rod Alfarag'),
(52, 1, 'شيراتون', 'Sheraton'),
(53, 1, 'الجمالية', 'El-Gamaleya'),
(54, 1, 'العاشر من رمضان', '10th of Ramadan City'),
(55, 1, 'الحلمية', 'Helmeyat Alzaytoun'),
(56, 1, 'النزهة الجديدة', 'New Nozha'),
(57, 1, 'العاصمة الإدارية', 'Capital New'),
(58, 2, 'الجيزة', 'Giza'),
(59, 2, 'السادس من أكتوبر', 'Sixth of October'),
(60, 2, 'الشيخ زايد', 'Cheikh Zayed'),
(61, 2, 'الحوامدية', 'Hawamdiyah'),
(62, 2, 'البدرشين', 'Al Badrasheen'),
(63, 2, 'الصف', 'Saf'),
(64, 2, 'أطفيح', 'Atfih'),
(65, 2, 'العياط', 'Al Ayat'),
(66, 2, 'الباويطي', 'Al-Bawaiti'),
(67, 2, 'منشأة القناطر', 'ManshiyetAl Qanater'),
(68, 2, 'أوسيم', 'Oaseem'),
(69, 2, 'كرداسة', 'Kerdasa'),
(70, 2, 'أبو النمرس', 'Abu Nomros'),
(71, 2, 'كفر غطاطي', 'Kafr Ghati'),
(72, 2, 'منشأة البكاري', 'Manshiyet Al Bakari'),
(73, 2, 'الدقى', 'Dokki'),
(74, 2, 'العجوزة', 'Agouza'),
(75, 2, 'الهرم', 'Haram'),
(76, 2, 'الوراق', 'Warraq'),
(77, 2, 'امبابة', 'Imbaba'),
(78, 2, 'بولاق الدكرور', 'Boulaq Dakrour'),
(79, 2, 'الواحات البحرية', 'Al Wahat Al Baharia'),
(80, 2, 'العمرانية', 'Omraneya'),
(81, 2, 'المنيب', 'Moneeb'),
(82, 2, 'بين السرايات', 'Bin Alsarayat'),
(83, 2, 'الكيت كات', 'Kit Kat'),
(84, 2, 'المهندسين', 'Mohandessin'),
(85, 2, 'فيصل', 'Faisal'),
(86, 2, 'أبو رواش', 'Abu Rawash'),
(87, 2, 'حدائق الأهرام', 'Hadayek Alahram'),
(88, 2, 'الحرانية', 'Haraneya'),
(89, 2, 'حدائق اكتوبر', 'Hadayek October'),
(90, 2, 'صفط اللبن', 'Saft Allaban'),
(91, 2, 'القرية الذكية', 'Smart Village'),
(92, 2, 'ارض اللواء', 'Ard Ellwaa'),
(93, 3, 'ابو قير', 'Abu Qir'),
(94, 3, 'الابراهيمية', 'Al Ibrahimeyah'),
(95, 3, 'الأزاريطة', 'Azarita'),
(96, 3, 'الانفوشى', 'Anfoushi'),
(97, 3, 'الدخيلة', 'Dekheila'),
(98, 3, 'السيوف', 'El Soyof'),
(99, 3, 'العامرية', 'Ameria'),
(100, 3, 'اللبان', 'El Labban'),
(101, 3, 'المفروزة', 'Al Mafrouza'),
(102, 3, 'المنتزه', 'El Montaza'),
(103, 3, 'المنشية', 'Mansheya'),
(104, 3, 'الناصرية', 'Naseria'),
(105, 3, 'امبروزو', 'Ambrozo'),
(106, 3, 'باب شرق', 'Bab Sharq'),
(107, 3, 'برج العرب', 'Bourj Alarab'),
(108, 3, 'ستانلى', 'Stanley'),
(109, 3, 'سموحة', 'Smouha'),
(110, 3, 'سيدى بشر', 'Sidi Bishr'),
(111, 3, 'شدس', 'Shads'),
(112, 3, 'غيط العنب', 'Gheet Alenab'),
(113, 3, 'فلمينج', 'Fleming'),
(114, 3, 'فيكتوريا', 'Victoria'),
(115, 3, 'كامب شيزار', 'Camp Shizar'),
(116, 3, 'كرموز', 'Karmooz'),
(117, 3, 'محطة الرمل', 'Mahta Alraml'),
(118, 3, 'مينا البصل', 'Mina El-Basal'),
(119, 3, 'العصافرة', 'Asafra'),
(120, 3, 'العجمي', 'Agamy'),
(121, 3, 'بكوس', 'Bakos'),
(122, 3, 'بولكلي', 'Boulkly'),
(123, 3, 'كليوباترا', 'Cleopatra'),
(124, 3, 'جليم', 'Glim'),
(125, 3, 'المعمورة', 'Al Mamurah'),
(126, 3, 'المندرة', 'Al Mandara'),
(127, 3, 'محرم بك', 'Moharam Bek'),
(128, 3, 'الشاطبي', 'Elshatby'),
(129, 3, 'سيدي جابر', 'Sidi Gaber'),
(130, 3, 'الساحل الشمالي', 'North Coast/sahel'),
(131, 3, 'الحضرة', 'Alhadra'),
(132, 3, 'العطارين', 'Alattarin'),
(133, 3, 'سيدي كرير', 'Sidi Kerir'),
(134, 3, 'الجمرك', 'Elgomrok'),
(135, 3, 'المكس', 'Al Max'),
(136, 3, 'مارينا', 'Marina'),
(137, 4, 'المنصورة', 'Mansoura'),
(138, 4, 'طلخا', 'Talkha'),
(139, 4, 'ميت غمر', 'Mitt Ghamr'),
(140, 4, 'دكرنس', 'Dekernes'),
(141, 4, 'أجا', 'Aga'),
(142, 4, 'منية النصر', 'Menia El Nasr'),
(143, 4, 'السنبلاوين', 'Sinbillawin'),
(144, 4, 'الكردي', 'El Kurdi'),
(145, 4, 'بني عبيد', 'Bani Ubaid'),
(146, 4, 'المنزلة', 'Al Manzala'),
(147, 4, 'تمي الأمديد', 'tami al\'amdid'),
(148, 4, 'الجمالية', 'aljamalia'),
(149, 4, 'شربين', 'Sherbin'),
(150, 4, 'المطرية', 'Mataria'),
(151, 4, 'بلقاس', 'Belqas'),
(152, 4, 'ميت سلسيل', 'Meet Salsil'),
(153, 4, 'جمصة', 'Gamasa'),
(154, 4, 'محلة دمنة', 'Mahalat Damana'),
(155, 4, 'نبروه', 'Nabroh'),
(156, 5, 'الغردقة', 'Hurghada'),
(157, 5, 'رأس غارب', 'Ras Ghareb'),
(158, 5, 'سفاجا', 'Safaga'),
(159, 5, 'القصير', 'El Qusiar'),
(160, 5, 'مرسى علم', 'Marsa Alam'),
(161, 5, 'الشلاتين', 'Shalatin'),
(162, 5, 'حلايب', 'Halaib'),
(163, 5, 'الدهار', 'Aldahar'),
(164, 6, 'دمنهور', 'Damanhour'),
(165, 6, 'كفر الدوار', 'Kafr El Dawar'),
(166, 6, 'رشيد', 'Rashid'),
(167, 6, 'إدكو', 'Edco'),
(168, 6, 'أبو المطامير', 'Abu al-Matamir'),
(169, 6, 'أبو حمص', 'Abu Homs'),
(170, 6, 'الدلنجات', 'Delengat'),
(171, 6, 'المحمودية', 'Mahmoudiyah'),
(172, 6, 'الرحمانية', 'Rahmaniyah'),
(173, 6, 'إيتاي البارود', 'Itai Baroud'),
(174, 6, 'حوش عيسى', 'Housh Eissa'),
(175, 6, 'شبراخيت', 'Shubrakhit'),
(176, 6, 'كوم حمادة', 'Kom Hamada'),
(177, 6, 'بدر', 'Badr'),
(178, 6, 'وادي النطرون', 'Wadi Natrun'),
(179, 6, 'النوبارية الجديدة', 'New Nubaria'),
(180, 6, 'النوبارية', 'Alnoubareya'),
(181, 7, 'الفيوم', 'Fayoum'),
(182, 7, 'الفيوم الجديدة', 'Fayoum El Gedida'),
(183, 7, 'طامية', 'Tamiya'),
(184, 7, 'سنورس', 'Snores'),
(185, 7, 'إطسا', 'Etsa'),
(186, 7, 'إبشواي', 'Epschway'),
(187, 7, 'يوسف الصديق', 'Yusuf El Sediaq'),
(188, 7, 'الحادقة', 'Hadqa'),
(189, 7, 'اطسا', 'Atsa'),
(190, 7, 'الجامعة', 'Algamaa'),
(191, 7, 'السيالة', 'Sayala'),
(192, 8, 'طنطا', 'Tanta'),
(193, 8, 'المحلة الكبرى', 'Al Mahalla Al Kobra'),
(194, 8, 'كفر الزيات', 'Kafr El Zayat'),
(195, 8, 'زفتى', 'Zefta'),
(196, 8, 'السنطة', 'El Santa'),
(197, 8, 'قطور', 'Qutour'),
(198, 8, 'بسيون', 'Basion'),
(199, 8, 'سمنود', 'Samannoud'),
(200, 9, 'الإسماعيلية', 'Ismailia'),
(201, 9, 'فايد', 'Fayed'),
(202, 9, 'القنطرة شرق', 'Qantara Sharq'),
(203, 9, 'القنطرة غرب', 'Qantara Gharb'),
(204, 9, 'التل الكبير', 'El Tal El Kabier'),
(205, 9, 'أبو صوير', 'Abu Sawir'),
(206, 9, 'القصاصين الجديدة', 'Kasasien El Gedida'),
(207, 9, 'نفيشة', 'Nefesha'),
(208, 9, 'الشيخ زايد', 'Sheikh Zayed'),
(209, 10, 'شبين الكوم', 'Shbeen El Koom'),
(210, 10, 'مدينة السادات', 'Sadat City'),
(211, 10, 'منوف', 'Menouf'),
(212, 10, 'سرس الليان', 'Sars El-Layan'),
(213, 10, 'أشمون', 'Ashmon'),
(214, 10, 'الباجور', 'Al Bagor'),
(215, 10, 'قويسنا', 'Quesna'),
(216, 10, 'بركة السبع', 'Berkat El Saba'),
(217, 10, 'تلا', 'Tala'),
(218, 10, 'الشهداء', 'Al Shohada'),
(219, 11, 'المنيا', 'Minya'),
(220, 11, 'المنيا الجديدة', 'Minya El Gedida'),
(221, 11, 'العدوة', 'El Adwa'),
(222, 11, 'مغاغة', 'Magagha'),
(223, 11, 'بني مزار', 'Bani Mazar'),
(224, 11, 'مطاي', 'Mattay'),
(225, 11, 'سمالوط', 'Samalut'),
(226, 11, 'المدينة الفكرية', 'Madinat El Fekria'),
(227, 11, 'ملوي', 'Meloy'),
(228, 11, 'دير مواس', 'Deir Mawas'),
(229, 11, 'ابو قرقاص', 'Abu Qurqas'),
(230, 11, 'ارض سلطان', 'Ard Sultan'),
(231, 12, 'بنها', 'Banha'),
(232, 12, 'قليوب', 'Qalyub'),
(233, 12, 'شبرا الخيمة', 'Shubra Al Khaimah'),
(234, 12, 'القناطر الخيرية', 'Al Qanater Charity'),
(235, 12, 'الخانكة', 'Khanka'),
(236, 12, 'كفر شكر', 'Kafr Shukr'),
(237, 12, 'طوخ', 'Tukh'),
(238, 12, 'قها', 'Qaha'),
(239, 12, 'العبور', 'Obour'),
(240, 12, 'الخصوص', 'Khosous'),
(241, 12, 'شبين القناطر', 'Shibin Al Qanater'),
(242, 12, 'مسطرد', 'Mostorod'),
(243, 13, 'الخارجة', 'El Kharga'),
(244, 13, 'باريس', 'Paris'),
(245, 13, 'موط', 'Mout'),
(246, 13, 'الفرافرة', 'Farafra'),
(247, 13, 'بلاط', 'Balat'),
(248, 13, 'الداخلة', 'Dakhla'),
(249, 14, 'السويس', 'Suez'),
(250, 14, 'الجناين', 'Alganayen'),
(251, 14, 'عتاقة', 'Ataqah'),
(252, 14, 'العين السخنة', 'Ain Sokhna'),
(253, 14, 'فيصل', 'Faysal'),
(254, 15, 'أسوان', 'Aswan'),
(255, 15, 'أسوان الجديدة', 'Aswan El Gedida'),
(256, 15, 'دراو', 'Drau'),
(257, 15, 'كوم أمبو', 'Kom Ombo'),
(258, 15, 'نصر النوبة', 'Nasr Al Nuba'),
(259, 15, 'كلابشة', 'Kalabsha'),
(260, 15, 'إدفو', 'Edfu'),
(261, 15, 'الرديسية', 'Al-Radisiyah'),
(262, 15, 'البصيلية', 'Al Basilia'),
(263, 15, 'السباعية', 'Al Sibaeia'),
(264, 15, 'ابوسمبل السياحية', 'Abo Simbl Al Siyahia'),
(265, 15, 'مرسى علم', 'Marsa Alam'),
(266, 16, 'أسيوط', 'Assiut'),
(267, 16, 'أسيوط الجديدة', 'Assiut El Gedida'),
(268, 16, 'ديروط', 'Dayrout'),
(269, 16, 'منفلوط', 'Manfalut'),
(270, 16, 'القوصية', 'Qusiya'),
(271, 16, 'أبنوب', 'Abnoub'),
(272, 16, 'أبو تيج', 'Abu Tig'),
(273, 16, 'الغنايم', 'El Ghanaim'),
(274, 16, 'ساحل سليم', 'Sahel Selim'),
(275, 16, 'البداري', 'El Badari'),
(276, 16, 'صدفا', 'Sidfa'),
(277, 17, 'بني سويف', 'Bani Sweif'),
(278, 17, 'بني سويف الجديدة', 'Beni Suef El Gedida'),
(279, 17, 'الواسطى', 'Al Wasta'),
(280, 17, 'ناصر', 'Naser'),
(281, 17, 'إهناسيا', 'Ehnasia'),
(282, 17, 'ببا', 'beba'),
(283, 17, 'الفشن', 'Fashn'),
(284, 17, 'سمسطا', 'Somasta'),
(285, 17, 'الاباصيرى', 'Alabbaseri'),
(286, 17, 'مقبل', 'Mokbel'),
(287, 18, 'بورسعيد', 'PorSaid'),
(288, 18, 'بورفؤاد', 'Port Fouad'),
(289, 18, 'العرب', 'Alarab'),
(290, 18, 'حى الزهور', 'Zohour'),
(291, 18, 'حى الشرق', 'Alsharq'),
(292, 18, 'حى الضواحى', 'Aldawahi'),
(293, 18, 'حى المناخ', 'Almanakh'),
(294, 18, 'حى مبارك', 'Mubarak'),
(295, 19, 'دمياط', 'Damietta'),
(296, 19, 'دمياط الجديدة', 'New Damietta'),
(297, 19, 'رأس البر', 'Ras El Bar'),
(298, 19, 'فارسكور', 'Faraskour'),
(299, 19, 'الزرقا', 'Zarqa'),
(300, 19, 'السرو', 'alsaru'),
(301, 19, 'الروضة', 'alruwda'),
(302, 19, 'كفر البطيخ', 'Kafr El-Batikh'),
(303, 19, 'عزبة البرج', 'Azbet Al Burg'),
(304, 19, 'ميت أبو غالب', 'Meet Abou Ghalib'),
(305, 19, 'كفر سعد', 'Kafr Saad'),
(306, 20, 'الزقازيق', 'Zagazig'),
(307, 20, 'العاشر من رمضان', 'Al Ashr Men Ramadan'),
(308, 20, 'منيا القمح', 'Minya Al Qamh'),
(309, 20, 'بلبيس', 'Belbeis'),
(310, 20, 'مشتول السوق', 'Mashtoul El Souq'),
(311, 20, 'القنايات', 'Qenaiat'),
(312, 20, 'أبو حماد', 'Abu Hammad'),
(313, 20, 'القرين', 'El Qurain'),
(314, 20, 'ههيا', 'Hehia'),
(315, 20, 'أبو كبير', 'Abu Kabir'),
(316, 20, 'فاقوس', 'Faccus'),
(317, 20, 'الصالحية الجديدة', 'El Salihia El Gedida'),
(318, 20, 'الإبراهيمية', 'Al Ibrahimiyah'),
(319, 20, 'ديرب نجم', 'Deirb Negm'),
(320, 20, 'كفر صقر', 'Kafr Saqr'),
(321, 20, 'أولاد صقر', 'Awlad Saqr'),
(322, 20, 'الحسينية', 'Husseiniya'),
(323, 20, 'صان الحجر القبلية', 'san alhajar alqablia'),
(324, 20, 'منشأة أبو عمر', 'Manshayat Abu Omar'),
(325, 21, 'الطور', 'Al Toor'),
(326, 21, 'شرم الشيخ', 'Sharm El-Shaikh'),
(327, 21, 'دهب', 'Dahab'),
(328, 21, 'نويبع', 'Nuweiba'),
(329, 21, 'طابا', 'Taba'),
(330, 21, 'سانت كاترين', 'Saint Catherine'),
(331, 21, 'أبو رديس', 'Abu Redis'),
(332, 21, 'أبو زنيمة', 'Abu Zenaima'),
(333, 21, 'رأس سدر', 'Ras Sidr'),
(334, 22, 'كفر الشيخ', 'Kafr El Sheikh'),
(335, 22, 'وسط البلد كفر الشيخ', 'Kafr El Sheikh Downtown'),
(336, 22, 'دسوق', 'Desouq'),
(337, 22, 'فوه', 'Fooh'),
(338, 22, 'مطوبس', 'Metobas'),
(339, 22, 'برج البرلس', 'Burg Al Burullus'),
(340, 22, 'بلطيم', 'Baltim'),
(341, 22, 'مصيف بلطيم', 'Masief Baltim'),
(342, 22, 'الحامول', 'Hamol'),
(343, 22, 'بيلا', 'Bella'),
(344, 22, 'الرياض', 'Riyadh'),
(345, 22, 'سيدي سالم', 'Sidi Salm'),
(346, 22, 'قلين', 'Qellen'),
(347, 22, 'سيدي غازي', 'Sidi Ghazi'),
(348, 23, 'مرسى مطروح', 'Marsa Matrouh'),
(349, 23, 'الحمام', 'El Hamam'),
(350, 23, 'العلمين', 'Alamein'),
(351, 23, 'الضبعة', 'Dabaa'),
(352, 23, 'النجيلة', 'Al-Nagila'),
(353, 23, 'سيدي براني', 'Sidi Brani'),
(354, 23, 'السلوم', 'Salloum'),
(355, 23, 'سيوة', 'Siwa'),
(356, 23, 'مارينا', 'Marina'),
(357, 23, 'الساحل الشمالى', 'North Coast'),
(358, 24, 'الأقصر', 'Luxor'),
(359, 24, 'الأقصر الجديدة', 'New Luxor'),
(360, 24, 'إسنا', 'Esna'),
(361, 24, 'طيبة الجديدة', 'New Tiba'),
(362, 24, 'الزينية', 'Al ziynia'),
(363, 24, 'البياضية', 'Al Bayadieh'),
(364, 24, 'القرنة', 'Al Qarna'),
(365, 24, 'أرمنت', 'Armant'),
(366, 24, 'الطود', 'Al Tud'),
(367, 25, 'قنا', 'Qena'),
(368, 25, 'قنا الجديدة', 'New Qena'),
(369, 25, 'ابو طشت', 'Abu Tesht'),
(370, 25, 'نجع حمادي', 'Nag Hammadi'),
(371, 25, 'دشنا', 'Deshna'),
(372, 25, 'الوقف', 'Alwaqf'),
(373, 25, 'قفط', 'Qaft'),
(374, 25, 'نقادة', 'Naqada'),
(375, 25, 'فرشوط', 'Farshout'),
(376, 25, 'قوص', 'Quos'),
(377, 26, 'العريش', 'Arish'),
(378, 26, 'الشيخ زويد', 'Sheikh Zowaid'),
(379, 26, 'نخل', 'Nakhl'),
(380, 26, 'رفح', 'Rafah'),
(381, 26, 'بئر العبد', 'Bir al-Abed'),
(382, 26, 'الحسنة', 'Al Hasana'),
(383, 27, 'سوهاج', 'Sohag'),
(384, 27, 'سوهاج الجديدة', 'Sohag El Gedida'),
(385, 27, 'أخميم', 'Akhmeem'),
(386, 27, 'أخميم الجديدة', 'Akhmim El Gedida'),
(387, 27, 'البلينا', 'Albalina'),
(388, 27, 'المراغة', 'El Maragha'),
(389, 27, 'المنشأة', 'almunsha\'a'),
(390, 27, 'دار السلام', 'Dar AISalaam'),
(391, 27, 'جرجا', 'Gerga'),
(392, 27, 'جهينة الغربية', 'Jahina Al Gharbia'),
(393, 27, 'ساقلته', 'Saqilatuh'),
(394, 27, 'طما', 'Tama'),
(395, 27, 'طهطا', 'Tahta'),
(396, 27, 'الكوثر', 'Alkawthar');

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE `companies` (
  `id` int(20) NOT NULL,
  `name` char(50) NOT NULL,
  `commission` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`id`, `name`, `commission`) VALUES
(4, 'ADM', 60);

-- --------------------------------------------------------

--
-- Table structure for table `companies_phones`
--

CREATE TABLE `companies_phones` (
  `id` int(20) NOT NULL,
  `note_en` char(50) NOT NULL,
  `note_ar` char(50) NOT NULL,
  `phone_number` char(11) NOT NULL,
  `id_companiy` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `companies_phones`
--

INSERT INTO `companies_phones` (`id`, `note_en`, `note_ar`, `phone_number`, `id_companiy`) VALUES
(5, 'fhjghkjkj', 'سيبيسب', '01148422820', 4),
(6, 'sdfddf', 'سيبيسب11', '01140481692', 4);

-- --------------------------------------------------------

--
-- Table structure for table `company_expenses`
--

CREATE TABLE `company_expenses` (
  `id` int(11) NOT NULL,
  `name` char(50) NOT NULL,
  `cost` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `company_expenses`
--

INSERT INTO `company_expenses` (`id`, `name`, `cost`, `created_at`) VALUES
(1, 'mahmoud', -70, '2022-12-01 02:39:11');

-- --------------------------------------------------------

--
-- Table structure for table `delegates`
--

CREATE TABLE `delegates` (
  `id_center` int(11) NOT NULL,
  `delegate_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `discounts`
--

CREATE TABLE `discounts` (
  `id` int(40) UNSIGNED NOT NULL,
  `cost` int(5) UNSIGNED NOT NULL,
  `id_user` int(20) DEFAULT NULL,
  `notes` char(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `discounts`
--

INSERT INTO `discounts` (`id`, `cost`, `id_user`, `notes`, `created_at`) VALUES
(1, 30, 35, '', '2022-11-30 22:51:43'),
(2, 6, 26, 'fghtrghgf', '2022-12-01 01:42:03'),
(3, 90, 35, 'test -', '2022-12-01 02:50:48');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `governorates`
--

CREATE TABLE `governorates` (
  `id` int(11) NOT NULL,
  `governorate_name_ar` varchar(50) NOT NULL,
  `governorate_name_en` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `governorates`
--

INSERT INTO `governorates` (`id`, `governorate_name_ar`, `governorate_name_en`) VALUES
(1, 'القاهرة', 'Cairo'),
(2, 'الجيزة', 'Giza'),
(3, 'الأسكندرية', 'Alexandria'),
(4, 'الدقهلية', 'Dakahlia'),
(5, 'البحر الأحمر', 'Red Sea'),
(6, 'البحيرة', 'Beheira'),
(7, 'الفيوم', 'Fayoum'),
(8, 'الغربية', 'Gharbiya'),
(9, 'الإسماعلية', 'Ismailia'),
(10, 'المنوفية', 'Menofia'),
(11, 'المنيا', 'Minya'),
(12, 'القليوبية', 'Qaliubiya'),
(13, 'الوادي الجديد', 'New Valley'),
(14, 'السويس', 'Suez'),
(15, 'اسوان', 'Aswan'),
(16, 'اسيوط', 'Assiut'),
(17, 'بني سويف', 'Beni Suef'),
(18, 'بورسعيد', 'Port Said'),
(19, 'دمياط', 'Damietta'),
(20, 'الشرقية', 'Sharkia'),
(21, 'جنوب سيناء', 'South Sinai'),
(22, 'كفر الشيخ', 'Kafr Al sheikh'),
(23, 'مطروح', 'Matrouh'),
(24, 'الأقصر', 'Luxor'),
(25, 'قنا', 'Qena'),
(26, 'شمال سيناء', 'North Sinai'),
(27, 'سوهاج', 'Sohag');

-- --------------------------------------------------------

--
-- Table structure for table `keep_money`
--

CREATE TABLE `keep_money` (
  `id` int(90) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `money` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2019_08_19_000000_create_failed_jobs_table', 1),
(2, '2019_12_14_000001_create_personal_access_tokens_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `msg` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `id_company` int(20) DEFAULT NULL COMMENT 'required',
  `id_police` char(20) DEFAULT NULL COMMENT 'required',
  `name_client` char(250) DEFAULT NULL COMMENT 'required',
  `phone` char(50) DEFAULT NULL COMMENT 'required',
  `phone2` char(50) DEFAULT NULL,
  `center_id` int(20) DEFAULT NULL,
  `agent_id` int(20) DEFAULT NULL COMMENT 'required',
  `delegate_id` int(20) DEFAULT NULL,
  `address` char(255) DEFAULT NULL COMMENT 'required',
  `cost` char(50) DEFAULT '0' COMMENT 'required',
  `salary_charge` char(50) DEFAULT NULL,
  `date` date DEFAULT NULL COMMENT 'required',
  `notes` char(255) DEFAULT NULL,
  `special_intructions` char(255) DEFAULT NULL,
  `name_product` char(255) DEFAULT NULL,
  `sender` char(50) DEFAULT NULL,
  `weghit` char(50) DEFAULT NULL,
  `open` char(250) DEFAULT NULL,
  `status_id` int(20) DEFAULT NULL,
  `cause_id` int(20) DEFAULT NULL,
  `order_locate` tinyint(1) DEFAULT 0 COMMENT '0=>not deliver ,1=>incompany,2=>withdelegate,3=>return',
  `gps_delivered` char(50) DEFAULT NULL,
  `identy_number` char(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `delegate_supply` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0=>not ,1=>yes',
  `delegate_supply_date` timestamp NULL DEFAULT NULL,
  `company_supply` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0=>not ,1=>yes',
  `company_supply_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `id_company`, `id_police`, `name_client`, `phone`, `phone2`, `center_id`, `agent_id`, `delegate_id`, `address`, `cost`, `salary_charge`, `date`, `notes`, `special_intructions`, `name_product`, `sender`, `weghit`, `open`, `status_id`, `cause_id`, `order_locate`, `gps_delivered`, `identy_number`, `created_at`, `updated_at`, `delegate_supply`, `delegate_supply_date`, `company_supply`, `company_supply_date`) VALUES
(188, 4, 'SP1001069214', 'Ahmed Abdo', '1069082524', 'none', 9, 28, 34, 'الفيوم مركز ابشواي قرية طبهار عند المعهد الديني', '940', '10', '2022-11-28', 'none', 'none', 'none', 'R2S', 'none', 'none', 1, NULL, 0, NULL, 'none', '2022-11-28 20:06:51', '2022-12-08 19:48:50', 1, '2022-12-03 00:17:13', 1, '2022-12-08 19:48:50'),
(189, 4, 'N3022370', 'بسمة', '1020502901', 'none', 9, 28, NULL, 'ابشواي ابو جنشو شارعه بورر سعيد بجواار مسجد النور', '2245', '10', '2022-11-28', 'none', 'none', 'none', 'R2S', 'none', NULL, 2, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', '2022-12-04 16:50:07', 0, '2022-12-03 00:17:13', 0, NULL),
(190, 4, '2001185758', 'محمد السيد', '1099095501', 'none', 9, 28, NULL, 'ابشواي', '2879', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, 3, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', '2022-12-04 16:54:17', 0, '2022-12-03 00:17:13', 0, NULL),
(191, 4, 'K694', 'شروق محمد', '1155641867', 'none', 9, 28, NULL, 'فيديمين الطريق السياحي لجوار صيدليه الدكتور غيث', '495', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, 4, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', '2022-12-04 16:54:18', 0, '2022-12-03 00:17:13', 0, NULL),
(192, 4, 'MGX200450208', 'روان عبد الحليم', '1005882276', 'none', 9, 28, NULL, 'ابشواي قصر الجبالي', '990', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, 6, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', '2022-12-04 16:54:19', 0, '2022-12-03 00:19:56', 0, NULL),
(193, 4, '2001187151', 'جمعه.رجب.احمد اكرامي', '01017299844 // 01101624467', 'none', 9, NULL, NULL, 'يوسف الصديق', '1990', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(194, 4, '789400', 'امال محمود', '1062187037', 'none', 9, NULL, NULL, 'فيوم قريه قديمن', '1545', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(195, 4, 'km81', 'ادهم محمد ابراهيم', '01062201285/1151319341', 'none', 9, NULL, NULL, 'الفيوم.. مركز يوسف الصديق.. الخريجين شارع السجل المدني بجوار البريد.', '340', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(196, 4, 'M466', 'ادهم محمد ابراهيم', '1151319341', 'none', 9, NULL, NULL, 'الفيوم قريه بنى صالح الجامع اول طريق بحيره قارون', '340', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(197, 4, 'مينا 1', 'ابراهيم رشاد', '1140847380', 'none', 9, 31, NULL, 'الفيوم سنورس سنهور القبليه', '660', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(198, 4, 'مينا 4', 'بدون اسم', '1015305053', 'none', 9, NULL, NULL, 'محافظه الفيوم قريه فيديمين عند الموقف', '445', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(199, 4, 'مينا3', 'عصام محمد', '1140778505', 'none', 9, 28, NULL, 'ابشواي سنرو القبليه', '410', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(200, 4, 'مينا7', 'اسلام محمود', '1141397107', 'none', 9, NULL, NULL, 'الفيوم/بجوار بحيرة قارون/قرية وليدة', '760', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(201, 4, 'مينا5', 'طارق فارس', '1122138473', 'none', 9, NULL, NULL, 'سنهور القبلية', '260', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(202, 4, 'مينا 2', 'رجب رزق', '1020506446', 'none', 9, 28, NULL, 'الفيوم مركز ابشواي \nمساكن المطافي محل انتي الاجمل', '260', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(203, 4, 'مينا6', 'ابراهيم', '1146659169', 'none', 9, 28, NULL, 'مركز ابشواي قرية ابو عيش على ضفاف بحيرة قارون امام كافيتريا قصر الاليزيه', '460', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(204, 4, '176471', 'مهاب محسن صبري', '1010311169-11018888475', 'none', 9, NULL, NULL, 'الفيوم سنهور القبلية موقف الفيوم', '395', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(205, 4, '176469', 'ا/سيد', '1022158873-110188475', 'none', 9, NULL, NULL, 'الفيوم فيديمين غرب البلد', '785', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(206, 4, '1225239', 'بسمله محمد', '1225239378', 'none', 9, NULL, NULL, 'سنهور الفيله عند المجمع', '50', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(207, 4, '240011', 'سيد', '1129345894', 'none', 9, NULL, NULL, 'الفيوم سنهور القبليه', '250', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(208, 4, '1091773', 'خلود', '1091773065', 'none', 9, NULL, NULL, 'مركز الشواشنة', '25', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(209, 4, '1270735', 'مني', '1270735797', 'none', 9, NULL, NULL, 'الفيوم مركز ابشواى خلف مسجد الحضانة', '300', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(210, 4, '53482', 'احمد محمد سلامه', '1226193651', 'none', 9, NULL, NULL, 'مركز سنهور', '400', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(211, 4, '122588', 'منال', '1225884884', 'none', 9, NULL, NULL, 'الفيوم مركز يوسف الصديق عزبة عفيفي', '210', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(212, 4, '11201649', 'none', '1120164976', 'none', 9, NULL, NULL, 'الفيوم قارون القرية الاوالي', '200', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(213, 4, '3089', 'ا/هيلانه سمير', '1223933953', 'none', 9, NULL, NULL, 'الفيوم. يوسف الصديق.الحامولى', '180', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(214, 4, '11575834', 'محمد احمد', '1157583484-1200588091', 'none', 9, NULL, NULL, 'زاوية كرداسة مركز الفيوم', '210', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(215, 4, '20896', 'دسوقي سيد جمعه', '1019997428-1147333147', 'none', 9, NULL, NULL, 'قريه ثلاث بجوارمسجد الفارق عمر', '610', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(216, 4, '20955', 'مهيتاب كامل', '1019644228', 'none', 9, NULL, NULL, 'مركز الشوشنه حارت اروبي امام الفرنه', '280', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(217, 4, '4651', 'منه احمد سيد', '1121197301', 'none', 9, 28, NULL, 'الفيوم مركز ابشواي - قرية ابو جنشو - بجوار مدرسة فاطمة الزهراء الاعدادية - منزل ربيع محمود', '300', '10', '2022-11-28', 'none', 'none', 'none', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(218, 4, '862', 'امل جرجس', '1272491118-1280120596', 'none', 9, NULL, NULL, 'الفيوم أبشواي مركز أبشواي', '650', '10', '2022-11-28', 'none', 'none', 'none', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(219, 4, '4580', 'اسراء محمد رأفت', '1154202366', 'none', 9, 28, NULL, 'الفيوم مركز ابشواي', '530', '10', '2022-11-28', 'none', 'none', 'none', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(220, 4, '1010050', 'مختار عبدالله محمدين', '1010050245', 'none', 9, 28, NULL, 'الفيوم مركز ابشواي -كحك بحري بجوار صيدليه موده', '250', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(221, 4, '816', 'انس محمود عويس', '1122787346', 'none', 9, 28, NULL, 'الفيوم /ابشواي/شكشوك', '40', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(222, 4, '2566', 'حماده سيد حمدالله', '1069099675', 'none', 9, NULL, NULL, 'الفيوم شارع ابو مدين بجوار المقابر ابوكساه', '250', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(223, 4, '564', 'ناجي خميس عبدالرازق', '1060028666', 'none', 9, NULL, NULL, 'الفيوم بحيره قارون عزبة عبدالقادر موسى', '150', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(224, 4, '11205043', 'none', '1120504305-111253991', 'none', 9, NULL, NULL, 'الفيوم يوسف الصديق قصر الجبالي منطقة التفتيش بجوار صيدليه دكتور عمرو ادريس', '250', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(225, 4, '553', 'نهاد طه عبدالعظيم', '1098066768-1090923356', 'none', 9, NULL, NULL, 'نزلة بشير بعد مدرسة الاورمان الخاصة ع طريق ثلاث بلد قبلها مركز الفيوم', '150', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(226, 4, '2658', 'ياسر ابراهيم ابو بكر', '1013019827-1009512139', 'none', 9, NULL, NULL, 'الشواشنة البريد', '450', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(227, 4, '1811', 'احمد علي احمد', '1006499646', 'none', 9, NULL, NULL, 'الفيوم قرية بن صالح بجوار التخريمة محل مشويات آدم', '150', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(228, 4, '2526', 'ابتسام رمضان', '1063718792-1099494890', 'none', 9, 28, NULL, 'العنوان الفيوم ابشواي في ابو جنشوا عند المطحن', '150', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(229, 4, '499', 'محمد سيد', '1019545472-1118855949', 'none', 9, 28, NULL, 'الفيوم مركز ابشواي قرية ذيد', '500', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(230, 4, '579', 'ايمان سعد', '1208675757', 'none', 9, NULL, NULL, 'زاويه الكرادسه - فيلا اللواء عبد الغفار - الفيوم,', '150', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(231, 4, '1065742', 'ابو ادم', '1065742132', 'none', 9, 31, NULL, 'الفيوم مركز سنورس مركز سنهور القبلية بجوار الاسعاف', '250', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(232, 4, '2522', 'ايمن فاروق محمد', '1008686360', 'none', 9, 28, NULL, 'ابشواي امام اوكازيون', '350', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(233, 4, '109650', 'محمد', '1096508197', 'none', 9, NULL, NULL, 'سنهور القبليه مركز علي صالح', '350', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(234, 4, '115151', 'محمد عشري', '1151512837', 'none', 9, 28, NULL, 'انا من ابشواي المنطقه اسمها الرمليه بجوار الجمعيه الخيريه', '150', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(235, 4, '53606', 'عاطف محمد اسحق', '1146441647', 'none', 9, 28, NULL, '‎محافظة الفيوم /مركز ابشواي /قريه كحك قبلي ‎الجامع الكبير', '649', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(236, 4, '1892', 'محمود رجب', '1023548943', 'none', 9, 28, NULL, 'القيوم ابشواي ش الجمهوريه المنشيه', '150', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(237, 4, '106178', 'احمد محمد رشدان', '1061784505-1125021291', 'none', 9, NULL, NULL, 'الفيوم - ابشواى - ابوكساه', '390', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(238, 4, '25064', 'يوسف عمر الكيلاني', '1095820130', 'none', 9, NULL, NULL, 'سنهور مدرسه عويس عليوه', '275', '10', '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(239, 4, '25183', 'عبدالله رزق', '1029472984', 'none', 9, 28, NULL, 'النصاريه', '200', '10', '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(240, 4, '25264', 'محمود ماهر محمود', '1091225868', 'none', 9, NULL, NULL, 'يمكن فتح الشحنة /2ق /محافظه الفيوم قريه بني صالح الفيوم', '200', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(241, 4, '24844', 'احمد السيد', '1064499478', 'none', 9, NULL, NULL, 'سنهور القبليه المفارق عند المسجد الكويتي', '285', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(242, 4, '80400', 'ابوخالد سليمان', '1003817175', 'none', 9, 28, NULL, 'مركز ابشواي ابشواي موقف الفيوم امام مركز مركز القاضي للاشاعات', '335', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:51', NULL, 0, NULL, 0, NULL),
(243, 4, 'FT23486', 'ايه محمد', '1063959390', 'none', 9, NULL, NULL, 'قريه سنهور القبليه بجوار فرع فودافون,FAIYUM GOVERNORATE', '530', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(244, 4, '25193', 'سعيد فكري محمد', '1030463943', 'none', 9, NULL, NULL, 'شكشوك', '285', '10', '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(245, 4, '16238', 'ايه', '1033675214', 'none', 9, NULL, NULL, 'يوسف الصديق', '4225', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(246, 4, '4098', 'احمد عبد التواب محمد', '1282404001', 'none', 9, NULL, NULL, 'النصاريه', '440', '10', '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(247, 4, 'DM3845', 'Mar Yam ~p~', '1553860890', 'none', 9, NULL, NULL, 'يوسف الصديق', '225', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(248, 4, '11119623', 'محمد حسن', '1111962340', 'none', 9, 28, NULL, 'ابشواي', '320', '10', '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(249, 4, '86987', 'محمد سالم', '1117204353', 'none', 9, NULL, NULL, 'سنهور', '865', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(250, 4, '1065', 'محمود جمال كمال', '1144421212', 'none', 9, NULL, NULL, 'سنهور البحريه', '470', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(251, 4, '226963600a148437b', 'محمد طنطاوي', '1060084500', 'none', 9, NULL, NULL, 'يوسف الصديق', '590', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(252, 4, '3020527', 'محمد ابراهيم', '1007582810', 'none', 9, NULL, NULL, 'ابو كساه', NULL, '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(253, 4, 'ADM0011', 'طارق صلاح عبد الفتاح', '1092354649', 'none', 9, NULL, NULL, 'شعلان', '25', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(254, 4, 'SP1001063505', 'العميد احمد ابو بكر تبع ايه', '1033379074', 'none', 9, NULL, NULL, 'قصر الجبالي', '50', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(255, 4, 'PRO15061', 'سيد عيد طه الفيوم الصوافى جنينه الساكت بجوار مسجد الساكت 01026989895', '1026989895', 'none', 9, NULL, NULL, 'شكره امام مدرسه شكره', '1354', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(256, 4, 'KE14447', 'ام احمد', '1223030573', 'none', 9, NULL, NULL, 'الفيوم النزله ش الوحدة البيطرية رقم 4', '500', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(257, 4, '283268', 'مصطفى فاروق', '01010149050\n -', 'none', 9, 28, NULL, 'العنوان /ابشواي بجوار مستشفى الهلال عند موقف الفيوم', '305', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(258, 4, '283110', 'الاسم مصطفى جوده', '01110776934\n -', 'none', 9, 28, NULL, 'مركز ابشواي - المنشيه عند المسجد الغربي', '270', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(259, 4, '1015868347', 'ا- سلمي', '1015868347', 'none', 9, NULL, NULL, 'إبشواي', '350', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(260, 4, 'PRO15411', 'احمد حسين', '1002366073', 'none', 9, NULL, NULL, 'العجميين', '214', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(261, 4, '285131', 'احمد كنزي', '01095974558\n 01095974558', 'none', 9, 28, NULL, 'الفسوم مركز ابشواي', '500', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(262, 4, '2001195621', 'Maha Saber', '1023141855', 'none', 9, NULL, NULL, 'الفيوم ابشوي ابو جنشو شارع الجلاء بجوار المطحن', '38', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(263, 4, '9900050335', 'محمد كمال عبد الجيد', '1000303756', 'none', 9, 28, NULL, 'الفيوم ابشواي', '230', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(264, 4, '286939', '/اشرف رمضان سيد', '01012656420\n -', 'none', 9, NULL, NULL, 'الفيوم مركز ابشوى', '1305', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(265, 4, '377309', 'Kholoud Hamdy', '1067679273', 'none', 9, NULL, NULL, 'الفيوم قريه فيدمين بجوار عين السيلين', '555', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(266, 4, '287944', 'امنية حمدي', '01007106409\n -', 'none', 9, NULL, NULL, 'مركز يوسف اصديق البلد اوتاه', '290', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(267, 4, '139454', 'شيرين محمد ابوزيد', '1002202027', 'none', 9, NULL, NULL, 'الفيوم السوار الشواشنه', '35', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(268, 4, 'Sl9997354', 'سيد ابو قادوس', '1008196063', 'none', 9, NULL, NULL, 'الضرب الأخضر منزل بدوى عبد الله', '40', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(269, 4, '19111', 'احمد هنداوي', '1024761314', 'none', 9, NULL, NULL, 'قرية شكشوك مركز ابشواى محافظة الفيوم', '35', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(270, 4, '136359', 'جيهان ابوليل', '1006969001', 'none', 9, 28, NULL, 'ابشواي مركز يوسف الصديق', '75', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(271, 4, '106186', 'محمد جمعه', '1004267731', 'none', 9, NULL, NULL, 'المشترك القبلي بجوار الكوبرى الغربي مركز يوسف الصديق الفيوم', '860', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(272, 4, 'B39', 'محمود عويس', '1002285350', 'none', 9, 28, NULL, 'الفيوم / ابشواي / قريه بلونه', '60', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(273, 4, 'BRf403', 'زياد وليد سيد سنوسي', '1010163947', 'none', 9, 28, NULL, 'ابشواي عند المطافي', '345', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(274, 4, 'MGR0002195', 'ساميه', '1284770566', 'none', 9, NULL, NULL, 'الفيوم /العنوان قريه محافظه الفيوم قرية تلات', '135', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(275, 4, 'WSL000985', 'حسن السيد', '1145165557', 'none', 9, 28, NULL, 'مركز ابشواي قرية حنا حبيب الفيوم', NULL, '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(276, 4, '200226890', 'سهاد عمار', '1007653992', 'none', 9, NULL, NULL, 'السنباط مركز الفيوم', '60', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(277, 4, 'N34132', 'حامد ابو حامد', '1020204465', 'none', 9, 31, NULL, 'الفيوم مركز سنورس سنهور القبليه طريق عبود', '75', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(278, 4, 'PRO14228', 'د / صفاء عبدالعزيز', '1097128310', 'none', 9, 28, NULL, 'العنوان الفيوم ابشواي الشارع الي قبل المستشفى العام', '45', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(279, 4, '127956', 'محمد إبراهيم', '1147605699', 'none', 9, 28, NULL, 'الفيوم ابشواي', '35', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(280, 4, '137583', 'محمد اشرف', '1144071763', 'none', 9, NULL, NULL, 'الفيوم\nمركز يوسف الصديق قرية الحامولي\nعزبت حمزاوي بجوار المقابر', NULL, '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(281, 4, '138125', 'شادي رمضان', '1064024546', 'none', 9, 31, NULL, 'سنورس_ مركز سنهور الفيوم', NULL, '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(282, 4, 'MGR0002175', 'خالد عمر ابوچليل', '1157443070', 'none', 9, NULL, NULL, 'مركز يوسف الصديق ، قرية كحك البحرى ، بجوار مركز الشباب', NULL, '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(283, 4, '138017', 'عبدالله زكريا احمد بدر', '1022857744', 'none', 9, NULL, NULL, 'الفيوم سنهور القبليه بجوار مسجد بدر', '450', '10', '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(284, 4, 'SO-1-13163', 'حسني محمد', '1027355715', 'none', 9, 28, NULL, 'ابشواي ابو جنشو بجوار مدرسه التجاره', '60', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:06:52', NULL, 0, NULL, 0, NULL),
(610, 4, 'SP1001032560', 'رشا العمدة', '1030095958', 'none', 9, NULL, NULL, 'الفيوم ، سنرو ، عزبة دكم ، فيلا العمدة محمد دكم', '75', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(611, 4, 'SP1001032807', 'فاطمه سيد', '1030328038', 'none', 9, 31, NULL, 'قرية السليين تبع مركز سنورس', '305', '10', '2022-11-28', 'none', 'none', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(612, 4, 'SP1001034326', 'شهد محمد', '1093555802', 'none', 9, 28, NULL, 'الفيوم - مركز ابشواي علي كوبري ابو جنشوا شارع بورسعيد امام سوبر ماركت مكه', '350', '10', '2022-11-28', 'none', 'none', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(613, 4, 'SP1001033563', 'اسامه عبدالناصر', '1022755744', 'none', 9, 28, NULL, 'الفيوم -مركز ابشواي - قرية ابوكساه -كوبري معبد -صيدلية دكتوره داليا احمد', NULL, '10', '2022-11-28', 'none', 'none', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(614, 4, 'NO103564', 'علاء عبود', '1012013854', 'none', 9, NULL, NULL, 'ابشواى مركز يوسف الصديق الفيوم', '655', '10', '2022-11-28', 'none', 'none', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(615, 4, 'P17099', 'شيماء محمد علي', '1003306003', 'none', 9, NULL, NULL, 'قرية تلات بجوار مسجد عمر بن الخطاب', '180', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(616, 4, '2221341', 'محمد أيوب', '1090141306', 'none', 9, 28, NULL, 'الفيوم ابشواي ابوجنشو', '185', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(617, 4, '2221343', 'حسنى أحمد عبدالعليم محمد', '٠١١١٠٢٧٧٧٢٤/٠١٠٠٣٧٤٧٧٨٢', 'none', 9, NULL, NULL, 'قرية السنباط مركز الفيوم بجوار المدرسة الابتدائية', '185', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(618, 4, 'N34452', 'وفاء', '1092073999', '1101624467', NULL, NULL, NULL, 'امام بنك الاهلي', '225', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(619, 4, 'MGR0000986', 'عصام علي', '1112287761', 'none', 9, NULL, NULL, 'الفيوم مركز يوسف الصديق مفارق قارون', '230', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(620, 4, 'BI101021', 'فاطمه خليفه', '1550601267', '1062201285', 9, NULL, NULL, 'سنهور القبليه بجوار فرن عبدالله دياب', '445', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(621, 4, 'pf854', 'محمود مجدي', '1090956460', 'none', 9, 28, NULL, 'الفيوم مركز ابشواي ابوكساه', NULL, '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(622, 4, '2287635c2b9dde5cf', 'احمد طه محمد عبدالعزيز', '1090569680', 'none', 9, NULL, NULL, 'الفيوم ابشواى العجميين بجوار مركز شباب العجميين', '2015', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(623, 4, '561186298', 'ياسمين سعيد', '1014304616', 'none', NULL, NULL, NULL, 'سنرو', '350', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(624, 4, 'ZX11164734', 'ياسمين القاضي', '1061511582', 'none', 9, 28, NULL, 'الفيوم مركز ابشواي بجوار مستشفي العام', '600', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(625, 4, '141881', 'ادهم حسين', '1020992906', 'none', NULL, NULL, NULL, 'نزلة بشير مركز الفيوم الفيوم', '210', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(626, 4, '561186292', 'محمود رجب', '1003215667', 'none', NULL, NULL, NULL, 'قرية الرواشدية', '300', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(627, 4, 'SE21652', 'أ\\ياسر', '1061410418', 'none', 9, NULL, NULL, 'الفيوم مركز يوسف الصديق قريها لحامولي', '464', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(628, 4, 'SE21689', 'الاسطى محمد الموردى', '1007057972', 'none', 9, 28, NULL, 'الفيوم ابشواي عند موقف مصر', '864', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(629, 4, '20094794', 'اخلاص عيد', '1012645248', 'none', NULL, NULL, NULL, 'الفيوم فديمين', '50', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(630, 4, 'SE21819', 'رجب جوده', '1009884380', 'none', 9, 28, NULL, 'الفيوم ابشواي الفيوم', '464', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(631, 4, '20617', 'محمد عبد الناصر', '1011219218', 'none', NULL, NULL, NULL, 'قصر بياض بجوار مدرسه تيو نصار الاعداديه', '500', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(632, 4, '21500', 'احمد عادل اسماعيل', '1002574220', 'none', 9, NULL, NULL, 'سنهور القبليه', '425', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(633, 4, '21654', 'محمد حجاج', '1027150699', 'none', 9, 28, NULL, 'ابشواي  العجميين', '250', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'R2S', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(634, 4, '*OTX2045904*', 'سيد محمد', '1013047784', 'none', 9, 28, NULL, 'الفيوم ابشواي العجين مقبل', '400', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(635, 4, '*OTX2045535*', 'كريم عبد التواب', '1026685447', 'none', NULL, NULL, NULL, 'الفيوم زاوية الكرواسة', NULL, '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(636, 4, '2200055148', 'محمود عشري مصطفى', '1090103380', 'none', 9, 28, NULL, '01090103380 الفيوم مركز ابشواي امام بنك القاهره', '460', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(637, 4, 'SP1001036396', 'احمد عجمي خليفه', '01068888263+01022221209', 'none', NULL, NULL, NULL, 'اخره الخميس-----الفيوم ابشواى بجوار الكنيسه وكافتيريا وسط البلد أمام معرض الطوفان للاجهزه الكهربائيه', '860', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(638, 4, 'SP1001035927', 'كريم جمعة', '1101368510', 'none', 9, 28, NULL, 'الفيوم . ابشواي . شرف الدين', '400', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(639, 4, 'SP1001035669', 'اماني عبدالرحمن', '1027510559', 'none', 9, 28, NULL, 'كفر عمرو ابشواي', '380', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(640, 4, '279252', 'Mahmoud Magdy Taha', '01090956460\n-', 'none', 9, 28, NULL, 'الفيوم ابوكساه مركز ابشواي شارع المصليه بجوار مطبعه ابو كساه منزل محمود مجدي', NULL, '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(641, 4, '284685', 'جهاد علي عوضي', '1004482567', 'none', 9, 28, NULL, 'الفيوم ابشواي الفاروقه بجوار الكنيسه', '65', '10', '2022-11-28', 'none', 'السماح بالمعينه', 'none', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(642, 4, 'R128796', 'عبدالغني ابو الحارث', '103255181', 'none', 9, NULL, NULL, 'العنون: الفيوم مركز سنهور عزبة ابوسلام بجوار المقابر', '250', '10', '2022-11-28', 'none', 'none', 'none', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(643, 4, 'MGR0001037', 'عبدالله عبد السلام', '1013181722', 'none', 9, NULL, NULL, 'الفيوم مركذ يوسف الصديق قريه تونس', '220', '10', '2022-11-28', 'none', 'none', 'none', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(644, 4, 't6452704', 'احمد سيد مصطفى', '1127342003', 'none', 9, NULL, NULL, 'الفيوم \nمركز يوسف الصديق عزبة الشيمي الوحده الوحده الصحيه تبع الشيمي', '230', '10', '2022-11-28', 'none', 'none', 'none', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(645, 4, 'KE12329', 'وليد صلاح عبدالعظيم', '1156521417', 'none', 9, NULL, NULL, 'الفيوم مركز يوسف الصديق قريه حناحبيب', '235', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(646, 4, 'KE12290', 'مصطفى حميده', '1094954375', 'none', 9, 28, NULL, 'الفيوم مركز الشواشنه بعد ابشواي', '240', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(647, 4, 'SO-1-13148', 'محمد علي', '201010000000', 'none', 9, NULL, NULL, 'الفيوم . بني صالح . بجوار مكتب البريد, الفيوم, مصر', '250', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(648, 4, 'KE12397', 'الفيوم', '1018625230', 'none', 11, 31, NULL, 'الفيوم مركز سنورس قريه فديمين', '440', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(649, 4, 'R129417', 'امجد كمال موسي', '1011005367', 'none', 9, 31, NULL, 'العنوان..محافظه الفيوم.مركز سنورس..قريه سنهور القبليه بجوار مركز شرطه سنهور القبليه', '480', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(650, 4, '279321', 'صيدلية ويليم الجديدة', '01222944844\n-', 'none', 9, NULL, NULL, 'سنهور القبلية الفيوم بجوار كنيسة العذراء بسنهور', '508', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(651, 4, '2276635ecb578af2f', 'ساره السيد محمد', '1066521796', 'none', NULL, NULL, NULL, 'محافظة الفيوم ابشواى عند موقف مصر', '590', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(652, 4, 'P17222', 'هاجر مؤمن', '1018650719', 'none', 9, NULL, NULL, 'سنهور القبليه عزبت البحيري', '180', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(653, 4, '2221612', 'طلحة فتحي علي', '01125687287 \\\\ 01023955166', 'none', NULL, NULL, NULL, 'قرية سنرو القبلية _الطريق السياحي أمام نقطة الشرطة والبريد الفيوم', '185', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(654, 4, '129125', 'شعبان صلاح محمد عبد المقصود', '1027335544', 'none', 9, 28, NULL, 'الفيوم ابشواي الحمولي مركز يوسف الصديق', '435', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:16', NULL, 0, NULL, 0, NULL),
(655, 4, 'fa957', 'ممدوح علي جنيدي علي', '1016236808', 'none', 9, 28, NULL, 'الفيوم مركز ابشواي قريه سترو', '285', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(656, 4, '49578', 'محمد اسماعيل', '1097506004', 'none', 9, NULL, NULL, 'يوسف الصديق تونس', '460', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(657, 4, 'MGR0001039', 'احمد محمد', '1032703563', 'none', 9, NULL, NULL, 'قرية شكشوك عزبة الياس بجوار مسجد الدوار', '315', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(658, 4, '12332', 'عبدالرحمن تامر عجمي', '1091969427', 'none', 9, 28, NULL, 'ابشواي.الفيوم.شارع الجمهورية امام مسجد الشيخ عبد العليم', '35', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(659, 4, '129305', 'احمد علي', '1273753757', 'none', 9, 28, NULL, 'لفيوم ابشواي: النصاريه: ع الاربعين', '250', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(660, 4, '*OTX2047315*', 'اسامه حسين عبد الرسول', '1126253640', 'none', 9, 28, NULL, 'ابشواي الحموي ،الفيوم', '250', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(661, 4, 'R2354472', 'سمر ربيع عبد الحليم', '1030158872', 'none', 9, 28, NULL, 'الفيوم -ابشواي-في ابو جنشو', '300', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(662, 4, '179128', 'محمود عبد الضوار', '1154179128', 'none', NULL, NULL, NULL, 'عند قهوه حسن', '260', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'شهبندر', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(663, 4, '18135', 'محمد رمضان', '1090225873', 'none', 9, NULL, NULL, 'مفارق قارون محل الهواري مركز يوسف الصديق', '150', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(664, 4, '2001173259', 'يوسف محمود', '1270108588', 'none', 9, NULL, NULL, 'أمام الثانوية العامة بجوار المجلس المحلي العجميين', '195', '10', '2022-11-28', 'none', 'none', 'ضروري جداا', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(665, 4, 'SP1001038256', 'محمد', '1068565436 1018864362', 'none', 9, 28, NULL, 'ابشواي عند مواف مصر عند قهوة الشرنوبي', '230', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(666, 4, 'SP1001038306', 'احمد الديب', '1154808577', 'none', 9, 28, NULL, 'الفيوم، ابشواي، كريت طبهار', '230', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(667, 4, '2001173244', 'Hanan Mohamed', '1120230590', 'none', 9, NULL, NULL, 'يوسف الصديق صيدليه الشلال', '747', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(668, 4, 'ZX5989522', 'عمرو الفار', '1064046350', 'none', NULL, NULL, NULL, 'قرية أبو كساة بجوار جامع المعبد', NULL, '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(669, 4, 'P17343', 'اسراء محمد', '1023870508', 'none', 9, NULL, NULL, 'النزله جنب مسجد الرحمه', '160', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(670, 4, '2221858', 'فاطمة رزق علي', '1114688055 / 01063873185', 'none', NULL, NULL, NULL, 'قرية الشهيد أحمد رمضان - مركز أبشواى - محافظة الفيوم', '185', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(671, 4, '129884', 'احمد الروبي', '1147639711', 'none', 9, 28, NULL, 'الفيوم مركز ابشواي', '200', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(672, 4, '280565', 'اسلام الشافعي', '01063004001\n-', 'none', 9, 28, NULL, 'ابشواي الفيوم', '260', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(673, 4, '274478', 'رمضان رجب محمد', '01008961999\n01557799741', 'none', 9, NULL, NULL, 'سنهور القبليه الفيوم', '450', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(674, 4, '129545', 'محمود صبري', '1159235523', 'none', 9, 28, NULL, 'مركز ابشواي', '265', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(675, 4, '2221844', 'محمد حسين عبدالقادر', '1018831899', 'none', 9, NULL, NULL, 'الفيومبني صالح_امام مدرسة فاطمة فتحي الابتدائيه', '285', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(676, 4, 'ZX11164865', 'سلمي', '1068759702', 'none', NULL, NULL, NULL, 'الفيوم الشواشنة', '295', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(677, 4, 'MGR0001104', 'لإسم الحاج محمود رجب ابراهيم', '1004665220', 'none', NULL, NULL, NULL, 'الفيوم قريه زاويه الكرادسه مركز الفيوم بجوار البنك الزراعي أعلي صيدليه دكتوره ولاء محمد انور', '335', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(678, 4, '8657', 'محمود محمد', '1098985461', 'none', 9, 28, NULL, 'الفيوم مركز ابشواي قصر الجبالي', '300', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(679, 4, '1165085', 'محمد عيد', '1010861041', 'none', 9, 28, NULL, 'ابشواي الفيوم', '620', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(680, 4, 'P17353', 'مصطفى عبدالباقى', '1069930330', 'none', NULL, NULL, NULL, 'مركز الفيوم قريه تلات بجوار الوحدة المحليه ونقطه الشرطه', '660', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(681, 4, 'R129452', 'احمد بكري رمضان', '1120096705', 'none', NULL, NULL, NULL, 'محافظة الفيوم مركز ابشواى قرية ابوشنب مخبز وحلوانى ليلة القدر', '265', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(682, 4, 'R129616', 'محمود سيد رمضان', '1010787639', 'none', 9, 28, NULL, 'الفيوم ابشواي شارع الجلاء عند المطافي', '265', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(683, 4, 'SE22041', 'ا\\وليد', '1101401265', 'none', 9, 28, NULL, 'الفيوم اشواي مكرز ابشواي مسجد الشيخ عبدالعليم', '454', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(684, 4, '129590', 'ابانوب يوساب', '1064467710', 'none', 9, 28, NULL, 'الفيوم مركز ابشواي شارع الجمهوريه', '500', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(685, 4, '2221832', 'خالد علي ع الرحمن', '1066260851', 'none', 9, NULL, NULL, 'الفيوم/مركز يوسف الصديق/قارون/عزبه الشيمي', '185', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(686, 4, '2221822', 'محمد عنتر محمود', '1004021748', '1095974558', 9, 28, NULL, 'مركز ابشواي محافظه الفيوم', '305', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(687, 4, '*OTX2044723*', 'محمود عشري مصطفى', '1090103380', 'none', 9, 28, NULL, 'مركز ابشواي امام بنك القاهره', '180', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(688, 4, '*OTX2048237*', 'رشا ناصر احمد عبد الجواد', '1012075779', 'none', 9, NULL, NULL, 'الفيوم ابشواى كحك بحرى', '670', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(689, 4, '*OTX2048162*', 'عمر هاشم مفتاح', '1005053352', 'none', NULL, NULL, NULL, 'محافظة الفيوم/مركز أبشواى/طريق أبشواى- زيد - بعد مدرسة أبشواى الإعدادية بنين - كوبرى العادلي', '400', '10', '2022-11-28', 'none', 'none', 'none', 'اوتكس', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(690, 4, '*OTX2048019*', 'اسماعيل امين', '1224559616', 'none', 9, 28, NULL, 'محافظه الفيوم مركز ابشواي قريه العجميين', '750', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(691, 4, '*OTX2046035*', 'علي عبد السلام', '1096000803', 'none', NULL, NULL, NULL, 'الفيوم مركز ابشواى شارع المستشفى بجوار قهوة قطر الندى', '180', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(692, 4, '*OTX2046029*', 'ابراهيم', '1021577789', 'none', 9, 28, NULL, 'ابشواي', '180', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(693, 4, '1154127', 'مصطفي احمد سعد', '1069510239', 'none', 9, 28, NULL, 'ابشواي البنك الاهلي', '220', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(694, 4, '1154453', 'خالد سالم', '1117597859/1154791142', 'none', 9, 28, NULL, 'ابشواي', '410', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(695, 4, '1154442', 'غاده', '1090746558', 'none', 9, 28, NULL, 'ابشواي محل المدينه المنوره للذهب بجوار المحكمه', '1120', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(696, 4, '54915', 'شيماء سعيد', '1062206643', 'none', 9, 28, NULL, 'ابشواي امام امن الدوله', '295', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(697, 4, '54928', 'وفاء سعيد', '1030657243', 'none', 9, NULL, NULL, 'ابو كساه منزل محمد صلاح', '300', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(698, 4, 'SP1001040782', 'مصطفي حنفي محمود', '1273771771', 'none', 9, 28, NULL, 'ابشواي', '65', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(699, 4, '407614', 'كرم احمد علي', '1018531589', 'none', 9, 28, NULL, 'ابشواي بحري الجامع الكبير', '450', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL);
INSERT INTO `orders` (`id`, `id_company`, `id_police`, `name_client`, `phone`, `phone2`, `center_id`, `agent_id`, `delegate_id`, `address`, `cost`, `salary_charge`, `date`, `notes`, `special_intructions`, `name_product`, `sender`, `weghit`, `open`, `status_id`, `cause_id`, `order_locate`, `gps_delivered`, `identy_number`, `created_at`, `updated_at`, `delegate_supply`, `delegate_supply_date`, `company_supply`, `company_supply_date`) VALUES
(700, 4, 'SP1001041035', 'نبيل سعد', '1002267710', 'none', 9, NULL, NULL, 'يوسف الصديق اول المركز عند مدرسه امين سعد', '510', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(701, 4, '73066', 'مصطفي محمد', '1022294555', 'none', 9, NULL, NULL, 'يوسف الصديق', '510', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(702, 4, 'SP1001040808', 'محمد ربيع', '1022975509', 'none', 9, NULL, NULL, 'سنهور القبليه المفارق', '400', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(703, 4, '2222138', 'أشرف عصام السيد محمد', '1200042063', 'none', 9, 28, NULL, 'طبهار بجوار مسجد العمدة /ابشواي /الفيوم', '165', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(704, 4, 'P17407', 'ام معاذ', '1004884506', 'none', 9, NULL, NULL, 'يوسف الصديق تونس السياحيه.', '180', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(705, 4, '142131', 'عبدالله ربيع محمود', '1226077012', 'none', 9, 28, NULL, 'الفيوم مركز ابشواي العجميين', '210', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(706, 4, 'P17449', 'احمدسيد رجب', '1096164144', 'none', 9, NULL, NULL, 'مركز سنهورالقبليه بجوار موقف مصر', '230', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(707, 4, '13121', 'محمود عبد الستار', '1009336402', 'none', 9, 28, NULL, 'ة الفيوم مركز ابشواي قاريه ابو دنقاش', '235', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(708, 4, '130270', 'حسام', '1124828115', 'none', 9, 28, NULL, 'ابشواي صميدى صالح', '250', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(709, 4, '142006', 'عمر محمد على', '1013988663', 'none', 9, NULL, NULL, 'تونس يوسف الصديق الفيوم', '200', '10', '2022-11-28', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(710, 4, 'R130762', 'حسام', '1124828115', 'none', 9, 28, NULL, 'ابشواي صميدى صالح', '250', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(711, 4, '12866', 'خالد قاسم', '1000921850', 'none', 9, 28, NULL, 'لفيوم مركز ابشواي قرية الطحاوي الطريق السياحي قبل ابشواي', '240', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(712, 4, 'KE13490', 'عبد الرحمن ايوب', '1025579690', 'none', 9, NULL, NULL, 'الفيوم فيديمين موقف المنجايه منزل استاذ ايوب الشيمى', '245', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(713, 4, 'P17498', 'مصطفى على الزغيبى', '1092531662', 'none', 9, NULL, NULL, 'سنهور القبلية', '250', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(714, 4, 'KE13299', 'محمد حجاج بكري', '1027150699', 'none', 9, 28, NULL, 'مركز ابشواي العجمين', '260', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(715, 4, 'MGR0001203', 'الشيخ حسني بوعزيه العبيدي', '1155944596', 'none', 9, NULL, NULL, 'الفيوم مركزسنهور عزبت وليده قبل ما يدخل البلد يكلمني', '275', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(716, 4, 'MGR0001152', 'حسين عبدالعزيز.', '1006564115', 'none', NULL, NULL, NULL, 'الفيوم ابشواى. قريه شرف الدين', '295', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(717, 4, '142144', 'نسمه حمدى محمد', '1007920614', 'none', 9, NULL, NULL, 'الفيوم ابشواى الشواشنه بجوار محل المحمديه', '335', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(718, 4, 'F39318', 'سامح شوقي السيد علي', '1061765566', 'none', NULL, NULL, NULL, 'الفيوم قريه فيد يمين بجوار جمعيه الشاي', '335', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(719, 4, 'MGR0001261', 'معاذ فتحي', '1115844530', 'none', NULL, NULL, NULL, 'قرية النصارية بجوار مدرسة عمر الخولي للتعليم الأساسي', '315', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(720, 4, 'khb59', 'محمد حجاج', '1069766692', 'none', 9, NULL, NULL, 'قرية السنباط مركز الفيوم وممكن استلم ف الفيوم نفسها', '475', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(721, 4, '130087', 'عمر نادي', '1032636872', 'none', 9, NULL, NULL, 'كحك بحري', '220', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(722, 4, '130396', 'احمد عيد محمود منصور', '1030456074', 'none', NULL, NULL, NULL, 'الفيوم مركزابشوي سنرو البحريه', '435', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(723, 4, '2707322', 'منار عاشور', '1033541588', 'none', NULL, NULL, NULL, 'قرية عين السيلين قرية سياحية امام محل كشري عاشور', '1065', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(724, 4, 'PNT000374', 'محمد صدقي', 'none', 'none', 9, NULL, NULL, 'الفيوم قرية تونس مركز يوسف الصديق فيلا العمرى', '9800', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(725, 4, 'R130556', 'عبد الرحمن ايوب الشيمي', '1025579690', 'none', 9, NULL, NULL, 'فيديمين موقف المنجايه الفيوم', '240', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(726, 4, '13613', 'مصطفى سمير', '1029686661', 'none', NULL, NULL, NULL, 'الفيوم دخلت تلات يا باشا هيسال على مصنع المراتب ايه اللي في تلات', '35', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(727, 4, '3005112', 'حمدي سيد كامل', '1015699156', 'none', 9, 28, NULL, 'مركز ابشواي قريه شكشوك عزبه سليمان', '700', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(728, 4, '*OTX2049888*', 'فاطمة عبد السلام', '1067115939', 'none', 9, NULL, NULL, 'الفيوم سنهور القبلية عزبة عقيلة', '4150', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(729, 4, '*OTX2048907*', 'محمد رفاعي عبد العزيز', '0 100 582 0068', 'none', 9, 31, NULL, 'الفيوم سنورس سنهور القبليه بجوار مركز الشرطه', '500', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(730, 4, '9899389', 'كريم محمد', '1098993892', 'none', 9, NULL, NULL, 'ابو كساه', '480', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(731, 4, '295979', 'ايه جمال', '1129597996-1278367139', 'none', 9, NULL, NULL, 'النزله', '450', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(732, 4, '117600', 'اسلام', '1015561460-1029494863', 'none', NULL, NULL, NULL, 'سنروا', '810', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(733, 4, '6716385', 'بسمه محمد', '1067163857', 'none', 9, NULL, NULL, 'الشواشنه', '300', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(734, 4, '83900', 'باسم عويس عبد السميع', '1091782534', 'none', 9, NULL, NULL, 'يوسف الصديق', '60', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(735, 4, '14551', 'محمد السيد صميده', '1068766197', 'none', 9, NULL, NULL, 'ابو كساه', '450', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(736, 4, '68885', 'دهب محمود', '1142357447', 'none', NULL, NULL, NULL, 'ابو لطيعه', '200', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(737, 4, '1093160326', 'ا.عاطف عويس', '1093160326', 'none', 9, NULL, NULL, 'سنهور القبليه سوق البيض', '235', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(738, 4, '971573', 'محمود حمدي', '1006133019', 'none', 9, NULL, NULL, 'يوسف الصديق الشواشنه', '400', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(739, 4, '1153844', 'استاذ محمد', '1114512115', 'none', 9, NULL, NULL, 'العجميين', '100', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(740, 4, '2001174235', 'محمود عبدالجواد', '1128555985', 'none', NULL, NULL, NULL, 'حناحبيب شارع مسجد الرحمه', '1998', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(741, 4, '1023838696', 'ممدوح', '1023838696', 'none', 9, NULL, NULL, 'فيدميين', '280', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(742, 4, '2001173966', 'عائشة عدلي', '1023542468', 'none', 9, NULL, NULL, 'منزل الشيخ عدلي قرية ذو الفقار مركز يوسف الصديق', '475', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(743, 4, '2001174419', 'محمود عبدالجواد', '1128555985', 'none', NULL, NULL, NULL, 'حناحبيب شارع مسجد الرحمه', '3060', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(744, 4, '22778', 'جمعه', '1060131850', 'none', 9, NULL, NULL, 'عزبه بهنس تبع المندره', '200', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(745, 4, '9512121264', 'احمد حماده حمدي', '1095121264', 'none', 9, NULL, NULL, 'كفر عبود الطماوي', '700', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(746, 4, '94872730', 'كوكو ماجدي', '1094872730-1559103873', 'none', 9, NULL, NULL, 'النزله بجوار كنيسه الامير تادرس الشطبي', '700', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(747, 4, '1019174393', 'مصطفي رجب', '1019174393', 'none', 9, NULL, NULL, 'سنهور القبليه عند كنسيه السيده مريم', '250', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:17', NULL, 0, NULL, 0, NULL),
(748, 4, '375444', 'ايمان محمد عبدالفتاح احمد', '1064562277', 'none', 9, NULL, NULL, 'شارع المعهد الديني المشرك قبلي مركز يوسف الصديق', '435', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(749, 4, '2001175576', 'Hanan mohamed', '1010904247', 'none', 9, NULL, NULL, 'الشواشنه مشرك قبلي', '876', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(750, 4, '69001', 'ام مريم عباس', '01097537368+', 'none', 9, 28, NULL, 'الفيوم ابشواي ابوجنشو بجوار موقف النزله', '200', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(751, 4, '131775', 'خالد جمال عباس', '1010666767', 'none', 9, 28, NULL, 'الفيوم ابشواي شارع التحرير', '235', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(752, 4, '131093', 'الاسم تامر رمضان امام شعيب', '1064726056', 'none', 9, NULL, NULL, 'الفيوم قريه سليمان الشيخ سعد المعهد الديني الازهر فيدميين', '245', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(753, 4, 'ST07661', 'حازم ابراهيم', '1099860430', 'none', 9, 28, NULL, 'الفيوم مركز ابشواي قرية ابو شنب', '255', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(754, 4, 'gm444', 'حسين', '1015520302', 'none', NULL, NULL, NULL, 'الفيوم ابشواى بجوار الوحده المحليه', '140', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(755, 4, '2222743', 'احمد صلاح عبد الغفار', '1032460070', 'none', 9, 28, NULL, 'الفيوم مركز ابشواي كفر عبود بجوار البوسطه', '285', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(756, 4, 'PRO15141', 'لبني', '1090191906', 'none', 9, 28, NULL, 'العنوان الفيوم ابشواي شارع الجمهوريه بجوار البريد', '404', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(757, 4, '102853', 'شهد محمود', '1115248463', 'none', 9, NULL, NULL, 'سنهور القبليه-البوابه عند مسجد فوده بيتو الاستاذ محمود ذكي', '430', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(758, 4, '102786', 'اسراء حمدى', '1092554099', 'none', 9, NULL, NULL, 'فيديمين الفيوم عاند سوبر ماركت ابو شادى', '550', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(759, 4, '389958', 'fatmaelgammal87', '1067781487', 'none', 9, NULL, NULL, 'الفيوم بني صالح فيلا الحاج زين علي صالح', '714', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(760, 4, '131859', 'محمد ناصر', '1018723366', 'none', 9, 28, NULL, 'الفيوم مركز ابشواي عند المطافى', '35', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(761, 4, '283173', 'احمد محمد', '01008786564\n -', 'none', 9, NULL, NULL, 'الفيوم تونس مركز يوسف الصديق', '1535', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(762, 4, '131399', 'عبدالله احمد عجمي', '1076326741', 'none', NULL, NULL, NULL, 'الفيوم ابشواى موقف ابوجنشو', '245', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(763, 4, '283098', 'عبده هاشم', '01065972432\n -', 'none', 9, 31, NULL, 'الفيوم قريه التوفيقيه بجوار المسجد الكبير- مركز سنورس -بيت عبده هاشم - بقرب من صيدليه', '270', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(764, 4, 'P17708', 'شيماء', '1004212365', 'none', NULL, NULL, NULL, 'باحيرت.قاروان.عازبت.عبد.السلام.', '260', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(765, 4, '131856', 'محمد صلاح رجب', '1032019967', 'none', NULL, NULL, NULL, 'الفيوم ابشواى بجوار موقف مصر', '290', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(766, 4, '102854', 'دنيا ناصر', '1010574946', 'none', 9, NULL, NULL, 'الشواشنه امام فرع اتصالات', '245', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(767, 4, 'MGR0000409', 'طارق صالح', '1115803211', 'none', 9, NULL, NULL, 'الفيوم ابشواى شارع الجمهورية', '370', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(768, 4, '21617', 'محمد عبد الناصر', '1011219218', 'none', NULL, NULL, NULL, 'قصر بياض', '500', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(769, 4, '20641', 'محمود بدوي علي', '1126833404', 'none', NULL, NULL, NULL, 'القوات المسلحه', '280', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(770, 4, 'R2356818', 'عيد محمد', '1068181325', 'none', 9, 28, NULL, 'مركز ابشواي شارع الجمهوريه بجوار المطافي', '430', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(771, 4, '*OTX2050446*', 'احمد العمري', '1011114247', 'none', 9, NULL, NULL, 'الفيوم مركز ابشوي بجوار البنك الاهلي', '250', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(772, 4, '30269362', 'علي', '1030269362', 'none', NULL, NULL, NULL, 'الؤلوه قريه منشيه السادات المنزل باسم علي سليمان عند كوبري العرب', '700', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(773, 4, '69763992', 'بدون اسم', '1069763992', 'none', 9, NULL, NULL, 'قصر الجبالي', '130', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(774, 4, '1155689', 'فاعل خير', '1001214135', 'none', NULL, NULL, NULL, 'ش الحمهوريه بجوار مكتب البريد', '300', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(775, 4, '1155385', 'احمد مصطفي', '1066907892', 'none', 9, 28, NULL, 'ابشواي ابو جنشو ش مدرسه ابو جنشو التجاريه', '150', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(776, 4, '2001176191', 'يوسف محمود', '1270108588', 'none', NULL, NULL, NULL, 'أمام الثانوية العامة بجوار المجلس المحلي', '384', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(777, 4, '20060993', 'احمد السيد', '1008123447', 'none', 9, NULL, NULL, 'محافظه الفيوم مركز يوسف الصديق', '725', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(778, 4, '13942', 'اسلام محسن', '1099128989', 'none', 9, NULL, NULL, 'قريه بني صالح بجوار المقابر', '240', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(779, 4, '14184', 'محمد حسن عويس عبد الباقي', '1026469628', 'none', 9, NULL, NULL, 'الفيوم مركز سنهور قريه فيد يمين الطريق السياحي محطه ابو عزت منزل المستشار حسن عويس عبد الباقي', '235', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(780, 4, '22576364dcd0c4e2e', 'ايه فتحي', '1008363022', 'none', 9, 28, NULL, 'الفيوم مركز ابشواي النزله', '1035', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(781, 4, '20058828', 'نجلاء احمد', '1028758076', 'none', 9, 28, NULL, 'الفيوم ابشواي ابو حنشو ش الجلاء', '195', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(782, 4, 'MGR0001429', 'حنا حبيب', '1117830518', 'none', 9, 28, NULL, 'مركز ابشواي', '220', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(783, 4, '103432', 'Nehal Fathy', '0 102 291 5328', 'none', NULL, NULL, NULL, 'Doctor Mohamed Hussein Street 5 شارع الدكتور محمد حسين', '235', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(784, 4, '15037', 'محمود رمضان', '1067858357', 'none', 9, NULL, NULL, 'مركز يوسف الصديق الشوشنه بجوار مركز الشوشنه', '240', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(785, 4, 'ZX2422443', 'حماده شعبان', '1151862636', 'none', NULL, NULL, NULL, 'الفيوم قرية الشيخ فضل بجوار الوحده الصحيه', '265', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(786, 4, 'L003407', 'علياء', '1004504409', 'none', NULL, NULL, NULL, 'عند الرواشية', '300', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(787, 4, 'MGR0001406', 'عبدالله أدريس', '1092573590', 'none', 9, 28, NULL, 'الفيوم &#x2F;ابشواي &#x2F;المشرم قبلي محل ادريس 2', '320', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(788, 4, 'MGR0001475', 'شعبان.بركات', '1002230630', 'none', 9, 28, NULL, 'الفيوم ابشواي احنا ابو جنشو شارع الزاويه', '335', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(789, 4, 'Sl14122064', 'حسين', '1013511001', 'none', 9, NULL, NULL, 'محافظه الفيوم مركز يوسف الصديق بحيره قارون قريه تونس', '375', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(790, 4, '284248', 'محمود حمدي السيد علي', '01000081713\n -', 'none', 9, 28, NULL, 'الفيوم مركز ابشواي الفاروقه', '640', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(791, 4, '227263663fc14c58a', 'مصطفي محمد محمود', '1126908793', 'none', 9, 28, NULL, 'الفيوم مركز ابشواي. 01126908793', '800', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(792, 4, '20059201', 'اسلام داوود', '1007427477', 'none', 9, 28, NULL, 'الفيوم ابشواي سنرو القبيلة', '1375', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(793, 4, '820697', 'نوران علي', '1004482567', 'none', 9, 28, NULL, 'ابشواي الفاروقه بجوار الكنيسه', '1908', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(794, 4, '142197', 'حامد الفاروق', '1002492222', 'none', NULL, NULL, NULL, 'الفيوم ابشواى', '200', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(795, 4, '63694', 'عبير السيد', '1015526109', 'none', NULL, NULL, NULL, 'قرية النصارية', '1505', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(796, 4, '222163652e2ce38b2', 'عمار محمد', '1060136057', 'none', 9, 31, NULL, 'الفيوم مركز سنورس قريه فيديمين موقف علي عامر', '2405', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(797, 4, 'ZX2422444', 'سمير رمضان', '1008309519', 'none', 9, NULL, NULL, 'الفيوم شكشوك ابواي', NULL, NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(798, 4, '*OTX2051502*', 'عبدو السيد', '1004570875', 'none', 9, NULL, NULL, 'الفيوم سنهور القبليه', '250', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(799, 4, 'SP1001046544', 'عادل عبد العليم حسين', '1006884883', 'none', 9, NULL, NULL, 'يوسف الصديق', '680', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(800, 4, 'RO1315', 'حسناء احمد احمد', '1068267485', 'none', NULL, NULL, NULL, 'المندرة الكوبري القديم', '395', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(801, 4, 'Sh156456', 'الاسم كريم', '1061694107', 'none', 9, NULL, NULL, 'العنوان الفيوم ا فيدمين شارع الطواحين', '585', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(802, 4, '132098', 'شعبان بركات', '1002230630', 'none', 9, 28, NULL, 'العنوان الفيوم ابشواي ابو ونشو شارع الزاويه', '670', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(803, 4, 't6452774', 'عائشة محمد', '1016785363', 'none', 9, 28, NULL, 'الفيوم /ابشواي\n \n بس ممكن لما المندوب ييجي هحاول اكون في مكان معروف يعني', '230', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(804, 4, 'ky15437', 'سلطان ممدوح', '1068138912', 'none', 9, NULL, NULL, 'الفيوم - قرية السليين نادي الهضبة بجوار البنك الزراعي', '490', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(805, 4, '132342', 'احمد جاد الله', '1065458487', 'none', 9, NULL, NULL, 'قرية كحك بحري الفيوم', '250', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(806, 4, 'R132383', 'احمد جمال', '1095334042', 'none', 9, NULL, NULL, 'مركز يوسف الصديق قريه الجندي', '480', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(807, 4, '69836', 'رضا عبد الناصر أحمد', '1094154233', 'none', 9, NULL, NULL, 'يوسف الصديق كحك بحري', '345', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(808, 4, 'FT34034', 'شيماء اسحاق', '1018480211', 'none', 9, NULL, NULL, 'الفيوم مركز سنهور', '775', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(809, 4, 'KE15378', 'محمد سيد فاروق', '1067536973', 'none', NULL, NULL, NULL, 'ابشواى', '250', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(810, 4, 'R132363', 'سمر عاشور', '1021297537', 'none', 9, NULL, NULL, 'قريه المندره', '480', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(811, 4, '*OTX2053588*', 'ا/ شيماء', '1064158898', 'none', 9, NULL, NULL, 'الفيوم مركز ابشاي كحك بحري بجوار صيدليه مودة', '6595', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(812, 4, '77978', 'اسماء', '1060783700', 'none', 9, NULL, NULL, 'سنهور القبليه عند مسجد موسي', '200', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(813, 4, '1060796936', 'حسن اسماعيل يوسف', '1064632466-1060796936', 'none', 9, NULL, NULL, 'يوسف الصديق عزبة عفيفي', '250', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(814, 4, '2268', 'ام مصطفي', '1030748492', 'none', 9, NULL, NULL, 'كفر عبود بجوار فيلا الامير', '50', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(815, 4, '1895', 'الاسم محمد يوسف', '1101624486', 'none', 9, NULL, NULL, 'يوسف الصديق عزبه عفيفي بجوار الجامع', '50', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(816, 4, '1110376811', 'انس عشري', '1110376811', 'none', 9, NULL, NULL, 'سنهور القبليه وليده', '150', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(817, 4, '347', 'محمود شعبات', '1201481996', 'none', 9, NULL, NULL, 'طبهار بجوار المدرسه الاعداديه', '350', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(818, 4, '4061', 'ا/علاء عطيه', '1029482532', 'none', 9, NULL, NULL, 'يوسف الصديق', '270', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(819, 4, '2194', 'الاسم/خالد ناصر الرزني', '1005560520', 'none', 9, 28, NULL, 'حنين اول بيت بعد كوبري حنين ابشواي', '150', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(820, 4, '1226880806', 'مني مصطفي المغربي', '1226880806', 'none', 9, NULL, NULL, 'قريه تونس', '740', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(821, 4, '1156021', 'جنه علي', '1011619035', 'none', 9, NULL, NULL, 'سنهور القبليه', '120', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(822, 4, '772', 'رجب', '1008628174', 'none', 9, 28, NULL, 'ابشواي مسجد الشيخ عبدالعليم', '700', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(823, 4, '103243', 'انس عشري', '1110376811', 'none', 9, NULL, NULL, 'سنهور القبليه  وليده بجوار المدرسه الابتدائيه القديمه', '305', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(824, 4, '103255', 'عمر خالد', '1005853251-1124992902', 'none', 9, 28, NULL, 'ابشواي', '670', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(825, 4, '2001177630', 'محمود حسن', '1013786710', 'none', NULL, NULL, NULL, 'الفيوم. مركز أبشواي شرق السكه الحديد', '2636', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(826, 4, 'MGR0001635', 'محمود الابيض', '1098439175', 'none', NULL, NULL, NULL, 'الفيوم صنهور القميه', '335', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(827, 4, '133043', 'عبدالله مصطفى مفتاح', '1013143671', 'none', 9, NULL, NULL, 'الفيوم مركز يوسف الصديق قريه اباظه', '285', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(828, 4, '104154', 'اسراء عادل الشاهد', '1023260391', 'none', NULL, NULL, NULL, 'الفيوم قريه فيديمن هقبال حضرتك ع الطريق السياحي', '400', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(829, 4, 'KE10813', 'اسلام', '1067500482', 'none', 9, NULL, NULL, 'الفيوم سنهور عند المفارق', '275', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(830, 4, 'ky15500', 'مروان اسلام', '01127716002-01021718023', 'none', NULL, NULL, NULL, 'الفيوم قرية جبر في طريق الفيوم السياحي اول الشارع مسجد الشرقي', '220', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(831, 4, 'ZX27692675', 'محمد عبدالواحد', '1001542843', 'none', 9, NULL, NULL, 'الفيوم يوسف الصديق ..قريه غيضان بجوار مكتب بريد غيضان', '245', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(832, 4, 'SO-1-13437', 'بكري عبد الله شافعي', '1060298090', 'none', 9, 28, NULL, 'الفيوم سنرو القبليه مركز ابشواي , الفيوم, مصر', '250', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(833, 4, '15656', 'محمد طه', '1060170046', 'none', 9, 28, NULL, 'مركز ابشواي قريه العجميين', '295', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(834, 4, 'ZX11165156', 'هشام', '1006889845', 'none', 9, NULL, NULL, 'الفيوم سنهور القبلية المفارق', '305', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(835, 4, '100535', 'الاء جمال', '1554288531', 'none', 9, 28, NULL, 'موقف الفيوم ابشواي', '340', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:18', NULL, 0, NULL, 0, NULL),
(836, 4, 'ZX23516717', 'رمضان ابو محمد', '1114020463', 'none', 9, 28, NULL, 'الفيوم ابشواي', '340', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(837, 4, '3005245', 'رنا ياسر', '1127432029', 'none', 9, 28, NULL, 'الفيوم ابشواي شارع المنشيه جوار مسجد المنشيه الشرقي', '420', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(838, 4, '132911', 'رحمه', '1063676694', 'none', 9, 28, NULL, 'الفيوم ف ابشواي', '260', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(839, 4, 'X1176', 'تقوي سرالايمان', '1118847409', 'none', 11, 31, NULL, 'محافظة الفيوم مركز سنورس قريه وليده اول البلد بجوار موقف العربيات', '450', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(840, 4, '45645', 'محمد جمال', '1019780131', 'none', 9, 28, NULL, 'ابشواي الفيوم', '515', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(841, 4, 'MGR0001586', 'خالد', '1007634970', 'none', 9, 28, NULL, 'الفيوم المندره طريق ابشواي السياحي', '610', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(842, 4, '24165', 'سهيله عمر', '1014142724', 'none', 9, NULL, NULL, 'الفيوم سنهور القبليه سراية مته', '290', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(843, 4, 's064109', 'اية ابشواي', '1093026291', 'none', 9, 28, NULL, 'الفيوم مركز ابشواي', '1265', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(844, 4, 'AR11421', 'ايهاب عبد الحليم', '1011770058', 'none', 9, 28, NULL, 'الفيوم الفيوم ابشواي كفر عبود الفيوم الفيوم', '9767', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(845, 4, '11803', 'عمرو حمدي', '1008318291', 'none', 9, NULL, NULL, 'محافظه الفيوم قرية فيديمين بجوار الحنفيه عند مسجد خاتم المرسلين', '235', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(846, 4, '132743', 'اسلام رمضان', '1020184249', 'none', 9, NULL, NULL, 'بني صالح مركز الفيوم', '350', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(847, 4, '15672', 'عادل فارس احمد', '1140945292', 'none', 9, NULL, NULL, 'الحامولي يوسف الصديق الفيوم بجوار محل محمودفارس', '240', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(848, 4, 'KE15291', 'محمد علي فراج', '1016807540', 'none', 9, NULL, NULL, 'محافظه الفيوم مركز سنهور بجوار مسجد سعداوي', '35', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(849, 4, 'SE22104', 'دينا محمد', '1033933526', 'none', 9, 28, NULL, 'الفيوم ابشواي الشواشنه البريد', '294', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(850, 4, '132838', 'عبدالغني ابوالحارث', '1032551812', 'none', 9, NULL, NULL, 'العنون: الفيوم مركز سنهور عزبة ابوسلام بجوار المقابر', '250', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(851, 4, '*OTX2053921*', 'عبده العيسوي', '1155052098', 'none', 9, NULL, NULL, 'الفيوم مركز يوسف الصديق قرية شعلان', '400', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(852, 4, '*OTX2054734*', 'ايمن', '1068586992', 'none', 9, 28, NULL, 'مركز ابشواي قرية ابوكساي ميدان السبيل محل العش', '360', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(853, 4, '*OTX2054288*', 'الاء عصام ربيع عبد السلام', '01062380332\n 01060150387', 'none', 9, 31, NULL, 'الفيوم\n مركز سنورس قرية فيدمين عند الكوبري الجديد بجوار صيدلية دكتور وفيق', '1500', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(854, 4, '*OTX2053925*', 'احمد رجب حسين عبد العال', '1007875831', 'none', 9, 31, NULL, 'الفيوم مركز سنورس سنهور القبليه', '400', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(855, 4, '5760133', 'شهد عيد محمد', '1007563977', 'none', 9, NULL, NULL, 'سنهور القبليه', '315', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(856, 4, '5760132', 'جهاد اشرف', '1148038390', 'none', 9, 28, NULL, 'ابشواي شارع البوره', '254', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(857, 4, '460364744', 'محمود سعد طوبه', '1011130077', 'none', 9, 28, NULL, 'ابشواي ش الجنينه', '1000', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(858, 4, '5544878', 'ا/هند فؤاد صادق', '1005544878', 'none', 9, 28, NULL, 'ابشواي ش المطافي مبني الاطباء الدور 2', '250', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(859, 4, '2252', 'علي مبروك', '1062488003', 'none', 9, NULL, NULL, 'يوسف الصديق قوة استعجال', '250', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(860, 4, '2030278', 'احمد الشاذلي', '1093244666', 'none', 9, 28, NULL, 'ابشواي العجميين فيلا الحاج علي الشاذلي', '500', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(861, 4, '73717', 'ليلي رجب', '1143072686', 'none', NULL, NULL, NULL, 'الفيوم مركزالشوانه الروشده منزل الحاج جلال', '360', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(862, 4, '73520', 'علا فريد', '1115500906', 'none', NULL, NULL, NULL, 'الفيوم ابشواى فى بلد اسمها توفيق حنين بيت الحاج زيد ابو السيد', '430', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(863, 4, 'SP1001062971', 'الاسم اميرة', '01033469211//01146650716', 'none', 9, NULL, NULL, 'طريق الفيوم القديم بجوار كافتريا العمدة الفيوم سنهور القبلية', '510', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(864, 4, 'SP1001061628', 'ام عبدالرحمن', '1005829698', 'none', 9, 28, NULL, 'الفيوم ابشواي كحك قبلي', '530', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(865, 4, 'SP1001059174', 'اميمه سمير', '1002589599', 'none', 9, 28, NULL, 'ابشواي قريه شكشوك', '720', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(866, 4, 'N3022128', 'ريماس', '1033726723', 'none', 9, NULL, NULL, 'الفيوم سنهور القبليه ميدان المفارق بجوار البنزينه امام معمل الاندلس', '360', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(867, 4, '74525', 'متولي السيد', 'ابشواي', 'none', 9, NULL, NULL, 'الفيوم بجوار مدرسة محمد حسين السليين', '480', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(868, 4, 'SP1001059177', 'شيماء صلاح', '1284816867', 'none', 9, NULL, NULL, 'العجميين المورده مدرسه علي الصاوي الاعدادي بنات', '315', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(869, 4, 'SP1001061900', 'حسام محمد', '01098591063 01554082336', 'none', 9, 28, NULL, 'لفيوم ابشوايطبهار(عند المدرسة الثانويه )', '2840', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(870, 4, 'R2360060', 'Ahmed Hassan', '1003358833', 'none', 9, NULL, NULL, 'معرض الفهد\n سنهور القبليه بجوار بنك القريه', NULL, NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(871, 4, 'R2361765', 'صلاح السيد', '1009802532', 'none', 9, NULL, NULL, 'مركز يوسف الصديق قريه مفارق قارون بجوار مستشفي الهلال منزل أستاذ صلاح السيد', '740', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(872, 4, 'R2361764', 'احمد محمد احمد', '1019828705/1095059093', 'none', 9, NULL, NULL, 'مركز يوسف الصديق قرية سيدنا موسى الشارع الرئيسي المنزل أمام مسجد الكبير', '740', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(873, 4, 'R2361761', 'محمد مصطفى عبد الحليم', '1154574509', 'none', 9, NULL, NULL, 'مركز الشواشنه - قرية بطن اهريت - منزل(محمد مصطفي ) بجوار مدرسة بطن اهريت الابتدائية', '860', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(874, 4, '2326', 'محمد فتحي', '1018927966', 'none', 9, NULL, NULL, 'يوسف الصديق الرواشديه', '150', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(875, 4, '261', 'عبدالله', '1129362786', 'none', 9, NULL, NULL, 'كفر عبود', '200', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(876, 4, '1095644', 'الاسم احمد صالح', '1095644248', 'none', 9, NULL, NULL, 'يوسف الصديق الصبيحي', '150', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(877, 4, '2339', 'محمود حسن', '1028853537', 'none', 9, NULL, NULL, 'سنهور القبليه', '125', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(878, 4, '26870', 'محمد سامي', '1020904019', 'none', 9, 28, NULL, 'ابشواي الشواشنه بطن هريت', '305', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(879, 4, '1157003', 'دعاء عبدالحميد', '1501379110', 'none', 9, NULL, NULL, 'العجميين', '545', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(880, 4, 'SP1001063001', 'سمر عماد', '1098101614', 'none', 9, NULL, NULL, 'سنهور القبليه المفارق عند المسجد الكويتي', '1660', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(881, 4, 'SP1001064424', 'علي رمضان علي', '1016187783 1016094014', 'none', 9, NULL, NULL, 'الفيوم يوسف الصديق قريه تونس', '400', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(882, 4, '73290', 'عمرو ناصر', '1127480310', 'none', 9, NULL, NULL, 'الفيوم يوسف الصديق الحمولي', '655', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(883, 4, 'SP1001064428', 'خالد عادل اسماعيل', '1152201214', 'none', 9, 28, NULL, 'محافظه الفيوم مركز ابشواي قريه الزيت عزبه السعي', '230', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(884, 4, '9900088007', 'شريف عاطف', '1019160154', 'none', 9, NULL, NULL, 'الفيوم مركز سنهور', '20', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(885, 4, '2001180132', 'عاصم ابو الحارس', '01093667611 // 01002882391', 'none', NULL, NULL, NULL, 'قرية زاوية الكرادسة -بجوار مسجد الشيخ عمار بالقرب من فرع رنين الفيوم - الفيوم', '2099', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(886, 4, '4683', 'عصام على محمد', '1112287761', 'none', NULL, NULL, NULL, 'امام مستشفى الشلال', '665', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(887, 4, 'SP1001064564', 'سيد محمد', '1026014851', 'none', 9, NULL, NULL, 'الفيوم يوسف الصديق القرية الثانية بيت هادي', '255', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(888, 4, 'R134663', 'احمد ربيع', '1090876374', 'none', 9, NULL, NULL, 'قريه سنهور القبليه', '820', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(889, 4, '135165', 'زياد محمد', '1013385201', 'none', NULL, NULL, NULL, 'الفيوم زاوية الكرداسه عند مسجد الروبي', '225', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(890, 4, '134724', 'مصطفى عدلي زكي', '1019336047', 'none', 9, NULL, NULL, 'الفيوم بني صالح', '250', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(891, 4, 'Sl552166', 'مصطفي درويش', '1060334609', 'none', 9, 28, NULL, 'الفيوم ابشواي طبهار', '240', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(892, 4, 'TG3026257', 'جمعة', '1006874462', 'none', 9, NULL, NULL, 'الفيوم مركز يوسف الصديق', '185', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL);
INSERT INTO `orders` (`id`, `id_company`, `id_police`, `name_client`, `phone`, `phone2`, `center_id`, `agent_id`, `delegate_id`, `address`, `cost`, `salary_charge`, `date`, `notes`, `special_intructions`, `name_product`, `sender`, `weghit`, `open`, `status_id`, `cause_id`, `order_locate`, `gps_delivered`, `identy_number`, `created_at`, `updated_at`, `delegate_supply`, `delegate_supply_date`, `company_supply`, `company_supply_date`) VALUES
(893, 4, 'i9999', 'مصطفى احمد', '1062508776', 'none', NULL, NULL, NULL, 'الفيوم ابشواى', '200', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(894, 4, 'MGR0001806', 'ربيع محمد شلبي', '1011762784', 'none', 9, 28, NULL, 'الفيوم ابشواي سنرو القبلية', '335', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(895, 4, 'KE16911', 'عبدالقادر محمد', '1091847824', 'none', 9, 28, NULL, 'الفيوم ابشواي مركز يوسف الصديق قريه الشيمي', '35', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(896, 4, 'KY15582', 'محمد السيد', '01090952941-01008878699', 'none', 9, NULL, NULL, 'الفيوم - مركز سنهور قريه جاب الله', '40', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(897, 4, 'ex74454', 'مجمد مفرح صالح', '1122017427', 'none', NULL, NULL, NULL, 'مركز الفيوم قرية الشيخ فضل \n شحن 80', '680', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(898, 4, '2224285', 'اشرف سرور عبد الحميد', '1021776022', 'none', NULL, NULL, NULL, 'الفيوم ابشواى شارع الجمهوريه', '185', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(899, 4, '135412', 'جمال محمد', '1023302857', 'none', 9, 28, NULL, 'الفيوم مركز ابشواي', '250', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(900, 4, '114202', 'احمد سيد', '1015102308', 'none', NULL, NULL, NULL, 'مخبز الحاج رمضان المرعوش قرية السيلين', '340', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(901, 4, 'ex74550', 'عمر محمد احمد عبد السلام', '1060747300', 'none', 11, 31, NULL, 'محافظة الفيوم مركز سنورس قرية فيديمي \n شخن 80', '680', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(902, 4, 'PRO15817', 'احمد', '1095945123', 'none', 9, NULL, NULL, 'يوسف الصديق الشواشه بجوار صيدلية د محمد جبالي', '704', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(903, 4, '2224304', 'حسين ابوعرب', '1030543431', 'none', NULL, NULL, NULL, 'الفيوم مركز ابشواى', '185', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(904, 4, '287611', 'محمد يوسف', '01101624486\n -', 'none', NULL, NULL, NULL, 'محافظة الفيوم مركز يوسف اصديق عزبت عفيفي منزل محمد يوسف بجوار مسجد الرحمه', '230', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(905, 4, 'p78196', 'Doha A Thapet', '1069805961', 'none', 9, NULL, NULL, 'ضحي عامر ثابت\n الفيوم.. بني صالح.. مسجد ابو بلال', '390', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(906, 4, 'tm489', 'احمدعبدالسلام عبدالرحمن', '1066565989', 'none', 9, NULL, NULL, 'محافظه الفيوم مركز يوسف الصديق قرية بريش الغربيه', '300', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(907, 4, '*OTX2048745*', 'hhhسمر ماجد', '1026199869', 'none', 9, 28, NULL, 'محافظه الفيوم مركز ابشواي', '315', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(908, 4, '*OTX2057181*', 'سعدابوبكر قاسم منجود', '1066440515', 'none', 9, 28, NULL, 'الفيوم مركز ابشواي قرية سنرو القبلية', '180', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(909, 4, '*OTX2057947*', 'عبدالله عادل محمد', '1096968788', 'none', 9, 28, NULL, 'الفيوم ابشواي بجوار المطافي', '515', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(910, 4, '10073833', 'خالد مصطفي', '1007383386', 'none', 9, NULL, NULL, 'ابو كساه', '230', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(911, 4, '1096696', 'مدحت محمد', '1096696321', 'none', 9, NULL, NULL, 'قصر الجبالي', '1140', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(912, 4, '1066160', 'محمود ثابت', '1066160961', 'none', 9, 28, NULL, 'ابشواي', '235', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(913, 4, '30218', 'ابراهيم اسامه', '1060330195', 'none', 9, NULL, NULL, 'سنرو القبليه النصاريه', '1330', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(914, 4, '2001180665', 'محمد شاهين', '1099599612', 'none', 9, NULL, NULL, 'سنرو القبليه امام نقطه شرطه سنرو', '279', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(915, 4, 'ZX8974754', 'ياسمينا سامي', '1156215162', 'none', 9, NULL, NULL, 'مركز يوسف الصديق قرية المقراني', '260', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(916, 4, 'ZX23516958', 'احمد عبدالتواب', '1282404001', 'none', 9, 28, NULL, 'الفيوم ابشواي', '430', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:19', NULL, 0, NULL, 0, NULL),
(917, 4, '142607', 'مؤتمن', '1552453322', 'none', 9, NULL, NULL, 'الفيوم / يوسف الصديق / كحك بحري / عزبه ميزار', '210', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(918, 4, 'ZX2422474', 'امل شعبان', '1147674647', 'none', 9, NULL, NULL, 'الفيوم. سنهور البحريه. وليده', '250', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(919, 4, 'i10018', 'عمرو السيد', '1144995285', 'none', 9, 28, NULL, 'الفيوم العجميين مركز ابشواي', '260', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(920, 4, 'R135647', 'عمرو حسين', '1013936285', 'none', 9, NULL, NULL, 'سنهور القبليه الفيوم', '260', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(921, 4, '135501', 'ابو سما', '1024941136', 'none', 9, NULL, NULL, 'الفيوم سنهور القبلية', '290', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(922, 4, '288168', 'محمد عيد محمد', '01017601553\n -', 'none', 9, NULL, NULL, 'الفيوم مركز سنهور فيدمين', '390', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(923, 4, '20063632', 'محمود قطب', '1093994383', 'none', NULL, NULL, NULL, 'الفيوم زاوية الكرداسة', '725', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(924, 4, 'p78212', 'احمد علي', '1025289012', 'none', 9, 28, NULL, 'الفيوم مركز ابشواي قريه طبهار بجوار مسجد العمده', '230', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(925, 4, 'wsl000341', 'محمود مجاهد', '1066762686', 'none', 9, 28, NULL, 'الفيوم مركز ابشواي بجوار مسجد عاشور', '60', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(926, 4, 'wsl000722', 'اشرف غيضان', '1003547813', 'none', 9, NULL, NULL, 'الفيوم سنهور السياحي ش الشؤؤن', '650', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(927, 4, 'PRO15883', 'مريم جمال', '1068521711', 'none', 9, 28, NULL, 'العنوان الفيوم مركز ابشواي ش المنشيه', '184', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(928, 4, '20063115', 'اسماء احمد', '1064765040', 'none', 9, 28, NULL, 'الفيوم مركز ابشواي قرية اسمها حميدة صالح', '410', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(929, 4, '135991', 'ابراهيم عرفه عبد القادر', '1062493686', 'none', 9, NULL, NULL, 'محافظه الفيوم مركز يوسف الصديق طريقه بحيرة قرون قريته الشرفدي', '500', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(930, 4, '136070', 'احمد السيد كامل', '1094584579', 'none', 9, 28, NULL, 'الفيوم ابشواي ابو جنشو', '670', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(931, 4, 'CCR928', 'علي الغول', '1000012609', 'none', 9, 28, NULL, 'الفيوم مركز ابشواي قريه النزله شارع الشيخ كامل حميده ابراهيم الغول ناصيه شارع الدرجات بخاريه بجوار الموقف و المسجد البحري', '860', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(932, 4, 'WSL000463', 'محمد ربيع', '1006028736', 'none', 11, 31, NULL, 'الفيوم سنورس السيليين', '650', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(933, 4, '24548', 'احمد مصطفي عبد الحليم', '1003049624', 'none', 9, NULL, NULL, 'السليين', '285', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(934, 4, '*OTX2057991*', 'hhhسمر ماجد', '1026199869', 'none', 9, 28, NULL, 'محافظه الفيوم مركز ابشواي', '100', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(935, 4, '*OTX2058392*', 'Amr Ali Elkady', '1010301913', 'none', 9, 28, NULL, 'الفيوم ابشواي مركز الشواشنه عند المسجد الكبير\n 01010301913', NULL, NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(936, 4, '*OTX2059063*', 'الاسم : احمد جوده', 'الهاتف : . 01020765576', 'none', 9, 28, NULL, 'العنوان : الفيوم مركز ابشواي محل المول', '545', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(937, 4, '*OTX2059076*', 'الفرج للمقولات العمومية', '1061555455', 'none', 9, 28, NULL, 'ابشواي بجوار المطافي', '350', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(938, 4, '*OTX2058734*', 'احمد ايوب', '1019197691', 'none', 9, NULL, NULL, 'الفيوم العجمين المنشيه', '381', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(939, 4, 'R2362490', 'صبرى رمضان', '1002777071', 'none', 9, 31, NULL, 'مركز سنورس قريه سنهور القبليه مقر العمل محل في مدخل المفارق', '370', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(940, 4, 'R2362485', 'مطلوب محمد احمد', '1156898238', 'none', 9, NULL, NULL, 'مركز ابشواى - قرية طبهار- منزل بجوار المعهد الدينى- امام المدرسة الابتدائية الجديدة', '370', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(941, 4, '*OTX2058768*', 'عبد الرحمن عيد', '123480955', 'none', 9, NULL, NULL, 'الفيوم مركز ابشوي قريه عبود بي القرب', '350', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(942, 4, 'R2362484', 'احمد جمعه السيد', '1060200138', 'none', NULL, NULL, NULL, 'الفيوم /ابشواى /شارع شرق الجدر عند شارع مجلس التقوى الاستلام امام مسجد الحضانه', '740', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(943, 4, '95434668', 'مصطفي محمد السيد', '1095434668', 'none', NULL, NULL, NULL, 'لفيوم قريه سنرو المنزل باسم مصطفى محمد بجوار مزلقان القطر هاجسنت و لاف فاكسين ضروري جدا جدا جدا', '1250', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(944, 4, '7539978', 'ايمن روبي محمود', '1007539978', 'none', 9, NULL, NULL, 'الفيوم. ابشواى. كفر عبود. قريه الطماوي بيت اول القريه بجوار المدرسه', '25', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(945, 4, '93731312', 'بكري', '1093731312', 'none', NULL, NULL, NULL, 'كري محمود عبدالباقي الفيوم مدخل بحيرة قارون مدشه بكري محمود بجوار سوق الخميس', '700', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(946, 4, '13544926', 'عمرو', '1113544926', 'none', 9, 28, NULL, 'الفيوم ابشواي قريه السنجق بيت عند مسجد النور بيت اسم عمرو سيد بكري بجوار ورشه', '700', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(947, 4, '10992989', 'الحاج فاروق محمد علي ابو نصار', '1099298925/1060656257', 'none', 9, 28, NULL, 'ابشواي النصاريه الوحده المحليه', NULL, NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(948, 4, 'SP1001071428', 'Mohamed EL Mohdaly', '1021273001', 'none', 9, NULL, NULL, 'ابو كساه ش السوق', '40', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(949, 4, 'SP1001071459', 'معاذ', '1033448036', 'none', 9, NULL, NULL, 'بني صالح بجوار المدرسه ومكتب البريد', NULL, NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(950, 4, 'SP1001070994', 'محسن زكي عبدالعليم', '1027212511', 'none', 9, NULL, NULL, 'فيديمين ش الشيخ سعد', '273', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(951, 4, 'SP1001069155', 'سيد محمد', '1090145920', 'none', 9, NULL, NULL, 'كفر عبود امام المعهد الديني', '285', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(952, 4, 'SP1001070118', 'اسراء رمضان', '1004118568', 'none', 9, NULL, NULL, 'ابوكساه', '150', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(953, 4, 'SP1001071478', 'اسماء ابراهيم حسن', '1095908972', 'none', 9, NULL, NULL, 'بجوار المطافي', NULL, NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(954, 4, 'SP1001068869', 'اميمه سمير', '1002589599', 'none', 9, NULL, NULL, 'شكشوك', NULL, NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(955, 4, 'SP1001070427', 'رجب الصائم احمد', '10143764669/1067744820', 'none', NULL, NULL, NULL, 'ابو جنشوا ش التحرير', '400', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(956, 4, 'SP1001070563', 'علي نور', '1096383248/1111530489', 'none', 9, 28, NULL, 'ابشواي', '250', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(957, 4, 'ST08026', 'محمد محروس', '1020066059', 'none', NULL, NULL, NULL, 'الفيوم فدمين موقف على عامر', '255', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(958, 4, 'MGR0001964', 'احمد خالد علي', '1090958322', 'none', 9, NULL, NULL, 'بجوار سنهور القبليه الفيوم', '230', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(959, 4, 'TG3026573', 'ايه عبد السلام محمود', '1063791068', 'none', 9, NULL, NULL, 'قرية سنهور عزبة عقيلة', '685', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(960, 4, '34040', 'شيماء اسحاق', '1018480211', 'none', 9, NULL, NULL, 'سنهور القبلية الفيوم', '1330', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, 1, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', '2022-12-08 19:48:50', 1, '2022-12-03 00:19:56', 1, '2022-12-08 19:48:50'),
(961, 4, 'KE17202', 'احمد زيدان', '1094313540', 'none', 9, NULL, NULL, '٠١٠٩٤٣١٣٥٤٠ احمد زيدان الفيوم سنهور القبلية كوبري الطواحين', '240', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(962, 4, '136384', 'عبدالرحمن عويس', '1015197666', 'none', 9, 28, NULL, 'العنوان الفيوم -ابشواي -شكشوك ابو نعمه', '250', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(963, 4, '288772', 'محمود موسي', '01098985461\n -', 'none', 9, 28, NULL, 'الفيوم مركز ابشواي قصرالجبالي', '30', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(964, 4, 'ALN9873244', 'محمد عرفه', '1026067524', 'none', NULL, NULL, NULL, 'الفيوم مركز دنشواي قرية ابو حماده', '270', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(965, 4, 'ky15674', 'سارة حسن', '01097752999-01030324009', 'none', 9, 28, NULL, 'الفيوم مركز ابشواي بلد صميده صالح', '425', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(966, 4, '20066901', 'عبد الله ربيع', '1019259558', 'none', 9, 28, NULL, 'الفيوم ابشواي ابو حبشو ش الجلاء بجوار مستشفي مكة', '725', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(967, 4, '290125', 'Nesma Ellahamy', '1032523668\n 1024020119', 'none', 9, NULL, NULL, 'الفيوم -مركز يوسف الصديق -مفارق قارون - اعلي مستشفي الشلال - الدور الثاني علوي', '1030', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(968, 4, '162292', 'جهاد علي', '1004482567', 'none', 9, 28, NULL, 'اهبوم ابشواي الفاروقه بجوار الكنيسه', '2900', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(969, 4, '136475', 'عمرو علي القاضي', '1010301913', 'none', 9, 28, NULL, 'الفيوم ابشواي مركز الشواشنه عند المسجد الكبير', '450', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(970, 4, '136398', 'محمد رجب', '1023430123', 'none', 9, 28, NULL, 'العنوان الفيوم ابشواي شارع الجمهوريه', '35', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(971, 4, '289644', 'ربيع السيد عبدالعزيز', '01010103688\n -', 'none', NULL, NULL, NULL, 'الفيوم ابشواى ابوجنشو بجوار مستشفى مكه', '425', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(972, 4, 'P18504', 'عفاف', '1011726272', 'none', 9, NULL, NULL, 'بلد سنهور جمب', '225', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(973, 4, 'MGR0001961', 'ايمن رجب احمد', '1013056189', 'none', 11, 31, NULL, 'الفيوم &#x2F;مركز سنورس&#x2F;بحيره قارون بحوار فندق القوات المسلحة', '200', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(974, 4, '24629', 'تامر عبد المنصف', '1025251785', 'none', 9, NULL, NULL, 'ابوكساه', '230', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(975, 4, '*OTX2059211*', 'شيرين سيد', '1026382064', 'none', NULL, NULL, NULL, 'الفيوم ابشوي', '65', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(976, 4, '3779', 'محمود عيد', '1157936157', 'none', 9, NULL, NULL, 'كفر عبود', '25', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(977, 4, '930', 'محمد عصام', '1024743531', 'none', 9, NULL, NULL, 'قصر الجبالي', '230', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(978, 4, '2204', 'ناصر', '1012087601', 'none', 9, NULL, NULL, 'يوسف الصديق', '735', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(979, 4, '4077', 'محمود موسي', '1098985461', 'none', 9, NULL, NULL, 'قصر الجبالي', '30', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(980, 4, '762', 'اسلام فتحي', '1019893981', 'none', 9, NULL, NULL, 'شكشوك', '250', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(981, 4, '4254', 'عمر', '1116919530', 'none', 9, NULL, NULL, 'الحامولي', '60', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(982, 4, '4330', 'شعبان رجب', '1027958318', 'none', NULL, NULL, NULL, 'موقف كحك', '30', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(983, 4, '1591', 'بدون اسم', '1095355913', 'none', 9, NULL, NULL, 'يوسف الصديق', '30', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(984, 4, '3936', 'كريم', '1020057880', 'none', 9, NULL, NULL, 'سنهور ش ضرب غلاب بجوار مسجد غلاب', '260', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(985, 4, '4465', 'حازم رمضان', '1094637084', 'none', 9, NULL, NULL, 'سنهور', '270', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(987, 4, '4509', 'عيد رجب محمد', '1090995884', 'none', 9, NULL, NULL, 'ابو دنقاش', '270', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(988, 4, '29853', 'مصطفي', '1555934032', 'none', NULL, NULL, NULL, 'قريه تلات', '150', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(989, 4, '30542', 'شروق', '1068172877', 'none', 9, 28, NULL, 'ابشواي امام اوكازيون', '1580', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(990, 4, '2001184872', 'مريم خلف', '1007598430', 'none', 9, 28, NULL, 'مستشفي ابشواي المركزي', '279', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, 2, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', '2022-12-08 19:48:50', 1, '2022-12-03 00:19:56', 1, '2022-12-08 19:48:50'),
(991, 4, 'MGX200450181', 'صابر يونس محفوظ', '1011160673', 'none', 9, 28, NULL, 'ابشواي قريه عمديه عبود بجوار مسجد الطابونه', '1150', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(992, 4, 'N3022425', 'محمد ربيع', '1012885169-1012885169', 'none', 9, NULL, NULL, 'سنهور المفارق', '280', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(993, 4, '77276', 'د. أحمد صابر', '1062646461', 'none', 9, 28, NULL, '01095676319 \n محافظة الفيوم / مركز ابشواي / قرية ابوكساة / ميدان السبيل / عمارة الدكتور صابر عطا', '175', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(994, 4, '17784', 'محمد', '1098116398', 'none', 9, 28, NULL, 'الفيوم مركز ابشواي ابوكساه بجوار جامع الطراد', '240', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(995, 4, 'R137417', 'هيثم ياسر', '1018696879', 'none', 9, 28, NULL, 'محافظه الفيوم. مركز ومدينه ابشواي العلامه المميزه شارع الجمهورية', '290', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(996, 4, '734807', 'رضوى خالد', '1093768596', 'none', 9, 28, NULL, 'الفيوم ابشواي البورة شارع الشيخ الشافعي', '155', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(997, 4, '289806', 'احمد عبد الله السيد', '01092938383\n -', 'none', 9, 28, NULL, 'مركز ابشواي أمام المطافي', '250', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(998, 4, 'ST08058', 'محمد صلاح', '1015014217', 'none', 9, 28, NULL, 'الفيوم ابشواي الرواشدية', '255', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(999, 4, 'MGR0002051', 'محمد الشريف', '1009378830', 'none', 9, NULL, NULL, 'محمد الشريف محافظة الفيوم بجوار مركز سنهور القبلية', '235', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(1000, 4, 'Sl4439246', 'الاستاذه هند', '1097992404', 'none', NULL, NULL, NULL, 'مركز أبشواى شارع التأمينات عمارة الحاج عزت', '850', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(1001, 4, '288891', 'اسراء محمد فرج', '01017295854\n 01005492922', 'none', NULL, NULL, NULL, 'ابشوي خلف مكتب البريد', '2330', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(1002, 4, '3005355', 'احمد موسى القاضي', '1013193111', 'none', NULL, NULL, NULL, 'الفيوم ابشوي مساكن شركه الملاحات', '350', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(1003, 4, '137327', 'احمد السيد', '1152772048', 'none', 9, NULL, NULL, 'سنهور بجوار البنك الزراعي', '490', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(1004, 4, '137105', 'سعيد سيد', '1069646278', 'none', NULL, NULL, NULL, 'طريق وادي الريان', '235', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(1005, 4, 'ZX8037365', 'مصطفي عطيه عبد القوي', '1550922178', 'none', 9, 28, NULL, 'الفيوم مركز ابشواي قرية العجميين شارع دكان رياض بجوار مسجد الشيخ يوسف', '560', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(1006, 4, 'X1796', 'Hamsa Aboraiyah', '1009469435', 'none', 9, NULL, NULL, '01009469435 الفيوم مركز يوسف الصديق قرية الصبيحي بجوار مصوغات الحرمين', '610', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(1007, 4, 'on369475096', 'السيد حسين رمضان', '01017557761-', 'none', NULL, NULL, NULL, 'مركز ابشوى بجوار مستشفى مكه', '845', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(1008, 4, 'M474', 'حسين محمد عبدالعال', '1000707246', 'none', 9, NULL, NULL, 'الفيوم -مركز ابشواى -قرية ابوكساه - ميدان السبيل', '860', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:20', NULL, 0, NULL, 0, NULL),
(1009, 4, '290232', 'خالد ابراهيم', '01000014954\n -', 'none', 9, NULL, NULL, 'فيديمن مركز سنهور', '1575', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1010, 4, 'PRO16108', 'هاني عبدالله', '1280730800', 'none', 9, NULL, NULL, 'طبهار', '1704', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1011, 4, 'MGR0002035', 'ابو بكر الفاروق', '1027308850', 'none', 9, NULL, NULL, 'الفيوم قريه بني صالح', '320', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1012, 4, '3005358', 'محمود سمير', '1141789620', 'none', NULL, NULL, NULL, 'الحريشي', '700', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1013, 4, 'R2364636', 'عبدالجلبل عبدالمجيدمصباح', '1091271674', 'none', 9, NULL, NULL, 'الفيوم.مركزيوسف الصديق قريه قوته بجوارمسجدعبدالمجيدمصباح', '200', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1014, 4, 'R2365236', 'يوسف محمد عبد ربه', '1066729604', 'none', 9, NULL, NULL, 'مركز يوسف الصديق قريه قارون اباظه بجوار قصر قارون', '370', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1015, 4, '*OTX2060246*', 'Ahmed saad', '1550440711', 'none', NULL, NULL, NULL, 'Yosef elsdek 49', '300', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1016, 4, '*OTX2060620*', 'ٱرباب عاطف محمد', '01013399630\n 01092114974', 'none', NULL, NULL, NULL, 'الفيوم\n  مركز ابشواى قرية الحامولى المنزل على الكوبرى بعد نقطة شرطة الحامولى', '1500', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1017, 4, 'R2359658', 'رجب الزيبق', '1065058543', 'none', 9, NULL, NULL, 'معرض الشريف بحوار فرع فودافون\n سنهور القبلية , الفيوم,', NULL, NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1018, 4, 'R2364808', 'هادي محمد', '1032555010', 'none', 9, 28, NULL, 'الفيوم مركز ابشواي بجوار المحكمه امام الشهر العقاري', '475', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1019, 4, 'R2367061', 'حازم جمال', '1030292285', 'none', NULL, NULL, NULL, 'مركز ابشواى- شارع الجمهورية الجديدة-منزل بجوار مسجد الاخوة', '740', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1020, 4, '783', 'نورهان رمضان علي', '1067080979-1017370935', 'none', 9, 28, NULL, 'ابشواي قريه الشهيد احمد رمضان', '165', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1021, 4, '15578114', 'النقيب ادهم عادل', '1557811405-1020979004', 'none', 9, 28, NULL, 'ابشواي مركز الشرطه', '575', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1022, 4, '11119623', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1023, 4, '4200954', 'محمد رجب', '1018182317', 'none', 9, NULL, NULL, 'بني صالح عند المعهد الازهري', '350', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1024, 4, '6949779', 'محمد موسي', '1000602096', 'none', 9, NULL, NULL, 'الشواشنه', '350', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1025, 4, '99753991', 'احمد سعيد', '1099753991', 'none', 9, NULL, NULL, 'النصاريه بجوار بجوار مكتب بريد النصاريه', NULL, NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1026, 4, 'SP1001075503', 'محمد مصطفي mohamed_mustafa1111', '1098645995', 'none', 9, NULL, NULL, 'الفيوم -قرية سنهور القبلية-بجوار مدرسة عويس عليوة', '160', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1027, 4, '20052234', 'حازم ناجح رمضان', '1017355393', 'none', 9, NULL, NULL, 'الفيوم قريت فيدمين بجوار محلات الازوار', '420', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1028, 4, '137614', 'اكرم عبد التواب', '1062509963', 'none', 9, NULL, NULL, 'مركز يوسف الصديق قارون', '265', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1029, 4, '137484', 'مجدى طلعت احمد', '1090561336', 'none', 9, NULL, NULL, 'العنوان محافظة الفيوم مركز ابشواى كريه النصاريه', '250', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1030, 4, '106871', 'نوال احمد عبد المطلب علي', '1091661049', 'none', 9, 28, NULL, 'محافظه الفيوم مركز ابشواي قريه ابودنقاش ...بجوار مدرسه القران جمب مسجد الحج باهي', '965', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1031, 4, '291905', 'اسماء محمد فؤاد', '01005492922\n -', 'none', 9, NULL, NULL, 'الفيوم السليين بجوار مدرسه محمد حسين جاد ع الطريق الرئيس', '635', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1032, 4, '137828', 'ابراهيم محمد ابراهيم', '1024504360', 'none', NULL, NULL, NULL, 'اليوفيقيه شارع الاربعين', '220', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1033, 4, 'Sh159174', 'عبد الله رمضان', '1093166616', 'none', 9, 28, NULL, 'محافظه الفيوم مركز ابشواي بجوار كافيه ابو عميره', '460', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1034, 4, 'HAP483', 'مصطفي رمضان', '1094028852', 'none', 9, NULL, NULL, 'محافظة الفيوم مركز سنهور', '405', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1035, 4, 's064543', 'فاطمة الجبالي', '1006445555', 'none', 9, 28, NULL, 'الفيوم ابشواي قصر الجبالي بجوار معرض ابن كيشار', NULL, NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1036, 4, 'R137842', 'عبدالعزيز السيد', '1025320930', 'none', 9, NULL, NULL, 'الفيوم ابشواى قصر الجبالي يوسف الصديق', '215', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1037, 4, 'MGR0002166', 'احمدسعد علي', '1010497166', 'none', 9, NULL, NULL, 'مركز ابشوي قريه كحك بحري', '220', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1038, 4, 'KE14891', 'تامر محمد', '1068628840', 'none', 9, 28, NULL, 'الفيوم ابشواي قريه ضحاوي بجوار مدرسه ضحاوي منزل بأسم محمد ربيع احمد', '245', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1039, 4, '18038', 'مصطفى', '1125495670', 'none', 9, 28, NULL, 'الفيوم ابشواي سنرو امام كشري ابو الدهب', '245', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1040, 4, 'lnv_00645', 'عبدالرحمن محمد', '1097032875', 'none', 9, 28, NULL, 'الفيوم مركز ابشواي عند بنك مصر', '280', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1041, 4, 'R138344', 'رجب', '1155829297', 'none', 9, NULL, NULL, 'الفيوم بني صالح', '280', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1042, 4, '20052304', 'محمود السقا', '1016136121', 'none', NULL, NULL, NULL, 'الفيوم ابجواي قريه طهار', '295', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1043, 4, '1018702782', 'رنا', '1018702782', 'none', 9, NULL, NULL, 'طبهار', '345', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1044, 4, '138017', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1045, 4, 'Sh159067', 'شيماء اسحاق', '1018480211', 'none', 9, NULL, NULL, 'مركز سنهور القبلية المفارق /الفيوم', '530', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1046, 4, 'q71543', 'ام ايكذ عمرو محمد', '1001863669', 'none', 9, NULL, NULL, 'العنوان الفيوم مركز الشوشنه حارت اروبي امام الفرنه', '230', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1047, 4, 'f360', 'مجدي طلعت محمد', '1090561336', 'none', NULL, NULL, NULL, 'محافظه الفيوم مركز ايبشواي', '330', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1048, 4, '291556', 'اهداء Ehdaa_mahmoud16', '1063844462\n -', 'none', NULL, NULL, NULL, 'الوزن ٥٨ و الطول ١٥٨ الفيوم قريه فديمين سنرو عزبه محمد علي بياض 01063377239', '550', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1049, 4, '46525', '_', '1003238010', 'none', 9, NULL, NULL, 'يوسف الصديق', NULL, NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1050, 4, 'KY15731', 'نجلاء فتحي', '01095902775-01090838824', 'none', 9, NULL, NULL, 'الفيوم - يوسف الصديق المشرك قبلي', '835', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1051, 4, 'R137539', 'عمر', '1008560615', 'none', 9, 28, NULL, 'الفيوم مركز ابشواي الشواشنة', '35', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1052, 4, '291628', 'الحاجه كميليا', '01152292737\n -', 'none', 9, 28, NULL, 'الفيوم ابشواي ش المروه منزل رقم 16 علي أول الشارع محل فيز بوك والمنزل بجوار صيدلية الدكتورة وفاء', '140', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1053, 4, '2223005', 'هانى محمود', '1003525182', 'none', 9, NULL, NULL, 'الفيوم مركز يوسف الصديق قرية تونس', '185', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1054, 4, '289729', 'ايمن محمد الصوفى', '01091457430\n 01091457430', 'none', 9, NULL, NULL, 'الفيوم ابشواى كحك بحرى جمب مسجد الكبير بيت الصوفي الدور التالت', '1500', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1055, 4, 'PRO16173', 'ياسمين', '1022354740', 'none', 9, 28, NULL, 'الفيوم مركز ابشواي', '304', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1056, 4, 'MGR0002127', 'صابر بكري', '1017746819', 'none', NULL, NULL, NULL, 'الفيوم مركز ابشواى', '300', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1057, 4, 'KE13437', 'وائل حمدى', '1129509798', 'none', 9, 28, NULL, 'الفيوم مركز ابشواي البنك الاهلي', '245', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1058, 4, '78238', 'يوسف البرت', '1027854989', 'none', 9, 31, NULL, 'الفيوم - مركز سنورس - سنهور القبلية \n شحن 80', '280', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1059, 4, 'MGR0002132', 'حسن بو يس', '1002797881', 'none', 9, NULL, NULL, 'مركز ومدينه يوسف الصديق محافظه الفيوم', '570', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1060, 4, '25064', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1061, 4, '25183', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1062, 4, '25042', 'محمود', '1155228355', 'none', 9, 28, NULL, 'ابشواي بجوار المطافي', '260', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1063, 4, '25193', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1064, 4, '*OTX2062164*', 'Alaa Adel', '1030696640', 'none', 9, 28, NULL, 'الفيوم ابشواي يوسف الصديق كحك بحري', '670', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1065, 4, '*OTX2061803*', 'عمر عدلي', '1096760072', 'none', 9, 28, NULL, '\"الفيوم ابشواي محل موبايل الرائد امان البنك الاهلي\n ٠١٠٩٦٧٦٠٠٧٢\n \"', '550', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1066, 4, '41923617', 'اسامه جمال', '1030080481', 'none', 9, 28, NULL, 'ابشواي', '410', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1067, 4, 'SM9999929017', 'يوسف جمال', '1025074494', 'none', NULL, NULL, NULL, 'لافيوم زواية الكرادسة', '385', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1068, 4, '2001178190', 'عائشة عدلي', '1023542468', 'none', 9, NULL, NULL, 'منزل الشيخ عدلي قرية ذو الفقار مركز يوسف الصديق', '320', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1069, 4, '2200055334', 'محمد ربيع متولي', '1013830555', 'none', 9, 28, NULL, 'ابشواي الفيوم شارع الجمهوريه بجوار شركه الكهرباء', '35', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1070, 4, '2200055327', 'محمود الحمزاوى', '1128648897', 'none', 9, NULL, NULL, 'الفيوم مركز يوسف الصديق الريان بجوار الوحده المحليه', '230', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1071, 4, '4334', 'سليم محمود', '1094429182', 'none', 9, NULL, NULL, 'سنهور القبليه', '225', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1072, 4, '73508', 'هاله وليد محمد', '1025644849', 'none', NULL, NULL, NULL, 'ابشواى قريه الحرجاويه ش الصيداليه', '345', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1073, 4, '133248', 'محمد سلامه جنيدي', '1067165936', 'none', 9, NULL, NULL, 'العنوان الفيوم يوسف الصديق', '250', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1074, 4, 'R133269', 'محمد علي', '1123225913', 'none', 9, 28, NULL, 'الفيوم ابشواي النزلة', NULL, NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1075, 4, '133853', 'عبدالله سعد', '1095820103', 'none', 9, NULL, NULL, 'الفيوم مركز يوسف الصديق قارون', '270', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1076, 4, '134311', 'عمر على', '1095365382', 'none', NULL, NULL, NULL, 'الفيوم شارع كحك قبلي', '225', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1077, 4, '2257636bcbfed5c28', 'احمد طه محمد عبدالعزيز', '1090569680', 'none', 9, NULL, NULL, 'الفيوم ابشواى العجميين بجوار مركز شباب العجميين', '65', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1078, 4, '142541', 'حسين ابوعرب', '1030543431', 'none', NULL, NULL, NULL, 'الفيوم مركز ابشواى', '230', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1079, 4, 'MGR0001680', 'عمر عابد', '1016069851', 'none', NULL, NULL, NULL, 'الفيوم قصرالجبالى الفيوم ابشواى قصرالجبالى عمر عابد', '275', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1080, 4, '2223859', 'حسين ابوعرب', '1030543431', 'none', NULL, NULL, NULL, 'الفيوم مركز ابشواى', '285', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1081, 4, 'R134284', 'احمد السيد مصطفي', '1023013732', 'none', 9, 28, NULL, 'الفيوم في ابشواي', '334', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1082, 4, '20053569', 'اسماء محمد', '1024904491', 'none', 9, NULL, NULL, 'الفيوم سنهور القبلية شارع نادي الشباب وسط البلد', '1495', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1083, 4, '16127', 'محمود جمعه', '1094814660', 'none', NULL, NULL, NULL, 'الفيوم السيليين بجوار المسجد الكبير', '455', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1084, 4, '51708', 'محمد شعبان', '1010219530', 'none', NULL, NULL, NULL, 'موقف طهبار بجوار الموقف', '475', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1085, 4, 'R134068', 'احمد حميده', '1066778711', 'none', 9, NULL, NULL, 'الفيوم يوسف الصديق جنب مركز الشرطه.', '440', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL);
INSERT INTO `orders` (`id`, `id_company`, `id_police`, `name_client`, `phone`, `phone2`, `center_id`, `agent_id`, `delegate_id`, `address`, `cost`, `salary_charge`, `date`, `notes`, `special_intructions`, `name_product`, `sender`, `weghit`, `open`, `status_id`, `cause_id`, `order_locate`, `gps_delivered`, `identy_number`, `created_at`, `updated_at`, `delegate_supply`, `delegate_supply_date`, `company_supply`, `company_supply_date`) VALUES
(1086, 4, '20049403', '..', '1033726723', 'none', 9, NULL, NULL, 'الفيوم سنهور قبلية مدان مفارق', '375', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1087, 4, 'MGR0001778', 'عصام عبد التواب', '1090404581', 'none', 9, NULL, NULL, 'سنهور القبليه', '315', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1088, 4, 'Sl14122254', 'محمد رمضان', '1024477318', 'none', 9, 31, NULL, 'الفيوم مركز سنورس قريه فيدمين', '375', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1089, 4, '607195', 'مريم عبد الفتاح', '1016162046', 'none', 9, 28, NULL, 'الفيوم ابشواي المطافي', '315', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1090, 4, '20057552', 'هناء عثمان', '1024763376', 'none', 9, NULL, NULL, 'الفيوم مركز سنهور فيديمين موقف على عامر', '450', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1091, 4, '2295636bd61a56c7d', 'محمود', '1007237811', 'none', 9, 28, NULL, 'محافظه الفيوم مركز ابشواي قريه ابوكساه ميدان السبيل', '1535', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:21', NULL, 0, NULL, 0, NULL),
(1092, 4, 'MGR0000496', 'لوءه نجاتي هيبة', '1067452673', 'none', 9, 28, NULL, 'العنوان الفيوم ابشواي الشارع الي قبل المستشفى العام المندوب يروح للحضانه علي طول يسال علي ميس ريهام  هتستلم منه الاوردر ومعها الفلوس', '550', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1093, 4, '5016', 'رحمه السيد', '1013421794', 'none', 9, 28, NULL, 'ابشواي', '630', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1094, 4, 'PRO15571', 'شيماء محمود', '1093805227', 'none', NULL, NULL, NULL, 'العنوان الفيوم دله عند جامعه الازهر', '184', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1095, 4, 'HAP418', 'محمد جمال', '1033064966', 'none', 9, 28, NULL, 'محافظه الفيوم ابشواي قصر الجبالي', '185', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1096, 4, 'se21364', 'دينا محمد', '1033933526', 'none', 9, NULL, NULL, 'الشواشنة البريد', '294', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1097, 4, '20062899', 'شهد السد', '1011578571', 'none', 9, NULL, NULL, 'فيوم طبهار عند موقف فيوم', '605', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1098, 4, '133633', 'ياسر كارم', '1050400287', 'none', 9, NULL, NULL, 'مركز ابو كساه', '35', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1099, 4, '20060612', 'عليه عبدالعليم', '1023472429', 'none', 9, NULL, NULL, 'الفيوم الشواشنه بجوار مسجد عبدالهادي', '1850', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1100, 4, '*OTX2055820*', 'محمد محمد غضبان', '1066784655', 'none', NULL, NULL, NULL, 'بن صالح اول بنى صالح وانت جاي من الفيوم عند ملعب كوره', '400', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1101, 4, '*OTX2055792*', 'احمد', '1009574068', 'none', 9, NULL, NULL, 'الفيوم مركز يوسف الصديق مشرك قبلي', '295', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1102, 4, '*OTX2055736*', 'Amr Ali Elkady', '1010301913', 'none', 9, 28, NULL, 'الفيوم ابشواي مركز الشواشنه عند المسجد الكبير\n 01010301913', '670', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1103, 4, 'R2360461', 'على حسين عبد السميع غيضان', '201004008128', 'none', 9, NULL, NULL, 'مركز الشواشنه - قريه غيضان - بجوار مسجد الشيخ يحيي', '740', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1104, 4, '*OTX2053923*', 'هشام عبده ابو طالب', '1005879032', 'none', 9, 28, NULL, 'الفيوم مركز ابشواي العجميين ش دكان رياض', '900', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1105, 4, '*OTX2055236*', 'مني جلال السيد', '1033899751', 'none', NULL, NULL, NULL, ' أبشواي بجوار مدرسة أبشواي الثانوية', '1500', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1106, 4, '2252', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1107, 4, '2030278', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1108, 4, '73717', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1109, 4, '73520', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1110, 4, 'SP1001062971', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1111, 4, 'SP1001061628', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1112, 4, 'SP1001059174', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1113, 4, 'N3022128', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1114, 4, '74525', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1115, 4, 'SP1001059177', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1116, 4, 'SP1001061900', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1117, 4, 'R2360060', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1118, 4, 'R2361765', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1119, 4, 'R2361764', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1120, 4, 'R2361761', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1121, 4, '2326', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1122, 4, '261', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1123, 4, '1095644', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1124, 4, '2339', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1125, 4, '26870', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1126, 4, '1157003', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1127, 4, 'SP1001063001', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1128, 4, 'SP1001064424', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1129, 4, '73290', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1130, 4, 'SP1001064428', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1131, 4, '9900088007', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1132, 4, '2001180132', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1133, 4, '4683', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1134, 4, 'SP1001064564', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1135, 4, 'R134663', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1136, 4, '135165', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1137, 4, '134724', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1138, 4, 'Sl552166', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1139, 4, 'TG3026257', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1140, 4, 'i9999', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1141, 4, 'MGR0001806', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1142, 4, 'ex74454', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1143, 4, '2224285', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1144, 4, '135412', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1145, 4, '114202', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1146, 4, 'ex74550', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1147, 4, 'PRO15817', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1148, 4, '287611', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1149, 4, 'p78196', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1150, 4, 'tm489', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1151, 4, 'KE16911', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1152, 4, '*OTX2048745*', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1153, 4, '*OTX2057181*', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1154, 4, '*OTX2057947*', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1155, 4, '10073833', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1156, 4, '1096696', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1157, 4, '1066160', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1158, 4, '30218', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1159, 4, '2001180665', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1160, 4, '135501', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1161, 4, 'ZX23516958', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1162, 4, '142607', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1163, 4, 'ZX2422474', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1164, 4, 'i10018', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1165, 4, 'R135647', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1166, 4, '288168', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1167, 4, '20063632', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1168, 4, 'p78212', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1169, 4, 'wsl000722', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1170, 4, 'PRO15883', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1171, 4, '20063115', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1172, 4, '135991', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1173, 4, '136070', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1174, 4, 'CCR928', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1175, 4, 'WSL000463', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1176, 4, 'ZX8974754', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1177, 4, 'wsl000341', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1178, 4, '24548', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1179, 4, '*OTX2058392*', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:22', NULL, 0, NULL, 0, NULL),
(1180, 4, '*OTX2059063*', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1181, 4, '*OTX2059076*', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1182, 4, '*OTX2058734*', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1183, 4, 'R2362490', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1184, 4, 'R2362485', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1185, 4, '*OTX2058768*', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1186, 4, 'R2362484', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1187, 4, '95434668', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1188, 4, '7539978', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1189, 4, '93731312', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1190, 4, '13544926', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1191, 4, '10992989', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1192, 4, 'SP1001071459', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1193, 4, 'SP1001070994', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1194, 4, 'SP1001069155', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1195, 4, 'SP1001070118', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1196, 4, 'SP1001071478', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1197, 4, 'SP1001068869', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1198, 4, 'SP1001070427', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1199, 4, 'SP1001070563', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1200, 4, 'SP1001071428', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1201, 4, 'MGR0001964', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1202, 4, 'TG3026573', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1203, 4, '34040', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1204, 4, 'KE17202', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1205, 4, '136384', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1206, 4, 'ALN9873244', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1207, 4, 'ky15674', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1208, 4, '20066901', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1209, 4, '290125', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1210, 4, '162292', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1211, 4, '289644', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1212, 4, 'P18504', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1213, 4, 'MGR0001961', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1214, 4, '288772', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1215, 4, '136475', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1216, 4, '136398', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1217, 4, '*OTX2059211*', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1218, 4, '1591', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1219, 4, '3936', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1220, 4, '4465', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1221, 4, '4509', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1222, 4, '3779', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1223, 4, '930', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1224, 4, '2204', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1225, 4, '4077', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1226, 4, '762', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1227, 4, '4254', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1228, 4, '4330', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1229, 4, '29853', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1230, 4, '30542', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1231, 4, '2001184872', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1232, 4, 'MGX200450181', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1233, 4, 'N3022425', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1234, 4, 'MGR0002051', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1235, 4, 'Sl4439246', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1236, 4, '77276', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1237, 4, '17784', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1238, 4, 'R137417', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1239, 4, '734807', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1240, 4, '289806', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1241, 4, 'ST08058', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1242, 4, '3005355', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1243, 4, '137327', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1244, 4, '137105', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1245, 4, 'ZX8037365', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1246, 4, 'X1796', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1247, 4, 'on369475096', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1248, 4, 'M474', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1249, 4, '290232', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1250, 4, 'PRO16108', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1251, 4, '3005358', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1252, 4, '288891', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1253, 4, 'MGR0002035', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1254, 4, 'R2367061', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1255, 4, 'R2365236', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1256, 4, 'R2364636', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1257, 4, '*OTX2060246*', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1258, 4, '*OTX2060620*', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1259, 4, 'R2359658', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1260, 4, 'R2364808', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1261, 4, '783', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1262, 4, '15578114', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1263, 4, '4200954', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1264, 4, '6949779', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1265, 4, '99753991', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1266, 4, 'SP1001075503', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1267, 4, '46525', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1268, 4, '20052234', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1269, 4, '137614', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1270, 4, '137484', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1271, 4, 'f360', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1272, 4, 's064543', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1273, 4, 'R137842', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1274, 4, 'MGR0002166', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1275, 4, 'KE14891', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:23', NULL, 0, NULL, 0, NULL),
(1276, 4, '18038', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:24', NULL, 0, NULL, 0, NULL),
(1277, 4, 'lnv_00645', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:24', NULL, 0, NULL, 0, NULL),
(1278, 4, 'R138344', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:24', NULL, 0, NULL, 0, NULL),
(1279, 4, '20052304', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:24', NULL, 0, NULL, 0, NULL),
(1280, 4, '1018702782', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:24', NULL, 0, NULL, 0, NULL),
(1281, 4, 'Sh159067', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:24', NULL, 0, NULL, 0, NULL),
(1282, 4, '291556', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, '2022-11-28 20:12:24', NULL, 0, NULL, 0, NULL),
(1283, 4, 'KY15731', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:24', NULL, 0, NULL, 0, NULL),
(1284, 4, '2223005', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:24', NULL, 0, NULL, 0, NULL),
(1285, 4, 'MGR0002127', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:24', NULL, 0, NULL, 0, NULL),
(1286, 4, 'KE13437', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:24', NULL, 0, NULL, 0, NULL),
(1287, 4, '291628', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:24', NULL, 0, NULL, 0, NULL),
(1288, 4, '78238', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:24', NULL, 0, NULL, 0, NULL),
(1289, 4, 'R137539', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:24', NULL, 0, NULL, 0, NULL),
(1290, 4, 'Sh159174', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:24', NULL, 0, NULL, 0, NULL),
(1291, 4, 'MGR0002132', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:24', NULL, 0, NULL, 0, NULL),
(1292, 4, '291905', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:24', NULL, 0, NULL, 0, NULL),
(1293, 4, '106871', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:24', NULL, 0, NULL, 0, NULL),
(1294, 4, '289729', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:24', NULL, 0, NULL, 0, NULL),
(1295, 4, 'HAP483', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:24', NULL, 0, NULL, 0, NULL),
(1296, 4, '137828', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:24', NULL, 0, NULL, 0, NULL),
(1297, 4, '25042', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:24', NULL, 0, NULL, 0, NULL),
(1298, 4, '*OTX2062164*', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:24', NULL, 0, NULL, 0, NULL),
(1299, 4, '*OTX2061803*', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:24', NULL, 0, NULL, 0, NULL),
(1300, 4, '41923617', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:24', NULL, 0, NULL, 0, NULL),
(1301, 4, '14964330', 'مصطفي احمد موسي', '1114964330', 'none', 9, 28, NULL, 'ابشواي', '305', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:24', NULL, 0, NULL, 0, NULL),
(1302, 4, '96763992', 'مها اشرف', '1069763992', 'none', 9, NULL, NULL, 'قصر الجبالي', '210', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:24', NULL, 0, NULL, 0, NULL),
(1303, 4, '1158405', 'روان عبد الحليم', '1005882276-1024770091', 'none', NULL, NULL, NULL, 'شارع المركز امام مدرسه ام المؤمنين', '475', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:24', NULL, 0, NULL, 0, NULL),
(1304, 4, '33118064', 'بدون اسم', '1033118064', 'none', 9, NULL, NULL, 'سنهور الفبليه', '2465', NULL, '1999-12-30', 'none', 'none', 'none', 'none', 'none', NULL, NULL, NULL, 0, NULL, NULL, '2022-11-28 20:12:24', NULL, 0, NULL, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `order_state`
--

CREATE TABLE `order_state` (
  `id` int(20) NOT NULL,
  `state` char(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_state`
--

INSERT INTO `order_state` (`id`, `state`) VALUES
(1, 'تسليم'),
(2, 'تسليم جزئي'),
(3, 'مرتجع بقيمه'),
(4, 'استبدال'),
(5, 'مرتجع'),
(6, 'مرتجع بعموله');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `personal_access_tokens`
--

INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `expires_at`, `created_at`, `updated_at`) VALUES
(1, 'App\\Models\\User', 27, 'token', '0443fca5c758ba80e6716c50122b57c69da8010731c732ddfb2a1c8e7f48c6f4', '[\"*\"]', NULL, NULL, '2022-12-06 15:11:17', '2022-12-06 15:11:17'),
(2, 'App\\Models\\User', 27, 'token', 'b02e140eae6c4ff09edc975ac6662139c38961173acb6b1ea16072860f3ea9ca', '[\"*\"]', NULL, NULL, '2022-12-06 15:13:19', '2022-12-06 15:13:19'),
(3, 'App\\Models\\User', 27, 'token', '798609118134f1a83efeaf50e3869ac232a25997678d2da5fb2fcfa86c41950f', '[\"*\"]', NULL, NULL, '2022-12-06 15:14:10', '2022-12-06 15:14:10'),
(4, 'App\\Models\\User', 27, 'token', 'b09430b041494c5171aad770be50f0a340e96e568dd5d12d3ae1b0431c52d5c1', '[\"*\"]', NULL, NULL, '2022-12-06 15:15:09', '2022-12-06 15:15:09'),
(5, 'App\\Models\\User', 27, 'token', '6618c18a8c06517f81b074ce174423bdd2fa2776489371a65a3c804e8fde81a7', '[\"*\"]', NULL, NULL, '2022-12-07 15:24:23', '2022-12-07 15:24:23'),
(6, 'App\\Models\\User', 27, 'token', '653690163468269f695e084221e0d445f78d743e427f853ef53318d33dbfa247', '[\"*\"]', NULL, NULL, '2022-12-07 15:46:18', '2022-12-07 15:46:18');

-- --------------------------------------------------------

--
-- Table structure for table `ranks`
--

CREATE TABLE `ranks` (
  `id` int(11) NOT NULL,
  `name` char(18) NOT NULL,
  `name_ar` char(12) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ranks`
--

INSERT INTO `ranks` (`id`, `name`, `name_ar`) VALUES
(1, 'admin', 'مشرف'),
(2, 'customer service', 'خدمه عملاء'),
(3, 'operations', 'اوبريشن'),
(4, 'data entry', 'مدخل بيانات'),
(5, 'acountant', 'محاسب'),
(6, 'employer', 'موظف'),
(7, 'company', 'شركه'),
(8, 'agent', 'وكيل'),
(9, 'representative', 'مندوب');

-- --------------------------------------------------------

--
-- Table structure for table `salaries`
--

CREATE TABLE `salaries` (
  `id` int(20) NOT NULL,
  `id_user` int(20) NOT NULL,
  `salary` int(11) NOT NULL,
  `discount` int(11) DEFAULT NULL,
  `notes` char(250) DEFAULT NULL,
  `done` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0=>not,1=>done',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `salaries`
--

INSERT INTO `salaries` (`id`, `id_user`, `salary`, `discount`, `notes`, `done`, `created_at`, `updated_at`) VALUES
(1, 26, 1500, 50, NULL, 1, '2022-12-01 01:42:03', '2022-12-01 01:42:03'),
(2, 35, 9000, 190, NULL, 0, '2022-12-01 02:50:48', '2022-12-01 02:50:48');

-- --------------------------------------------------------

--
-- Table structure for table `stocks`
--

CREATE TABLE `stocks` (
  `id` int(11) NOT NULL,
  `quantitiy` int(11) NOT NULL,
  `name` int(11) NOT NULL,
  `size` int(11) NOT NULL,
  `color` int(11) NOT NULL,
  `company_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `sub_center`
--

CREATE TABLE `sub_center` (
  `id` int(20) NOT NULL,
  `id_center` int(20) NOT NULL,
  `name` char(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sub_center`
--

INSERT INTO `sub_center` (`id`, `id_center`, `name`) VALUES
(2, 9, 'ابو شنب'),
(3, 9, 'العجميين'),
(4, 9, 'ثلات'),
(12, 9, ' فيديمين'),
(13, 9, 'الفيوم ابشواي بجوار المركز الطبي الحضاري'),
(14, 9, ' ابشواى بجوار البنك الاهلى'),
(15, 9, ' ابشواى بجوار المطافي'),
(16, 9, ' مركز ابشواي'),
(17, 9, 'المحافظه الفيوم\n  قرية جبر - أبشواي'),
(18, 9, 'الفيوم ابشوى كحك بحري عند مول أ شامل'),
(19, 9, 'محمد مصطفي ٠١٠٩٥٥٢٩١٧٧ الفيوم . يوسف الصديق. قارون. اباظه'),
(20, 9, 'العنوان :الفيوم مركز يوسف الصديق مفارق قارون عند المسجد'),
(21, 9, 'الفيوم +العنوان قرية كحك بحرى مركز يوسف الصديق'),
(22, 9, 'الفيوم ابشواي قرية النصارية'),
(23, 9, 'الفيوم مركز ابشواى قرية شرف الدين'),
(24, 9, 'الفيوم - يوسف الصديق'),
(25, 9, 'ابشواي مستشفي ابشواي المركزي'),
(26, 9, 'الفيوم مركز ابشواي امام البنك الاهلي'),
(27, 9, 'الفيوم مركز يوسف الصديق. قارون الخلطة'),
(28, 9, 'العنوان الفيوم مركز يوسف الصديق الصبيحي'),
(29, 9, 'الفيوم &#x2F; مركز سنورس عين السليين'),
(30, 9, 'سنهور القبليه امام البنك الاهلي'),
(31, 9, 'الفيوم ابشواى قرية ابودنقاش'),
(32, 9, 'الفيوم مركز ابشواى قرية قصر الجبالى'),
(33, 9, 'الفيوم/يوسف الصديق/مفارق قارون'),
(34, 9, 'مركز سنورس\n قرية فيديمين\n مكتب بريد فيديمين'),
(35, 9, 'الفيوم سنهودر بجوار مسجد الطواحين'),
(36, 9, 'يوسف الصديق الثلثمائه'),
(37, 9, 'الفيوم ابشواي شكشوك فوق مطعم ارزاق'),
(38, 9, 'الفيوم مركز يوسف الصديق قريه تونس بجوار فندق ظلال'),
(39, 9, 'سنهور ضروري'),
(40, 9, 'الفيوم . مركز أبشواي . قريه شكشوك .أمام المدرسه الاعداديه'),
(41, 9, 'العنوان: الفيوم مركز ابشواي شارع المحطه امام حديقه الطفل اعلى مطعم الهواري منزل يوسف منتصر'),
(42, 9, 'العنوان محافظة الفيوم قرية تلات بجوار مسجد الرحمه رقم الموب ٠١٠٠٢١٢١٣٧٠ 01002121370'),
(43, 9, 'الفيوم سنرو القبليه شارع المقابر محل صغير ابو كريم'),
(44, 9, 'الفيوم سنهور القبليه بجوار مركز سنهور'),
(45, 9, 'الفيوم الشواشنه امام مدرسه ثانوي'),
(46, 9, 'العنوان الفيوم مركز سنورس سنهور القبليه\n بجوار المفارق'),
(47, 9, 'ابشواي بجوار مسجد الشيخ عبدالعليم'),
(48, 9, 'مكتب بيت الخبره امام البنك الاهلي ابشواي الفيوم - العميل هيستلم ف المكتب نفسه ولو العميل مردش يسلمه للمكتب مباشرة'),
(49, 9, 'ابشواي شكشوك'),
(50, 9, 'بني صالح فيلا الحج ايوب بجوار مسجد الحرمين'),
(51, 9, 'ابشواي شركه تنميه للمشروعات'),
(52, 9, 'طبهار بجوار مسجد العمده'),
(53, 9, 'فيديميين مركز الشباب امام صيدليه د حماده روبي'),
(54, 9, 'ابشواي بجوار مسجد عزام'),
(55, 9, 'مفارق يوسف الصديق محل مهندس حسن العبادي امام المسجد'),
(56, 9, 'ابشواي'),
(57, 9, 'ابشواي شارع الواغط'),
(58, 9, 'االفيوم الاداره الزراعيه بابشواى امام مكتب بريد بشواى لحد السااعه 2 ظهرا'),
(59, 9, 'الفيوم - مركز ابشاوي قريه زيد قبال صيدليه د محمود'),
(60, 9, 'الفيوم ابشواى مركز يوسف الصديق الخلطه'),
(61, 9, 'الفيوم موكز ابشواي'),
(62, 9, 'الفيوم ابشواي ابوجنشو اول طريق الصفرايه العماره6 ادوار امام الملعبالرقم01065261919'),
(63, 9, 'الفيوم مركز ابشواى قرية النزله البيت اللى قدام قهوة الفرنساوى'),
(64, 9, 'ابشواي ابوجنشو المنطقه الصناعيه عند مطعم بيت العيله'),
(65, 9, 'الفيوم مركز ابشواي قرية الشهيد احمد رمضان - 01067080979'),
(66, 9, 'الفيوم ...مركز ابشواي.... محل دلع في دلع إدارة ابو عمر....أمام اوكازيون ....اول شارع البورة في ابشواي'),
(67, 9, 'الفيوم مراكز ابشواى قريت ابوكساه السبيل دردير الاستلام قيل الجمعة ضروري'),
(68, 9, 'الفيوم ابشواي شكشوك أمام صيدليه محمد ربيع'),
(69, 9, 'الفيوم مركز ابشواي بجوار مستشفي مكه'),
(70, 9, 'الفيوم ابشواي ابو جنشوا المنطقه الصناعيه بجوار مطعم بيت العيله'),
(71, 9, 'قرية المشرك قبلي مركز يوسف الصديق الفيوم ( بجوار مطبعة الصايم ومخبز العيش البلدي ) منزل الأستاذ عثمان علي علي'),
(72, 9, 'الفيوم مركز ابشواي ابو كاه قرية بلونه بجوار المدرسة'),
(73, 9, 'الفيوم مركز الشواشنه بجوار مركز الشرطه'),
(74, 9, 'الفيوم مركز يوسف الصديق الرواشديه'),
(75, 9, 'الفيوم &#x2F;ابشواي &#x2F; طبهار بجوار الوحده المحليه'),
(76, 9, 'الفيوم مركز سنورس قرية سنهور القبلية'),
(77, 9, 'الفيوم قارون قوتة'),
(78, 9, 'يوسف الصديق الخريجين ف العماير ال ف اول البلد'),
(79, 9, 'الفيوم سنورس سنهور القبليه الطواحين'),
(80, 9, 'قريه الريان مركز يوسف الصديق محافظه الفيوم'),
(81, 9, 'محافظة الفيوم مركز ابشواى ابو جنشر بجوار مدرسه التجاره'),
(82, 9, 'قريه سنهور البحريه'),
(83, 9, 'الفيوم ابشواى ويكلمنى على الرقم انا اكمل معاه اوك'),
(84, 9, 'الشواشنه مشرك قبلي'),
(85, 9, 'الفيوم فيدمين بجوار جامع محمد مرسي'),
(86, 9, 'من الفيوم من مركز يوسف الصديق'),
(87, 9, 'المندره طريقة ابشوى السياحي'),
(88, 9, 'الفيوم /ابشواي /الشواشنة أمام سوبر ماركت أسواق الغمراوي.'),
(89, 9, 'ش محمد حسين ابشواي'),
(90, 9, 'الفيوم ابشواى العجميين'),
(91, 9, 'ابشواي بجوار المستشفى العام'),
(92, 9, 'الفيوم _ المشرك قبلي _ مركز يوسف الصديق'),
(93, 9, 'الفيوم ابشواى بجوار المطحن'),
(94, 9, 'مركز ابشواي شركو الكهرباء بجوار بنك مصر'),
(95, 9, 'القيوم مركز ابشاوى عند المطافى'),
(96, 9, 'الفيوم مركز ابشواي يوسف الصديق قرية حنا حبيب'),
(97, 9, 'Address0, العنوان الفيوم كحك بحرى جامع محمد يوسف, Floor 0, Apt 0, Fayoum, Fayoum'),
(98, 9, 'الفيوم السواسله'),
(99, 9, 'البشواي الشواشنه بجوار اسواق الغمراوي'),
(100, 9, 'بحيره قارون ش المركز عماره 12 شقه 6 خلف الشهر العقاري'),
(101, 9, 'الفيوم مركز يوسف الصديق - قارون - خرابة الشيمي - بعد مفارق قارون'),
(102, 9, 'الفيوم ابشواي النصاريه طريق الوسطاني'),
(103, 9, 'العنوان/الفيوم -ابشواى-النزله -بجوار صيدلية خديجة'),
(104, 9, 'الفيوم ابشواى عند موقف كحك بحرى'),
(105, 9, 'مركز ابشواي امام البنك الاهلي'),
(106, 9, 'الفيوم - مركز سنورس - قرية فيديمن - موقف المنجايه او موقف علي عامر'),
(107, 9, 'الفيوم ابشواي\n 01287263271'),
(108, 9, 'الفيوم - ابشواى - كوبرى ابو حنشو امام محل وليد عزام للاقمشة - عمارة د/انور'),
(109, 9, 'حنا حبيب ابشواي الفيوم'),
(110, 9, 'الفيوم - شارع النجارين'),
(111, 9, 'العنوان الفيوم تلات منشأة سكران'),
(112, 9, 'العنوان/ الفيوم.. ابشواي.. المدرسه الابتدائيه.. الشنطوري'),
(113, 9, 'الفيوم ابشواي بجوار المطافي'),
(114, 9, 'الفيوم ابشواي ش الجمهوريه'),
(115, 9, 'الفيوم ابشواي الحامولي'),
(116, 9, 'المندره طريق ابشواي السياحي'),
(117, 9, 'مركز يوسف الصديق. الحامول قرية حمزاوي..بجوار قنطرة يوسف..منزل استاذ محمد جعفر جوده.'),
(118, 9, 'فيدميين'),
(119, 9, 'ابشواي الفيوم'),
(120, 9, 'الفيوم ابشواى ابوجنشو كشرى راشد'),
(121, 9, 'الفيوم مركز ابشواي ميدان المطافي محل الملكة للحلويات'),
(122, 9, 'الفيوم &#x2F;مركز ابشواي&#x2F; قرية النزلة &#x2F; منطقة السوق القديم'),
(123, 9, 'الفيوم_ فيديمين _موقف علي عامر'),
(124, 9, 'الفيوم جمب مسجد الحرميين بعد المعهد الديني بني صالح'),
(125, 9, 'الفيوم ابشواي بجوار المرور'),
(126, 9, 'الفيوم اشبواي بجوار المستشفي العام'),
(127, 9, 'ابشواي بجوار فرع فودافون'),
(128, 9, 'ابشويابوكساه'),
(129, 9, 'الفيوم يوسف الصديق قارون اباظه'),
(130, 9, 'محافظة الفيوم مركز ابشواى ابوكساه شارع السبيل جامع المرجاوى'),
(131, 9, 'ابو شانوي'),
(132, 9, 'ابشواي عند المطافي'),
(133, 9, 'الفيوم ... قريه المندره'),
(134, 9, 'الفيوم ابشواي كفر عبود'),
(135, 9, 'سنهور امام الجنيسه القديمه ضروري وممككن التواصل واتساب'),
(136, 9, 'ابشواي بجوار فرع فوادفون'),
(137, 9, 'الفيوم -مركز ابشواي -قريه هويدي - الشارع العمومي-بجوار المسجد'),
(138, 9, 'الفيوم مركز ابشواي بلد الشواشنة عند اسواق الغراوي'),
(139, 9, 'الفيوم مركز ابشواى امام مجلس المدينة'),
(140, 9, 'ابشواى ابوكساه الفاروقه امام مسجد المحطه معرض اليسر السيراميك(التسليم ضرورى جدا)'),
(141, 9, 'قرية الثلثمائة يوسف الصديق الفيوم'),
(142, 9, 'الفيوم مركز يوسف الصديق قرية العواشنة'),
(143, 9, 'الفيوم ابشواي ميدان المحطه خلف بنك مصر داخل شركه فايد للسياحه'),
(144, 9, 'مركز أبشواي قريه النزله بجوار مدرسه الروضه المشتركه منزل أستاذ على صابر'),
(145, 9, 'ش. سعد زغلول ابشواى الفيوم'),
(146, 9, 'مركز يوسف الصديق\n المشرك قبلي\n شارع البحر عيادة الأسنان دكتور محمود عبدالعزيز'),
(147, 9, 'مركز ابشواي المطافئ'),
(148, 9, 'ابو كساه'),
(149, 9, 'قرية سنرو القبليه مركز ابشواي عند فيلا الشيخ علي ابراهيم'),
(150, 9, 'يوسف الصديق ابشواي'),
(151, 9, 'الفيوم / ابشواى/ ابو كساه'),
(152, 9, 'الفيوم فيدمين الطريق السياحي بعد موقف المانجايه امام جامع محمد مرسي'),
(153, 9, 'العنوان: الفيوم ابشواي ابوجنشو اول طريق الصفرايه العماره6ادوار امام الملعب'),
(154, 9, 'الفيوم سنورس سنهور القبليه بجوار صيدلية د أشرف الليموني'),
(155, 9, 'الفيوم مركز ابشواي شارع المستشفى العام'),
(156, 9, 'فيوم مركز ابشواي قريه عجمين'),
(157, 9, 'الفيوم مركز سنورس سنهور الفيوم'),
(158, 9, 'قريه تونس السياحه -مركز يوسف الصديق- محافظة الفيوم'),
(159, 9, 'ابشواي ابوكساه امام الكنيسه'),
(160, 9, 'ابو دنقاش مركز اشواي'),
(161, 9, 'العنوان محافظه الفيوم القريه بنى صالح خلف مسجد الحرمين ببنى صالح'),
(162, 9, 'ابشواي شارع الجيلاني بجانب صيدلية د ابراهيم'),
(163, 9, 'بجوار البنك الاهلي'),
(164, 9, 'قصر قارون بجانب مدرسه'),
(165, 9, 'ابوكساه'),
(166, 9, 'الخواجات'),
(167, 9, 'فيديمين السجل المدني'),
(168, 9, 'فدمين مركز الشباب'),
(169, 9, 'بجوار مشروع المياه القديم'),
(170, 9, 'الشواشنه'),
(171, 9, 'خلف مسجد الاخوه'),
(172, 9, 'سنهور القبليه محل دهب المدينه المنوره امام مسجد بدر'),
(173, 9, 'محافظه الفيوم ابشواي ابو جنشو شارع التحرير'),
(174, 9, 'مركز البتواي ش البحر الجديد'),
(175, 9, 'ابشواي فرية النصاريه الفيوم'),
(176, 9, 'الفيوم ابشواي المنشيه'),
(177, 9, 'الفيوم &#x2F; سنهور وسط البلد'),
(178, 9, 'الفيوم مركز الفيوم قرية بني صالح'),
(179, 9, 'العنوان الفيوم ابشواي قصر الجبالي'),
(180, 9, 'الفيوم سنورس فيدميين بجوار موقف على عامر'),
(181, 9, 'الفيوم مركز ابشواي قريه العجمين بجوار مسجد الهدايه'),
(182, 9, 'الفيوم مركز ابشواي قصر الجبالي امام البريد'),
(183, 9, 'الفيوم مركز سنهور قريه الطوحين اول البلد'),
(184, 9, 'ابوالحارث احمد شعبان العنوان عزبة بطرس مركز سنهور القبليه محافظة الفيوم'),
(185, 9, 'الفيوم طريق تلات العجميين نزلت الحريشي'),
(186, 9, 'مركز ابشواي علي البركه'),
(187, 9, 'الفيوم مركز سنهور \n \n FAYOUM FYM \n EGYPT'),
(188, 9, 'العجميين'),
(189, 9, 'العنوان الفيوم /السليين/عزبه الحلفايا'),
(190, 9, 'محافظه الفيوم مركز يوسف الصديق الشواشنة اول طريق بطن هريت بجوار المستوصف الطبي صيدلية د هبة عبد المجيد'),
(191, 9, 'عزبة معوض بعد بحيرة قارون قبل سنهور'),
(192, 9, 'الفيوم مركز ابشوامى قريه ابو كساه ميدان السبيل'),
(193, 9, 'السليين'),
(194, 9, 'يوسف الصديق شعلان صيد ليه محمد عيد الونييس'),
(195, 9, 'العنوان محافظه الفيوم قريه سنهور القبليه الكبري بجوار مسجد بدر'),
(196, 9, 'الفيوم مركز ابشواي قرية ابو كساة'),
(197, 9, 'ميدان سنهور عند مسجد الطواحين'),
(198, 9, 'المشرك قبلي يوسف الصديق'),
(199, 9, 'الفيوم / ابشواي /مركز يوسف الصديق / قارون / قوته'),
(200, 9, 'الفيوم مركز ابشوي'),
(201, 9, 'الفيوم سنورس بحيره قارون قاعه اللؤلؤه قريه محمد يوسف'),
(202, 9, 'الفيوم مركز ابشواى قرية طبهار'),
(203, 9, 'فيوم مركز اشنونن قريهخ بعد مدرسه همر الخولي الابتدائيه .'),
(204, 9, 'الفيوم مركز ابشواي قرية طبهار او الفيوم موقف مصر بجوار بنزينة التعاون'),
(205, 9, 'الفيوم ابشواي شارع الجمهوريه بجوار كازيون\n FYM\n FAYOUM\n EGYPT'),
(206, 9, 'الشواشته ابشواى'),
(207, 9, 'الشواشنه او شكشوك'),
(208, 9, 'الفيوم ابشواي'),
(209, 9, 'الحامولي'),
(210, 9, 'قريه الصعايده'),
(211, 9, 'ابشواي النزله بجوار صيدليه د.خديجه'),
(212, 9, 'الفيوم ابشواى شعلان'),
(213, 9, 'الفيوم سنسورس موقف سنهور القبليه قصاد كشري اللؤلؤة'),
(214, 9, 'الفيوم بحيرة قارون بجانب نادي الشباب في شكشوك'),
(215, 9, 'الفيوم مركز ا بشواي عند النازله'),
(216, 9, 'تلات تبع الفيوم'),
(217, 9, 'الفيوم مركز يوسف الصديق امام مول عصام عبد الله'),
(218, 9, 'فيديمين عند موقف الحاج عامر هبعت حد ياخده مش هيدخل جوا البلد او لو عرفت اوفق مع المندوب اخده منه من الفيوم نفسها'),
(219, 9, 'الفيوم طبهار عند موقف الشوارع'),
(220, 9, 'الفيوم مركز ابشواي قريت العجميين بجوار منزل يوسف الشازلي'),
(221, 9, 'العنوان الفيوم مركز ابشواي مفارق يوسف الصديق'),
(222, 9, 'الفيوم ابشواى بجوار المعهد الدينى'),
(223, 9, 'الفيوم ابشواي شارع الساقيه'),
(224, 9, 'الفيوم اشواق ابودنقاس'),
(225, 9, 'الفيوم مركز ابشواي قرية أبو شنب الفيوم'),
(226, 9, 'من قريت بني صالح'),
(227, 9, 'محافظة الفيوم مركز ابشواي شارع الساقيه مقابل المعهد الازهري'),
(228, 9, 'ساميه عبد العزيز محمد محافظه الفيوم مركز ابشواى قريه طبهار درب الوابور'),
(229, 9, 'العنوان :الفيوم -ابشواي بجوار البنك الاهلي'),
(230, 9, 'رائد صلاح الفيوم يوسف الصديق مشرك قبلى 01068297976'),
(231, 9, 'الفيوم مركز الفيوم زاوية الكرادسة'),
(232, 9, 'الفيوم مركز ابيشواي بلونه'),
(233, 9, 'الفيوم / مركز ابشواي/ كوبري ابشواي أمام محل خضروات وفواكه حسين أبو عرب'),
(234, 9, 'العنوان الفيوم /ابشواي /النزله'),
(235, 9, 'الفيوم ابشواي'),
(236, 9, 'الفيوم ابشواي - ابوكساه الفاروقة بجوار المدرسة الإبتدائية المشتركة منزل حمدي محمود'),
(237, 9, 'الفيوم السيليين عند المراجيح'),
(238, 9, 'الفيوم ابشواي ابو شنب'),
(239, 9, 'قوته قارون يوسف الصديق'),
(240, 9, 'الفيوم مركز سنهور يمين موقف على عامر عماره على زهران'),
(241, 9, 'ركز ابشواي قرية ايوكساه ميدان السبيل'),
(242, 9, 'قرية تلات'),
(243, 9, 'ميدان سنهور معرض الشريف'),
(244, 9, 'الفيوم ايشواي بجوار معمل البرج'),
(245, 9, 'مركز الستورس قرية فيديمين بجوار موقف علي عامر'),
(246, 9, 'الفيوم ابشوايي امام المدرسه الثاويه'),
(247, 9, 'ابشواي نزله'),
(248, 9, 'الفيوم ابشواي ابوكساه عن كوبري معبد'),
(249, 9, 'محافظة الفيوم ابشواي قصر الجبالي عند البنزينه'),
(250, 9, 'الفيوم مركز ابشواي بجوار ماستر للكمبيوتر'),
(251, 9, 'م الفيوم م ابشواي بجوار مركز ابشواي'),
(252, 9, 'بحير قارون'),
(253, 9, 'الفيوم ابشواي المشرك عفيفي'),
(254, 9, 'الفيوم بدروسين الشرقيه يوسف الصديق المشرك البحري'),
(255, 9, 'ابشواي الفيوم امام المطافي'),
(256, 9, 'الفيوم مركز يوسف الصديق مفارق يوسف الصديق بجوار بنزينه التعاون'),
(257, 9, 'الفيوم - يوسف الصديق - مفارق قارون'),
(258, 9, 'خلف البنك الاهلي ابشواي'),
(259, 9, 'الفيوم /مركز سنورس/ قريه فيديمين'),
(260, 9, 'الفيوم ابشواي بجوار مدرسه الثانويه العامه للبنات محل عصير العابد'),
(261, 9, 'الفيوم. يوسف الصديق. الحامولى'),
(262, 9, 'الفيوم مركز الفيوم زاوية الكرادسه اول البلد امام ارض الاوقاف'),
(263, 9, 'كحك بحري بحيره قارون'),
(264, 9, 'ابشواي مفارق يوسف الصديق'),
(265, 9, 'الفيوم \n مركز يوسف الصديق قرية النزله عند موقف العربيات بجوار فرع اتصالات'),
(266, 9, 'الفيوم ابشواي عند المطافي'),
(267, 9, 'الفيوم ابشواي قريه ابوكساه'),
(268, 9, 'المنشيه البحريه'),
(269, 9, 'سنهور عزبه محمد يوسف'),
(270, 9, 'الفيوم جنب فندق القوات المسلحه ع بحيره قارون'),
(271, 9, 'يوسف الصديق تونس'),
(272, 9, 'يوسف الصديق قارون'),
(273, 9, 'محافظه الفيوم مركز يوسف الصديق قريه الرواشدية بجوار سوبر ماركت المحمديه'),
(274, 9, 'الفيوم /ابشواي/قصر الجبالي'),
(275, 9, 'الفيوم سنهور القبليه'),
(276, 9, 'الفيوم فيدمين'),
(277, 9, 'الفيوم ابشواي بجوار موقف كحك الفيوم'),
(278, 9, 'الفيوم مركز بني صاالح'),
(279, 9, 'الفيوم سنهور القبلية بجوار فرن عبدالله دياب'),
(280, 9, 'الفيوم ابشواي شكشوك'),
(281, 9, 'الفيوم مركز ابشواي عند فندق القوات المسلحه'),
(282, 9, 'الفيوم ابشواي قرية سنرو القبلية عند المعهد الديني القديم التواصل علي الرقم الاراضي'),
(283, 9, 'الفيوم ابو كساه ابشواي'),
(284, 9, 'الفيوم , الفيوم , محافظة الفيوم - الابعديه مركز يوسف الصديق قرية الابعدية منزل الاستاذ عادل طاهر ميزار'),
(285, 9, 'قارون مركز يوسف الصديق'),
(286, 9, 'المشرك'),
(287, 9, 'طبهار ضروري جداا من بعد الساعه4'),
(288, 9, 'بني صالح عند المظله'),
(289, 9, 'ابشواي ابو جنشو شارع الروبي بيت احمد مصطفي'),
(290, 9, 'ش البوره شارع سعد زغلول'),
(291, 9, 'المكان الفيوم ابشواي النزله الصوق القديم بجوار جامع الرحمه'),
(292, 9, 'الفيوم مركز ابشواي'),
(293, 9, 'الفيوم ، سنرو ، عزبة دكم ، فيلا العمدة محمد دكم'),
(294, 9, ' مركز ابشواي قرية ابوكساه كوبري معبد او مسجد معبد'),
(295, 9, 'بجوار المطافي'),
(296, 9, 'العنوان الفيوم سنهور القبليه بجوار مركز سنهور'),
(297, 9, 'مدينة الشواشنة بجوار مستشفي الشواشنة'),
(298, 9, 'ع. محافظه الفيوم مركز يوسف الصديق قرية الصعايده أمام مسجد السيده خديجه'),
(299, 9, 'السنباط'),
(300, 9, 'مركز يوسف الصديق\n  المشرك قبلي بجوار سنترال الاصدقاء طريق زكي صالح'),
(301, 9, 'الفيوم مركز ابشواي قريه ابوكساه'),
(302, 9, 'الفيوم ابشواي ابوجنشو مسجد الشيخ منصور منزل بهاء الدين المحامي'),
(303, 9, 'ابشواي زيد'),
(304, 9, 'العجميين بجور المدرسه الفنيه'),
(305, 9, 'المسله بجوار البنزينه تحويل ابشواي'),
(306, 9, 'الفيوم-سنهور-عندالكنيسه'),
(307, 9, 'الفيوم. ابشواي. قرية الخواجات. علي الكوبري'),
(308, 9, 'الفيوم سنهور القبليه محل مصوغات ومجوهرات المدينه المنوره امام مسجد بدر'),
(309, 9, 'الفيوم  سنورس السليين'),
(310, 9, 'الفيوم سنهور القبلية عزبة عبدالله عليوة طريق بحيرة قارون'),
(311, 9, 'العنوان الفيوم سنهور الاقليه مسجد غلاب'),
(312, 9, 'الفيوم ابشواي عند مستشفى العام بتاعت ابشواي'),
(313, 9, 'الفيوم يوسف الصديق الشواشنه'),
(314, 9, 'الفيوم مركز أبشواى'),
(315, 9, 'سنهور القبليه وليده'),
(316, 9, 'الفيوم ابشواي النزله المقراني منزل جمال كمال الدين شارع ١١'),
(317, 9, 'ندا اسماعيل محافظه الفيوم مركز ابشواي امام المطافي'),
(318, 9, 'شكشوك'),
(319, 9, 'الفيوم مفارق يوسف الصديق محل النهندس حسن حوده امام مسجد'),
(320, 9, 'قرية الحريشي طريق تلات'),
(321, 9, 'الفيوم مركز يوسف الصديق'),
(322, 9, 'مركز إبشواي قريه العجمين عند مجلس المحلي مسجد محمد عبد المجيد إبشواي'),
(323, 9, 'الفيوم مركز يوسف الصديق قريه الشواشينه'),
(324, 9, 'الفيوم مركز يوسف الصديق طريق بحيره قرون قريه الشرفدي'),
(325, 9, 'ابو دنقاش'),
(326, 9, 'الفيوم مركز ابشواي سنرو القبلية فيلا محسن الجمل'),
(327, 9, 'الفيوم مركز ابشواي شرق السكه الحديد'),
(328, 9, 'الفيوم - أبشواي - قرية النزلة'),
(329, 9, 'الفيوم مركز ابشواي سنرو القبليه شارع المدارس بجوار المسجد البحري'),
(330, 9, 'قرية تلات بجوار الجامع الوسطاني اعلي محل ابو حمدي تلات مركز الفيوم'),
(331, 9, 'مركز سنهور القبلية امام مسجد فودة الفيوم'),
(332, 9, 'ابشواي ابو جنشو بجوار د / عباس عند مدرسه التجاره'),
(333, 9, 'مركز ابشواي قرية العجميين بجوار المعهد الدييني مركز ابشواي الفيوم'),
(334, 9, 'الفيوم - العمدية بالنصارية مركز ابشواي'),
(335, 9, 'الفيوم ابشواي قريه النزله منزل محمود علي السيد الموقف'),
(336, 9, 'العنوان- الفيوم،ابشواي،مركز يوسف الصديق قرية كحك بحري بجوار مول المصري'),
(337, 9, 'الفيوم-سنهور القبلية-المفارق-شارع المغربي بجوار الاسعاف'),
(338, 9, 'الفيوم مركز اشوي بجوار موقف الخالدية'),
(339, 9, 'الفيوم - المندره الكوبري الجديد - بجوار مدرسه المندره الابتدائيه'),
(340, 9, 'الفيوم السيليين الطريق السياحي امام مسجد'),
(341, 9, 'الفيوم مركز يوسف الصديق قريه تونس'),
(342, 9, 'قريه سنرو القبلية على طريق ابشواى السياحى محافظه الفيوم'),
(343, 9, 'محافظة الفيوم مركز ابشواى قريه شكشوك'),
(344, 9, 'الفيوم مركز ابشواي قرية ابوكساه 01091495909'),
(345, 9, 'الفيوم ابشواي عند بنك القاهره الكوبري'),
(346, 9, 'زاوية الكرداسه مغلسه اكس بريس'),
(347, 9, 'الفيوم مركز يوسف الصديق - قرية الصبيحي - بجوار نادي الصفوة'),
(348, 9, 'الفيوم ابشواى النزله'),
(349, 9, 'منزل سيد ربيع احمد عبدالشافي امام المساكن السليين'),
(350, 9, 'الفيوم مركز يوسف الصديق بجوار مكتب البريد'),
(351, 9, 'الفيوم منشأة فتيح بجوار مدرسه الاورمان مدخل العجميين'),
(352, 9, 'الفيوم الطريق السياحى مرفق المانجه فيدميين'),
(353, 9, 'الفيوم ابشواي طبهار'),
(354, 9, 'الفيوم يوسف الصديق'),
(355, 9, 'الفيوم مركز يوسف الصديق القرية التانية'),
(356, 9, 'الفيوم سنهور علام'),
(357, 9, 'الفيوم يوسف الصديق'),
(358, 9, 'الفيوم يوسف الصديق'),
(359, 9, 'الفيوم - قديمين موقف علي عامر'),
(360, 9, 'الفيوم مركز ابشواي قريه ابوكسه'),
(361, 9, 'الفيوم يوسف الصديق بريش الغربي'),
(362, 9, 'العنوان الفيوم ابشواى امام كازيون'),
(363, 9, 'الفيوم زاويه الكرداسه'),
(364, 9, 'الفيوم سنهور'),
(365, 9, 'للعنوان قصر بياض ٠'),
(366, 9, 'الفيوم - سنورس - فيديمين'),
(367, 9, 'ابشواي قرية الروشدية'),
(368, 9, 'قرية تونس'),
(369, 9, 'الفيوم يوسف الصديق بريش الغربي'),
(370, 9, 'مركز الفيوم قرية بني صالح بجوار البريد'),
(371, 9, 'فيدميين المثلث'),
(372, 9, 'الفيوم سالم جاد المشرك قبلى يوسف الصديق'),
(373, 9, 'الفيوم مركز يوسف الصديق قصر الجبالي'),
(374, 9, 'الفيوم مركز (ابي شواى) قريه طبهار بجوار مفارق طبهار وجردو و المناشى منزل الماذون صلاح عبد الستار'),
(375, 9, 'الفيوم - مركز ابشواي قرية كحك بحري بجوار مسجد محمد يوسف إبشواي'),
(376, 9, 'العجميين مركز ابشواي بجوار وحدة العلمين إبشواي'),
(377, 9, 'الفيوم ابشواي الشواشنه بجوار المدرسه الثانويه'),
(378, 9, 'كفر عبود المدرسه الاعداديه'),
(379, 9, 'فيدمين'),
(380, 9, 'كحك بحري مسجد عباس'),
(381, 9, 'الفيوم..مركز سنهور فيديمين ..موقف علي عامر عمارة علي زهران'),
(382, 9, 'ابو صايم مطعم ولاد البلد'),
(383, 9, 'سنهور الطواحين'),
(384, 9, 'ابو كساة'),
(385, 9, 'الفيوم..مركز سنهور فيديمين ..موقف علي عامر عمارة علي زهران'),
(386, 9, 'يوسف الصديق قريه الخرابه الشيمي'),
(387, 9, 'القريه الاولي'),
(388, 9, 'بحيره قارون  قبل فندق القوات المسلحه'),
(389, 9, 'الفيوم مركز ابشواي شارع المطافي بجوار شركه WE'),
(390, 9, 'بني صالح مركز الفيوم بجوار البريد المصري شارع المدرسه'),
(391, 9, 'الفيوم ابشواي ابوكساه حزين'),
(392, 9, 'المشرك قبلي'),
(393, 9, 'المشرك قبلي'),
(394, 9, 'المنشيه'),
(395, 9, 'من خط شعلان ل الريان'),
(396, 9, 'الفيوم المشرق قبلي'),
(397, 9, 'الفيوم المندرة الكيمان'),
(398, 9, 'الفيوم ابشوي واما توصل ابشواي اسأل ع ذيد ولما توصل ذيد ابقى قولي'),
(399, 9, 'الفيوم يوسف الصديق الشواشنه'),
(400, 9, 'الفيوم مركز ابشواى سنرو القبلية شارع المدرسة'),
(401, 9, 'الفيوم ابشواي ابوكساه السياحي امام مو صلاح'),
(402, 9, 'شارع الرزنه قرية الصبيحي بجوار مسجد الرزنه مركز يوسف الصديق'),
(403, 9, 'الفيوم يوسف الصديق قارون الخلطه'),
(404, 9, 'المنشيه'),
(405, 9, 'ابوكساه ميدان السبيل'),
(406, 9, 'الشواشنة كحك بحري بجوار مول المصري'),
(407, 9, 'في مستشفى ابشواي المركزي هيستلم في ابوكساه'),
(408, 9, 'النزله'),
(409, 9, 'محافظه الفيوم مركز ابشواي قريه الحامولي'),
(410, 9, 'العنوان الفيوم مركز يوسف الصديق شارع احمد افندي'),
(411, 9, 'العنوان الفيوم. مركز ابشواي قرية كحك بحري'),
(412, 9, 'النزله'),
(413, 9, 'مركز ابشواي قريه ابودنقاش'),
(414, 9, 'الفيوم ابشواي سنرو'),
(415, 9, 'النزله'),
(416, 9, 'النصاريه'),
(417, 9, 'الفيوم \n مركز سنورس قريه سنهور البحريه امام اللمدرسه الابتدأيه**عبوه'),
(418, 9, 'المندرة / الكوبري القديم / محافظة الفيوم'),
(419, 9, 'قرية أبو شنب بجوار الوحدة المحلية'),
(420, 9, 'الفيوم مركز يوسف الصديق قرية بطن اهريت'),
(421, 9, 'Address: الفيوم- ابشواي - شارع المستشفى - برج شركة الغاز'),
(422, 9, 'ابشواي قريه الريان'),
(423, 9, 'تلات الفيوم مركز الفيوم'),
(424, 9, 'الفيوم مركز ابشواي قريه سنرو'),
(425, 9, 'النصاريه'),
(426, 9, 'الفيوم.ابشواي.النصاريه بجوار مدرسه عمر الخولي'),
(427, 9, 'مركز يوسف الصديق قرية الريان'),
(428, 9, 'تونس'),
(429, 9, 'فديمين موقف على عامر الفيوم'),
(430, 9, 'مركز ابشواي شارع الجمهوريه بجوار مسجد الحضانه'),
(431, 9, 'ابشواي شارع البوره بجوار مسجد عاشور إبشواي'),
(432, 9, 'ابو صايم'),
(433, 9, 'النصاريه'),
(434, 9, 'إبشواي'),
(435, 9, 'سنهور القبليه عند المفارق عند مسجد الكويتي بالظبط'),
(436, 9, 'يوسف الصديق قريه ابو لطيعه'),
(437, 9, 'سنهور البحريه'),
(438, 9, 'إبشواي'),
(439, 9, 'الفيوم قريه العجميين'),
(440, 9, 'مركز يوسف الصديق المشرك قبلي الصببحي ع الكوبري'),
(441, 9, 'الفيوم مركز ابشواي قريه النصاريه بجوار مسجد النورق'),
(442, 9, 'لفيوم مركز يوسف الصديق حناحببب بجوار صيدليه الدكتور اسماعيل الشيمي'),
(443, 9, 'إبشواي'),
(444, 9, 'الفيوم بجوار مسجد الجمعيه الخيريه ابشواي'),
(445, 9, 'ابوشنب مركز ابشواي'),
(446, 9, 'مركز ابشواي قرية ابوكساه'),
(447, 9, '،الفيوم مركز الشواشنه ،0'),
(448, 9, 'إبشواي'),
(449, 9, 'الفيوم مركز سنورس سيلين امام المسجد الكبير'),
(450, 9, 'العنوان الفيوم سنهور القبلية'),
(451, 9, 'الفيوم - سنرو القبلية - امام البريد'),
(452, 9, 'الفيوم الشواشنه الرواشدية أول القريه من جة الشرق \n طريق ابشواى كحك قبلي الرواشدية'),
(453, 9, 'ابشواي مستشفي مكه'),
(454, 9, 'إبشواي'),
(455, 9, 'إبشواي'),
(456, 9, 'إبشواي'),
(457, 9, 'إبشواي'),
(458, 9, 'إبشواي'),
(459, 9, 'إبشواي'),
(460, 9, 'طبهار بجوار قهوه الدهشان'),
(461, 9, 'إبشواي'),
(462, 9, 'بني صالح'),
(463, 9, 'بني صالح'),
(464, 9, 'الفيوم مركز يوسف الصديق - قارون -القرية الثانية - بجوار المسجد الكبير -أمام صيدلية د /مسعود'),
(465, 9, 'الفيوم مركز سنيورس قريه سيد مني سوبر ماركت ابو شادى بجوار موقف على عامر'),
(466, 9, 'الفيوم قرية طبهار'),
(467, 9, 'غير مسموح بالفتح \n الفيوم مركز ابشواي بجوار ماستر للكمبيوتر'),
(468, 9, 'بني صالح'),
(469, 9, 'في الحمولي الفيوم'),
(470, 9, 'بني صالح شارع السبعه'),
(471, 9, 'سنرو القبليه'),
(472, 9, 'محافظة الفيوم مركز ابشواي مقيم في المالحه'),
(473, 9, 'سنرو القبليه'),
(474, 9, 'عند مفارق قارون'),
(475, 9, 'سنهور'),
(476, 9, 'الفيوم سنهور'),
(477, 9, 'سنهور'),
(478, 9, 'سنهور'),
(479, 9, 'الفيوم\n أبشواي شارع المستشفي العام طريق ابوكساه'),
(480, 9, 'محافظه الفيوم مركز ابشواي امام امن الدوله'),
(481, 9, 'سنهور'),
(482, 9, 'ابشواي كحك بحري'),
(483, 9, 'ابوكساه'),
(484, 9, 'الفيوم يوسف الصديق قريه غيدان بجوار المستشفى'),
(485, 9, 'سنهور'),
(486, 9, 'الفيوم الدائري دخله المندره فيلا اشرف ميزار'),
(487, 9, 'السلسبين ينزل عند القهوه العموميه بجوار جامع الرحمن الفيوم'),
(488, 9, 'سنهور'),
(489, 9, 'الفيوم/ابشواي/قصرالجبالي'),
(490, 9, 'الفيوم ابشواي قبلي'),
(491, 9, 'الفيوم مركذ سنورس قريه سنهور المنذل امام مسجد بدر 01050525105'),
(492, 9, 'الفيوم مركز ابشواي بجوار البنك الاهلي'),
(493, 9, 'الفيوم مركز سنورس سنهور القبلية ع العصر لان العميل بيبقي نايم'),
(494, 9, 'الفيوم ابشواي ع طريق السياحي بحيرة قارون قريه الصعايدة'),
(495, 9, 'الفيوم قريه تلات عند مسجد الفاروق عمر بن الخطاب'),
(496, 9, 'الفيوم مركز سنورس - قرية سنهور - منطقة المجمع بجوار مدرسة ياسين عليوة الابتدائية'),
(497, 9, 'سنهور'),
(498, 9, 'سنهور'),
(499, 9, 'سنهور'),
(500, 9, 'امام مسجد الشريف في سنهور'),
(501, 9, 'الفيوم مركز السنباط بجوار عماره المهندس امين'),
(502, 9, 'محافظه الفيوم نزله بشير'),
(503, 9, 'قرية زاوية كرداسة / علي طريق سنهور / بجوار مغسلة الجزيرة'),
(504, 9, 'المكان الفيوم قريت فيدمين بجوار محلات الاازوار'),
(505, 9, 'الفيوم مركز بشواى عزبة شرف الدين'),
(506, 9, 'تبشواي'),
(507, 9, 'الفيوم ابشواى شارع الجمهورية'),
(508, 9, 'العنوان/ الفيوم مركز ابشواي ابوكساه'),
(509, 9, 'ابشواي ابوكساه عند الكنيسه هنعطي للعميل 435'),
(510, 9, 'ابشواي  كفر عبود'),
(511, 9, 'سنهور'),
(512, 9, 'سنهور'),
(513, 9, 'يوسف الصديق الخلطه'),
(514, 9, 'يوسف الصديق قارون القريه الاولي معرض الفخراني'),
(515, 9, 'التوفيقيه'),
(516, 9, 'المندره'),
(517, 9, 'يوسف الصديق الصبيحي'),
(518, 9, 'سنهور البحريه'),
(519, 9, 'محافظه الفيوم مركز سنورس مدينه السيليين'),
(520, 9, 'الفيوم ابشواي جبل التجار'),
(521, 9, 'مركز يوسف الصديق قرية طريق السياحي'),
(522, 9, 'الفيوم مركز يوسف الصديف ش السجل المدني'),
(523, 9, 'الفيوم مركز ابشواي كوبري ابو جنشوا بجوار كشري الشيماء'),
(524, 9, 'سنهور البحريه'),
(525, 9, 'سنهور القبليه'),
(526, 9, 'الفيوم ابشواى قرية طبهار'),
(527, 9, 'الفيوم سنهور القبليه اول عزبه جاب الله'),
(528, 9, 'الفيوم ابشواى قرية النزله'),
(529, 9, 'العجمين عزبت ابو شنب الفيوم'),
(530, 9, 'الفيوم مركز يوسف الصديق الرواشدية شارع المغسلة'),
(531, 9, 'الطريق السياحي بعد المثلث امام ابوعزت'),
(532, 9, 'الفيوم ابشواي امام مسجد الحضانة'),
(533, 9, 'الفيوم مركز ابشواي طحاوي'),
(534, 9, 'الفيوم سنهور كفتريا اللؤلؤة بحيرة قارون'),
(535, 9, 'عزبه خضير قبل كحك السياحي مركز الشواشنه'),
(536, 9, 'سنورس بحيره قارون قاعه اللؤلؤه'),
(537, 9, 'مركز ابشواي شكشوك البركه خلف المدرسه الابتدائي منزل الشيخ يوسف'),
(538, 9, 'فدمين غرب البلد فيلا الشاهد'),
(539, 9, 'الفيوم يوسف الصديق مدرسة القرية الثالثة أنا شغال في المدرسة'),
(540, 9, 'الفيوم مركز ابشواي قرية ابو دنقاش'),
(541, 9, 'الفيوم مركز ابشواي الطريق السياحي بجوار كافية العمده معرض سايبس للدهانات البيت الحديث'),
(542, 9, 'سنهور القبليه عند المفارق'),
(543, 9, 'يوسف الصديق قريه تونس بجوار فندق ظلال النخيل'),
(544, 9, 'الرواشديه الشواشنه'),
(545, 9, 'ابشواي كفر عبود'),
(546, 9, 'الفيوم مركز ابشواي قريه شكشوك'),
(547, 9, 'محافظه الفيوم مركز سنهور فيديمن'),
(548, 9, 'العنوان /مصر . الفيوم . ابشواى .الشواشنه .بجوار قسم شرطه الشواشنه .منزل الحاج صبرى سليمان \n رقم التلفون /'),
(549, 9, 'الفيوم مركز سنورس قريه سنهور القبليه منزل الشيخ علي جبيلي'),
(550, 9, 'ابشواي امام مجلس المدينه'),
(551, 9, 'سنهور القبليه'),
(552, 9, 'مركز ابشواى - شارع البورة - بجوار صيدلية احمد فؤاد'),
(553, 9, 'ش شعبان بجوار مسجد العمده'),
(554, 9, 'جبل النجار'),
(555, 9, 'سنهور القبليه'),
(556, 9, 'منتجع نورياس ع البحر'),
(557, 9, 'سنهور عزبه ابو سلام'),
(558, 9, 'سنهور القبليه عند الجمعيه الزراعيه'),
(559, 9, 'طبهار تشوين خالد محمد فرج'),
(560, 9, 'فيديمين موقف الحج علي عامر'),
(561, 9, 'ابشواي المحافظه توفيق حنين'),
(562, 9, 'سنهور القبليه'),
(563, 9, 'سنهور القبليه'),
(564, 9, 'سنهور القبليه'),
(565, 9, 'ش الجلاء ابشواي'),
(566, 9, 'سنهور القبليه'),
(567, 9, 'مركز يوسف الصديق'),
(568, 9, 'سنهور القبليه'),
(569, 9, 'قريه تبهار عند موقف الفيوم امام اكشن منزل الحاج محمد عبد الرشيد'),
(570, 9, 'سنهور القبليه'),
(571, 9, 'فيديمين مقابل سجل مدني'),
(572, 9, 'سنهور القبليه'),
(573, 9, 'العجمين الشارع الجنينه'),
(574, 9, 'سنهور القبليه'),
(575, 9, 'مركز يوسف الصديق قارون قوته بجوار صيدليه الدكتور'),
(576, 9, 'سنهور القبليه'),
(577, 9, 'ابشواي عند فرع اوكازيون'),
(578, 9, 'ابشواي جامع الاخوه او بنك القاهره'),
(579, 9, 'يوس الصديق قريه كحك بحري مول المصري مقر عمل'),
(580, 9, 'شارع المدارس الابتدائيه بالسنباط'),
(581, 9, 'الفيوم مركز ابشواي شارع د.مها'),
(582, 9, 'محافظه الفيوم - سنهور - ميدان المفارق'),
(583, 9, 'الفيوم ابشواي ع كوبري ابو جنشو معمل ميدان بجوار بنك القاهرة'),
(584, 9, 'البيت الفيوم مركز سنورس فيديمين'),
(585, 9, 'الفيوم مركز الفيوم قرية تلات'),
(586, 9, 'العنوان محافظة الفيوم قرية تلات بداخل البلد'),
(587, 9, 'الفيوم يوسف الصديق كحك بحرى'),
(588, 9, 'قريه قوته بجوارمسجدعبدالمجيدمصباح'),
(589, 9, 'سنهور القبليه'),
(590, 9, 'ميدو الفيوم مركز ابشواى قريه ابو كساه المساكن شارحع الرحمه 01024844835'),
(591, 9, 'قريه ابو كساه'),
(592, 9, 'مركز ابشواي قرية كحك قبلي الجامع الكبير'),
(593, 9, 'ابشواي النزله بجوار مسجد الرحمه'),
(594, 9, 'مركز ابشواي النزله بجوار الموقف'),
(595, 9, 'الفيوم _ مركز يوسف الصديق _ قريه المشرك قبلي'),
(596, 9, 'الفيوم اشواي الشواشنه بجوار البريد'),
(597, 9, 'سنهور القبليه'),
(598, 9, 'الفيوم مركز ابشواي العحميين'),
(599, 9, 'محافظه الفيوم ابشواى قهوه حسن'),
(600, 9, 'المشرك قبلي _ الفيوم _ مركز يوسف صادق'),
(601, 9, 'الفيوم،ابشواي،ابوكساه ،بجوار مسجد معبد'),
(602, 9, 'الفيوم ابشواي الخواجات حناحبيب'),
(603, 9, 'ام حبيبه الفيوم مركز الصديق قارون مفارق يوسف 01032356359'),
(604, 9, 'الفيوم بني صالح امام البريد'),
(605, 9, 'الفيوم بني صالح طريق السليين بحيرة قارون جنب مسجد التقوي الي في بني صالح'),
(606, 9, 'سنهور القبليه المفارق'),
(607, 9, 'سنهور القبليه المفارق'),
(608, 9, 'شارع سعد زغلول'),
(609, 9, 'قريه المندره'),
(610, 9, 'ابشواى امام المطافى'),
(611, 9, 'ابشواي قريه شرف الدين بجوار محطه البنزين'),
(612, 9, 'محافظه الفيوم مركز ابشواي الجيلاني على طريق مصر السياحي'),
(613, 9, 'مركز ابشواى - شارع الجلاء - بجوار المطحن'),
(614, 9, 'شكشوك'),
(615, 9, 'شكشوك'),
(616, 9, 'كفر عبود'),
(617, 9, 'الجبلاني ابشواي الفيوم'),
(618, 9, 'محافظه الفيوم مركز ابشواي يجوار محكمة ابشواي نزلت البوره شارع سعد زغلول عماره النقيب مصطفى عبدالحكيم'),
(619, 9, 'محافظة الفيوم مركز يوسف الصديق قرية الحامولي'),
(620, 9, 'الفيوم اشواي بجوار مسجد الشيخ علدالعليم'),
(621, 9, 'الفيوم ابشواي قصر الجبالي'),
(622, 9, 'الفيوم مركز ابشواي يوسف الصديق قريه اباظه قارون'),
(623, 9, 'ابو شنب ابشواي الفيوم منزل الحاج احمد محمود بجوار المدرسه الابتدائيه'),
(624, 9, 'الفيوم مركز ابشواي امام البنك الاهلي شارع الصعايده علي اول الشارع محل ابوطالب للمحمول'),
(625, 9, 'ابشواي الجيلاني بجوار مقابر الجيلاني الفيوم'),
(626, 9, 'الفيوم مركز سنورس قرية فيديمين'),
(627, 9, 'محمد من الفيوم مركز يوسف الصديق مفارق قارون'),
(628, 9, 'محافظه الفيوم مركز ابشواي قريه النزله'),
(629, 9, 'الفيوم ابشواى كحك'),
(630, 9, 'العنوان ـ الفيوم مركز سنهور القبلية ـ شارع السويقه بجوار مسجد'),
(631, 9, 'مركز ابشواي قريه ابو كشاق'),
(632, 9, 'قريه الشيخ فضل'),
(633, 9, 'قرية أبو كساه'),
(634, 9, 'الفيوم علي البركة ف فندق الواحة'),
(635, 9, 'الفيوم، مركز يوسف الصديق، قارون، قوتة'),
(636, 9, 'شكشوك'),
(637, 9, 'الفيوم ابشواي ماهو متسجل في العنوان لمحل شيخ العطارين 2 قدام البنك الاهلي'),
(638, 9, 'مركز ابشواي كحك بحري'),
(639, 9, 'الفيوم اشواي الصبيحي'),
(640, 9, 'محافظه الفيوم بني صالح'),
(641, 9, 'العنوان الفيوم مركز يوسف الصديق قارون الخلطه صاحب محل حدايد وبويات'),
(642, 9, 'شكشوك'),
(643, 9, 'يوسف الصديق قرية حنا حبيب شارع الجامعه'),
(644, 9, 'طبهار'),
(645, 9, 'طبهار'),
(646, 9, 'ابشواي كفر عمرو'),
(647, 9, 'طبهار'),
(648, 9, 'ابشواي'),
(649, 9, 'طبهار'),
(650, 9, 'الفيوم مركز ابشواي قريه طبهار عند استديو فادي كلر'),
(651, 9, 'ابو كساه شارع الفاوي'),
(652, 9, 'طبهار'),
(653, 9, 'الفيوم مركز الصديق قريه حنا حبيب منزل السيد محمد مهران'),
(654, 9, 'الفيوم مركز الشواشنه المشرك قبلي سنترال الاصدقاء'),
(655, 9, 'الفيوم ابشواي ابوكساه'),
(656, 9, 'الفيوم مركز اشواى'),
(657, 9, 'فلمين موقف علي عامر'),
(658, 9, 'الفيوم . يوسف الصديق . المشرك عند المكنة'),
(659, 9, 'طهبار ابشواي الفيوم'),
(660, 9, 'مركز ابشواي شارع الجمهوريه'),
(661, 9, 'فيديمين'),
(662, 9, 'محافظة الفيوم- مركز يوسف الصديق- بريشه الغربيه\\\\01067171890\n مصاريف الشحن 80ج'),
(663, 9, 'الفيوم الشواشنه'),
(664, 9, 'الشواشنة بجوار البريد'),
(665, 9, 'فيديمين'),
(666, 9, 'فيديمين'),
(667, 9, 'الفيوم مركز ابشواي بجوار اكزيون'),
(668, 9, 'قرية بني صالح بجوار مشويات ابو ادهم'),
(669, 9, 'العنوان الفيوم قرية تلات بجوار مسجد الرحمه'),
(670, 9, 'الفيوم مركز ابشواي قريه ابو كساه'),
(671, 9, 'الفيوم سنهور القبليه بجوار كنسيه السيد العذراء مريم'),
(672, 9, 'فيديمين'),
(673, 9, 'يوسف الصديق الشواشنه'),
(674, 9, 'قارين عين سلين امام الجامعيه الزراعيه'),
(675, 9, 'قارين عين سلين امام الجامعيه الزراعيه'),
(676, 9, 'قرية ابو دنقاش'),
(677, 9, 'قرية ابو دنقاش'),
(678, 9, 'قريه النصاريه'),
(679, 9, 'قريه النصاريه'),
(680, 9, 'المشرك قبلي الشوشنه'),
(681, 9, 'قصر الجبالي'),
(682, 9, 'ابشواي ابو شنب'),
(683, 9, 'يوسف الصديق الخرجين'),
(684, 9, 'كحك بحري'),
(685, 9, 'قصر الجبالي'),
(686, 9, 'منشيه فتيح'),
(687, 9, 'ابشواي ش الجمهوريه بجوار مكتب البريد مخبز محمد علي'),
(688, 9, 'محافظه الفيوم مركز سنهور القبليه بجوار مسجد الطواحين'),
(689, 9, 'ابشواي الشواشنه'),
(690, 9, 'الفيوم مركز الفيوم بني صالح'),
(691, 9, 'محافظه محافظه الفيوم ابشواي ابوكساه'),
(692, 9, 'محافظه الفيوم مركز سنهور القبليه بجوار مسجد الطواحين'),
(693, 9, 'الفيوم ابشواي ع كوبري ابو جنشو معمل الميدان بجوار بنك القاهرة'),
(694, 9, 'ابوشنب البحريه صيدليه دكتوره عائشه عبد التواب الفيوم'),
(695, 9, 'الفيوم قريه سنرو'),
(696, 9, 'الفيوم قريه العجميين مركز ابشواى لمنزل بأسمى بجوار منزل النائب يوسف الشاذلى'),
(697, 9, 'الفيوم سنهور البحرية بالقرب من بحيرة قارون'),
(698, 9, 'الفيوم&#x2F;مركز يوسف الصديق&#x2F; قريه بريشه الشرقيه'),
(699, 9, 'العنوان الفيوم مركز يوسف الصديق قريه النجار'),
(700, 9, 'الفيوم بجوار مركز سنهور القبليه'),
(701, 9, 'الفيوم يوسف الصديق المفارق بتاع المركز'),
(702, 9, 'الفيوم ابشوى النزله الربع'),
(703, 9, 'مركز ابشواي'),
(704, 9, 'مركز ابشواي'),
(705, 9, 'قريه السنباط مركز الفيوم بجوار مسجد التقوي'),
(706, 9, 'لفيوم/ ابشواي/ أول طريق زيد/ قهوة حسن الاستلام فى وررشه المونتال المهندس محمد'),
(707, 9, 'الحميديه الجديده'),
(708, 9, 'الفيوم مركز ابشواى ابو جنشو شارع التحرير بجوار سوبر ماركت التحرير'),
(709, 9, 'الفيوم مركز ابشواي قرية طبهار عند المعهد الديني'),
(710, 9, 'ابشواي ابو جنشو شارعه بورر سعيد بجواار مسجد النور'),
(711, 9, 'مركز ابشواي'),
(712, 9, 'فيديمين الطريق السياحي لجوار صيدليه الدكتور غيث'),
(713, 9, 'ابشواي قصر الجبالي'),
(714, 9, 'مركز ابشواي'),
(715, 9, 'فيوم قريه قديمن'),
(716, 9, 'الفيوم.. مركز يوسف الصديق.. الخريجين شارع السجل المدني بجوار البريد.'),
(717, 9, 'الفيوم قريه بنى صالح الجامع اول طريق بحيره قارون'),
(718, 9, 'الفيوم سنورس سنهور القبليه'),
(719, 9, 'محافظه الفيوم قريه فيديمين عند الموقف'),
(720, 9, 'ابشواي سنرو القبليه'),
(721, 9, 'الفيوم/بجوار بحيرة قارون/قرية وليدة'),
(722, 9, 'سنهور القبلية'),
(723, 9, 'الفيوم مركز ابشواي \nمساكن المطافي محل انتي الاجمل'),
(724, 9, 'مركز ابشواي قرية ابو عيش على ضفاف بحيرة قارون امام كافيتريا قصر الاليزيه'),
(725, 9, 'الفيوم سنهور القبلية موقف الفيوم'),
(726, 9, 'الفيوم فيديمين غرب البلد'),
(727, 9, 'سنهور الفيله عند المجمع'),
(728, 9, 'مركز ابشواي ابشواي موقف الفيوم امام مركز مركز القاضي للاشاعات'),
(729, 9, 'مركز الشواشنة'),
(730, 9, 'الفيوم مركز ابشواى خلف مسجد الحضانة'),
(731, 9, 'مركز ابشواي ابشواي موقف الفيوم امام مركز مركز القاضي للاشاعات'),
(732, 9, 'الفيوم مركز يوسف الصديق عزبة عفيفي'),
(733, 9, 'الفيوم قارون القرية الاوالي'),
(734, 9, 'الفيوم. يوسف الصديق.الحامولى'),
(735, 9, 'زاوية كرداسة مركز الفيوم'),
(736, 9, 'قريه ثلاث بجوارمسجد الفارق عمر'),
(737, 9, 'مركز الشوشنه حارت اروبي امام الفرنه'),
(738, 9, 'الفيوم مركز ابشواي - قرية ابو جنشو - بجوار مدرسة فاطمة الزهراء الاعدادية - منزل ربيع محمود'),
(739, 9, 'الفيوم أبشواي مركز أبشواي'),
(740, 9, 'مركز الشوشنه حارت اروبي امام الفرنه'),
(741, 9, 'الفيوم مركز ابشواي -كحك بحري بجوار صيدليه موده'),
(742, 9, 'الفيوم /ابشواي/شكشوك'),
(743, 9, 'الفيوم شارع ابو مدين بجوار المقابر ابوكساه'),
(744, 9, 'الفيوم بحيره قارون عزبة عبدالقادر موسى'),
(745, 9, 'الفيوم يوسف الصديق قصر الجبالي منطقة التفتيش بجوار صيدليه دكتور عمرو ادريس'),
(746, 9, 'نزلة بشير بعد مدرسة الاورمان الخاصة ع طريق ثلاث بلد قبلها مركز الفيوم'),
(747, 9, 'الشواشنة البريد'),
(748, 9, 'الفيوم قرية بن صالح بجوار التخريمة محل مشويات آدم'),
(749, 9, 'العنوان الفيوم ابشواي في ابو جنشوا عند المطحن'),
(750, 9, 'مركز الشوشنه حارت اروبي امام الفرنه'),
(751, 9, 'زاويه الكرادسه - فيلا اللواء عبد الغفار - الفيوم,'),
(752, 9, 'الفيوم مركز سنورس مركز سنهور القبلية بجوار الاسعاف'),
(753, 9, 'ابشواي امام اوكازيون'),
(754, 9, 'سنهور القبليه مركز علي صالح'),
(755, 9, 'انا من ابشواي المنطقه اسمها الرمليه بجوار الجمعيه الخيريه'),
(756, 9, '‎محافظة الفيوم /مركز ابشواي /قريه كحك قبلي ‎الجامع الكبير'),
(757, 9, 'القيوم ابشواي ش الجمهوريه المنشيه'),
(758, 9, 'الفيوم - ابشواى - ابوكساه'),
(759, 9, 'الفيوم بشويه بوكساه'),
(760, 9, 'مركز الشوشنه حارت اروبي امام الفرنه'),
(761, 9, 'يمكن فتح الشحنة /2ق /محافظه الفيوم قريه بني صالح الفيوم'),
(762, 9, 'سنهور القبليه المفارق عند المسجد الكويتي'),
(763, 9, 'مركز سنهور'),
(764, 9, 'قريه سنهور القبليه بجوار فرع فودافون,FAIYUM GOVERNORATE'),
(765, 9, 'مركز سنهور'),
(766, 9, 'يوسف الصديق'),
(767, 9, 'يوسف الصديق'),
(768, 9, 'يوسف الصديق'),
(769, 9, 'يوسف الصديق'),
(770, 9, 'يوسف الصديق'),
(771, 9, 'يوسف الصديق'),
(772, 9, 'يوسف الصديق'),
(773, 9, 'يوسف الصديق'),
(774, 9, 'شعلان'),
(775, 9, 'يوسف الصديق'),
(776, 9, 'شكره امام مدرسه شكره'),
(777, 9, 'الفيوم النزله ش الوحدة البيطرية رقم 4'),
(778, 9, 'العنوان /ابشواي بجوار مستشفى الهلال عند موقف الفيوم'),
(779, 9, 'مركز ابشواي - المنشيه عند المسجد الغربي'),
(780, 9, 'يوسف الصديق'),
(781, 9, 'يوسف الصديق'),
(782, 9, 'الفسوم مركز ابشواي'),
(783, 9, 'الفيوم ابشوي ابو جنشو شارع الجلاء بجوار المطحن'),
(784, 9, 'يوسف الصديق قوته'),
(785, 9, 'الفيوم مركز ابشوى'),
(786, 9, 'الفيوم قريه فيدمين بجوار عين السيلين'),
(787, 9, 'مركز يوسف اصديق البلد اوتاه'),
(788, 9, 'الفيوم السوار الشواشنه'),
(789, 9, 'الضرب الأخضر منزل بدوى عبد الله'),
(790, 9, 'قرية شكشوك مركز ابشواى محافظة الفيوم'),
(791, 9, 'ابشواي مركز يوسف الصديق'),
(792, 9, 'المشترك القبلي بجوار الكوبرى الغربي مركز يوسف الصديق الفيوم'),
(793, 9, 'الفيوم / ابشواي / قريه بلونه'),
(794, 9, 'يوسف الصديق قوته'),
(795, 9, 'الفيوم /العنوان قريه محافظه الفيوم قرية تلات'),
(796, 9, 'مركز ابشواي قرية حنا حبيب الفيوم'),
(797, 9, 'السنباط مركز الفيوم'),
(798, 9, 'الفيوم مركز سنورس سنهور القبليه طريق عبود'),
(799, 9, 'العنوان الفيوم ابشواي الشارع الي قبل المستشفى العام'),
(800, 9, 'يوسف الصديق قوته'),
(801, 9, 'الفيوم\nمركز يوسف الصديق قرية الحامولي\nعزبت حمزاوي بجوار المقابر'),
(802, 9, 'سنورس_ مركز سنهور الفيوم'),
(803, 9, 'مركز يوسف الصديق ، قرية كحك البحرى ، بجوار مركز الشباب'),
(804, 9, 'بجوار مدرسه الثانوى العامه'),
(805, 9, 'ابشواي ابو جنشو بجوار مدرسه التجاره');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` char(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `gender` char(1) NOT NULL DEFAULT '',
  `address` varchar(255) CHARACTER SET utf8 NOT NULL,
  `identy_number` char(255) NOT NULL,
  `Driving_License` char(255) NOT NULL DEFAULT '',
  `bike_license` char(255) NOT NULL DEFAULT '',
  `commision` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `remember_token` char(255) NOT NULL DEFAULT '',
  `rank_id` int(2) NOT NULL,
  `phonep` char(11) NOT NULL,
  `phonew` char(11) NOT NULL,
  `phone3` char(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `password`, `gender`, `address`, `identy_number`, `Driving_License`, `bike_license`, `commision`, `created_at`, `updated_at`, `remember_token`, `rank_id`, `phonep`, `phonew`, `phone3`) VALUES
(26, 'mahmoud', 'hhetlar121', '$2y$10$QgT.czVTcf3K2mrwF.gkuu79WCOCUXZ3aZo0nmJxbE06AFWTbq39i', 'm', '*', '/storage/26/identy.pdf', '*', '*', 1500, '2022-11-30 19:36:41', '2022-11-30 19:36:41', '', 4, '*', '*', '*'),
(27, 'mahmoud medhat', 'hetlarhhs@gmail.com', '$2y$10$OR7/oynMY/fwbAqnragHyOObO2pxW4dgwWhTmJfqsNCBZw/j7dPkS', 'm', '*', '/storage/27/identy.pdf', '*', '*', 0, '2022-11-29 14:12:01', '2022-11-29 14:12:01', '', 9, '01118991230', '*', '*'),
(28, 'محمود طرفايه', '01004091003', '$2y$10$.IXcPepdi8hSRQK1KMVtUefx9trW40RaLFsaS.mlnS/81L4f7gOay', 'm', 'ابكسا ابشواي', '*', '*', '*', 15, '2022-12-10 11:26:06', '2022-12-10 11:26:06', '', 8, '*', '*', '*'),
(29, 'احمد اشرف', '01211122305', '$2y$10$9mZEDmMhlbgCcjkuu2kOeOYkwFoZCvKXkNrtABX6JWuOSqB2S/nQC', 'm', '*', '*', '*', '*', 0, '2022-11-28 15:55:26', NULL, '', 8, '*', '*', '*'),
(30, 'احمد حسين', '01000602092', '$2y$10$PQHNq0MCUeBwbJaFGhWbSOS8WExFnh1dXb2ScgVr.Z6h/y/w46Nvy', 'm', 'طاميه', '*', '*', '*', 0, '2022-11-28 15:56:12', NULL, '', 8, '*', '*', '*'),
(31, 'احمد ربيع', '01020021620', '$2y$10$VJ8oOkAKB.BB6Jybatk9zOJe14s/rooyeBu6yfR.6lp1kQlkZfvam', 'm', '*', '*', '*', '*', 0, '2022-11-28 15:57:04', NULL, '', 8, '*', '*', '*'),
(32, 'محمد الشيخ', '0103389071', '$2y$10$CDqtsWecEDkMchxwhXSc9.0AnFujsdaeC90rFzSIbapHfenBNjm0O', 'm', '*', '*', '*', '*', 0, '2022-11-28 15:57:40', NULL, '', 8, '*', '*', '*'),
(33, 'محمد رمضان', '01010783089', '$2y$10$mV0oO6bVckSK4EJPvAWkhOa47ztGGOrx8RZhj7eoSuQeKZSyjuTS6', 'm', '*', '*', '*', '*', 0, '2022-11-28 15:58:57', NULL, '', 8, '*', '*', '*'),
(34, 'احمد عبد النبي', '01026249582', '$2y$10$7NEXHzPC8/zwbm.Y/Td1qeqL0VkqflhfRrM1zPUmRIcQyfD2J3WsC', 'm', '*', '*', '*', '*', 20, '2022-12-01 16:36:15', '2022-12-01 16:36:15', '', 9, '*', '*', '*'),
(35, 'ert', 'ert', '$2y$10$Dlp324smVUiRagMydrS9regnW2WI8JbccQlvJ/ioxrcTfIWjxBzNa', 'm', '*', '*', '*', '*', 9000, '2022-11-30 21:29:07', '2022-11-30 21:29:07', '', 5, '*', '*', '*');

-- --------------------------------------------------------

--
-- Table structure for table `uuid`
--

CREATE TABLE `uuid` (
  `id` int(20) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `uuid` char(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account_stament_agents`
--
ALTER TABLE `account_stament_agents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_account_stament_agents_users` (`agent_id`);

--
-- Indexes for table `account_stament_companies`
--
ALTER TABLE `account_stament_companies`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `FK_account_stament_companies_companies` (`company_id`);

--
-- Indexes for table `causes_return`
--
ALTER TABLE `causes_return`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `centers`
--
ALTER TABLE `centers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_centers_users` (`id_agent`),
  ADD KEY `FK_centers_governorates` (`governate_id`);

--
-- Indexes for table `chats`
--
ALTER TABLE `chats`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_chats_users` (`reciver_id`),
  ADD KEY `FK_chats_users_2` (`sender_id`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `companies_phones`
--
ALTER TABLE `companies_phones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_companies_phones_companies` (`id_companiy`);

--
-- Indexes for table `company_expenses`
--
ALTER TABLE `company_expenses`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `delegates`
--
ALTER TABLE `delegates`
  ADD KEY `id_center` (`id_center`),
  ADD KEY `FK_delegates_users` (`delegate_id`);

--
-- Indexes for table `discounts`
--
ALTER TABLE `discounts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_discounts_users` (`id_user`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `governorates`
--
ALTER TABLE `governorates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `keep_money`
--
ALTER TABLE `keep_money`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_notifications_users` (`user_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_orders_centers` (`center_id`),
  ADD KEY `FK_orders_companies` (`id_company`),
  ADD KEY `FK_orders_order_state` (`status_id`),
  ADD KEY `FK_orders_causes_return` (`cause_id`),
  ADD KEY `FK_orders_users` (`delegate_id`),
  ADD KEY `FK_orders_users_2` (`agent_id`);

--
-- Indexes for table `order_state`
--
ALTER TABLE `order_state`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `ranks`
--
ALTER TABLE `ranks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `salaries`
--
ALTER TABLE `salaries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_salaries_users` (`id_user`);

--
-- Indexes for table `stocks`
--
ALTER TABLE `stocks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_stocks_companies` (`company_id`);

--
-- Indexes for table `sub_center`
--
ALTER TABLE `sub_center`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK__centers` (`id_center`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `FK_users_ranks` (`rank_id`);

--
-- Indexes for table `uuid`
--
ALTER TABLE `uuid`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account_stament_agents`
--
ALTER TABLE `account_stament_agents`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `account_stament_companies`
--
ALTER TABLE `account_stament_companies`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `causes_return`
--
ALTER TABLE `causes_return`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `centers`
--
ALTER TABLE `centers`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `chats`
--
ALTER TABLE `chats`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=397;

--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `companies_phones`
--
ALTER TABLE `companies_phones`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `company_expenses`
--
ALTER TABLE `company_expenses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `discounts`
--
ALTER TABLE `discounts`
  MODIFY `id` int(40) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `governorates`
--
ALTER TABLE `governorates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `keep_money`
--
ALTER TABLE `keep_money`
  MODIFY `id` int(90) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1305;

--
-- AUTO_INCREMENT for table `order_state`
--
ALTER TABLE `order_state`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `ranks`
--
ALTER TABLE `ranks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `salaries`
--
ALTER TABLE `salaries`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `sub_center`
--
ALTER TABLE `sub_center`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=806;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `uuid`
--
ALTER TABLE `uuid`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `account_stament_agents`
--
ALTER TABLE `account_stament_agents`
  ADD CONSTRAINT `FK_account_stament_agents_users` FOREIGN KEY (`agent_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `account_stament_companies`
--
ALTER TABLE `account_stament_companies`
  ADD CONSTRAINT `FK_account_stament_companies_companies` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`);

--
-- Constraints for table `centers`
--
ALTER TABLE `centers`
  ADD CONSTRAINT `FK_centers_governorates` FOREIGN KEY (`governate_id`) REFERENCES `governorates` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_centers_users` FOREIGN KEY (`id_agent`) REFERENCES `users` (`id`);

--
-- Constraints for table `chats`
--
ALTER TABLE `chats`
  ADD CONSTRAINT `FK_chats_users` FOREIGN KEY (`reciver_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `FK_chats_users_2` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `companies_phones`
--
ALTER TABLE `companies_phones`
  ADD CONSTRAINT `FK_companies_phones_companies` FOREIGN KEY (`id_companiy`) REFERENCES `companies` (`id`);

--
-- Constraints for table `delegates`
--
ALTER TABLE `delegates`
  ADD CONSTRAINT `FK_delegates_users` FOREIGN KEY (`delegate_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `discounts`
--
ALTER TABLE `discounts`
  ADD CONSTRAINT `FK_discounts_users` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`);

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `FK_notifications_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `FK_orders_causes_return` FOREIGN KEY (`cause_id`) REFERENCES `causes_return` (`id`),
  ADD CONSTRAINT `FK_orders_centers` FOREIGN KEY (`center_id`) REFERENCES `centers` (`id`),
  ADD CONSTRAINT `FK_orders_companies` FOREIGN KEY (`id_company`) REFERENCES `companies` (`id`),
  ADD CONSTRAINT `FK_orders_order_state` FOREIGN KEY (`status_id`) REFERENCES `order_state` (`id`),
  ADD CONSTRAINT `FK_orders_users` FOREIGN KEY (`delegate_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `FK_orders_users_2` FOREIGN KEY (`agent_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `salaries`
--
ALTER TABLE `salaries`
  ADD CONSTRAINT `FK_salaries_users` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`);

--
-- Constraints for table `stocks`
--
ALTER TABLE `stocks`
  ADD CONSTRAINT `FK_stocks_companies` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`);

--
-- Constraints for table `sub_center`
--
ALTER TABLE `sub_center`
  ADD CONSTRAINT `FK__centers` FOREIGN KEY (`id_center`) REFERENCES `centers` (`id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `FK_users_ranks` FOREIGN KEY (`rank_id`) REFERENCES `ranks` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
